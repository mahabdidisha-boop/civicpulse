/**
 * Security Rules Adversarial Verification Suite (Phase 0 Reference)
 * Maps each of the 12 Dirty Dozen payloads in security_spec.md to expected PERMISSION_DENIED behavior.
 */

export interface AdversarialTestCase {
  id: string;
  description: string;
  operation: 'create' | 'update' | 'get' | 'list';
  path: string;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_CASES: AdversarialTestCase[] = [
  {
    id: 'DD-01',
    description: 'Unauthenticated user tries to create an issue',
    operation: 'create',
    path: '/issues/CP-2026-2001',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-02',
    description: 'Authenticated user spoofs authorId of another user',
    operation: 'create',
    path: '/issues/CP-2026-2001',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-03',
    description: 'Unverified email user attempts to create an issue',
    operation: 'create',
    path: '/issues/CP-2026-2002',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-04',
    description: 'Citizen tries to self-assign role: admin in /users/{uid}',
    operation: 'create',
    path: '/users/userA',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-05',
    description: 'Shadow ghost field isVerified injected on issue update',
    operation: 'update',
    path: '/issues/CP-2026-2001',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-06',
    description: 'Non-admin author tries to transition status to Resolved',
    operation: 'update',
    path: '/issues/CP-2026-2001',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-07',
    description: 'Non-admin tries to edit title of already Resolved issue',
    operation: 'update',
    path: '/issues/CP-2026-1003',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-08',
    description: 'User attempts to read another user PII private/info',
    operation: 'get',
    path: '/users/userB/private/info',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-09',
    description: 'Client sends backdated createdAt timestamp instead of request.time',
    operation: 'create',
    path: '/issues/CP-2026-2003',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-10',
    description: 'Oversized 150-char document ID rejected by isValidId()',
    operation: 'create',
    path: `/issues/${'x'.repeat(150)}`,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-11',
    description: 'Standalone upvotes increment without atomic vote document rejected',
    operation: 'update',
    path: '/issues/CP-2026-1001',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-12',
    description: 'User attempts to list another user notifications',
    operation: 'list',
    path: '/users/userB/notifications',
    expected: 'PERMISSION_DENIED',
  },
];
