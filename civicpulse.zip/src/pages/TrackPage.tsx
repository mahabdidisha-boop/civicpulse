import { FormEvent, useEffect, useState } from 'react';
import { Check, Clock, MapPin, Search } from 'lucide-react';
import { getPriorityTextClass, getStatusTextClass } from '../components/IssueCard';
import { CivicIssue, ISSUE_STATUSES } from '../types/issue';

interface TrackPageProps {
  issues: CivicIssue[];
  initialTrackId: string;
}

/**
 * Track Complaint Page:
 * Allows citizens to look up any Complaint ID and inspect its 5-stage resolution timeline,
 * chronological status history, and latest progress notes.
 */
export function TrackPage({ issues, initialTrackId }: TrackPageProps) {
  const [queryId, setQueryId] = useState(initialTrackId || 'CP-2026-1001');
  const [searchedId, setSearchedId] = useState(initialTrackId || 'CP-2026-1001');

  useEffect(() => {
    if (initialTrackId) {
      setQueryId(initialTrackId);
      setSearchedId(initialTrackId);
    }
  }, [initialTrackId]);

  const matchedIssue = issues.find(
    (issue) => issue.id.toLowerCase() === searchedId.trim().toLowerCase()
  );

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSearchedId(queryId.trim());
  };

  const currentStageIndex = matchedIssue
    ? ISSUE_STATUSES.indexOf(matchedIssue.status)
    : -1;

  const sampleIds = issues.slice(0, 4).map((item) => item.id);

  return (
    <div className="mx-auto max-w-4xl space-y-8 py-10">
      <div className="border-b border-[var(--cp-border)] pb-6">
        <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
          Status Lookup
        </p>
        <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl">
          Track Complaint Progress
        </h1>
        <p className="mt-1.5 text-sm sm:text-base text-[var(--cp-text-muted)]">
          Enter your unique Complaint ID to inspect current verification stage and chronological
          status updates.
        </p>
      </div>

      {/* Complaint Lookup Form */}
      <form onSubmit={handleSearch} className="cp-card p-6 sm:p-7">
        <label
          htmlFor="complaint-id-input"
          className="block text-sm font-bold text-[#172B45] dark:text-white"
        >
          Complaint Tracking ID
        </label>
        <div className="mt-2.5 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--cp-text-muted)]"
              aria-hidden="true"
            />
            <input
              id="complaint-id-input"
              type="text"
              value={queryId}
              onChange={(e) => setQueryId(e.target.value)}
              placeholder="e.g., CP-2026-1001"
              className="w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] py-2.5 pl-10 pr-4 font-mono-tabular text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="cp-btn-primary px-6 py-2.5 text-sm whitespace-nowrap min-h-[44px]"
          >
            Track Complaint
          </button>
        </div>

        {/* Quick-select sample IDs */}
        <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-[var(--cp-text-muted)]">
          <span className="font-semibold">Quick lookup:</span>
          {sampleIds.map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                setQueryId(id);
                setSearchedId(id);
              }}
              className={`rounded-lg border px-2.5 py-1 font-mono-tabular font-semibold transition-colors ${
                searchedId.toUpperCase() === id.toUpperCase()
                  ? 'border-[#159C91] bg-[var(--cp-accent-soft)] text-[#0F7E75] dark:text-[#2DD4BF]'
                  : 'border-[var(--cp-border)] bg-[var(--cp-bg)] hover:border-[#159C91] hover:bg-[var(--cp-accent-soft)]'
              }`}
            >
              {id}
            </button>
          ))}
        </div>
      </form>

      {/* Results or Empty/Not-Found State */}
      {!matchedIssue ? (
        <div className="cp-card p-10 text-center">
          <p className="font-display text-lg font-bold text-[#172B45] dark:text-white">
            No Complaint Found for “{searchedId}”
          </p>
          <p className="mt-1.5 text-sm text-[var(--cp-text-muted)]">
            Check the Complaint ID format (for example, CP-2026-1001) or choose one of the quick
            lookup IDs above.
          </p>
        </div>
      ) : (
        <article className="space-y-6">
          {/* Complaint Overview Card */}
          <div className="cp-card p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[var(--cp-border)] pb-5">
              <div>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[var(--cp-text-muted)]">
                  <span className="font-mono-tabular font-semibold text-[var(--cp-text)]">
                    {matchedIssue.id}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{matchedIssue.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className={`font-semibold ${getPriorityTextClass(matchedIssue.priority)}`}>
                    {matchedIssue.priority} Priority
                  </span>
                  {matchedIssue.isDemoRecord && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Sample Demo Record</span>
                    </>
                  )}
                </div>
                <h2 className="mt-2 font-display text-xl font-extrabold text-[#172B45] dark:text-white">
                  {matchedIssue.title}
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-[var(--cp-text-muted)]">
                  {matchedIssue.description}
                </p>
              </div>

              <div className="text-left sm:text-right">
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Current Status</p>
                <p className={`mt-0.5 font-display text-lg font-extrabold ${getStatusTextClass(matchedIssue.status)}`}>
                  {matchedIssue.status}
                </p>
              </div>
            </div>

            {/* Key Metadata */}
            <div className="mt-5 grid grid-cols-1 gap-4 text-sm sm:grid-cols-3">
              <div>
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Reported Locality</p>
                <p className="mt-1 inline-flex items-center gap-1.5 font-semibold text-[var(--cp-text)]">
                  <MapPin className="h-3.5 w-3.5 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
                  {matchedIssue.locality}, {matchedIssue.city}
                </p>
              </div>
              <div>
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Submission Date</p>
                <time
                  dateTime={matchedIssue.createdAt}
                  className="mt-1 block font-mono-tabular font-semibold text-[var(--cp-text)]"
                >
                  {new Date(matchedIssue.createdAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </time>
              </div>
              <div>
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Latest Update</p>
                <time
                  dateTime={matchedIssue.updatedAt}
                  className="mt-1 block font-mono-tabular font-semibold text-[var(--cp-text)]"
                >
                  {new Date(matchedIssue.updatedAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </time>
              </div>
            </div>

            {/* 5-Stage Visual Progress Timeline */}
            <div className="mt-8 border-t border-[var(--cp-border)] pt-6">
              <h3 className="text-xs font-bold uppercase tracking-wide text-[var(--cp-text-muted)]">
                Resolution Progress Stages
              </h3>

              <ol
                aria-label="Complaint Progress Timeline"
                className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-5"
              >
                {ISSUE_STATUSES.map((stage, index) => {
                  const isCompleted = index < currentStageIndex;
                  const isCurrent = index === currentStageIndex;

                  return (
                    <li
                      key={stage}
                      className={`rounded-xl border p-4 transition-colors ${
                        isCurrent
                          ? 'border-[#159C91] bg-[var(--cp-accent-soft)]'
                          : isCompleted
                            ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/60 dark:bg-emerald-950/20'
                            : 'border-[var(--cp-border)] bg-[var(--cp-bg)] opacity-70'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono-tabular text-xs font-bold text-[var(--cp-text-muted)]">
                          0{index + 1}
                        </span>
                        {isCompleted ? (
                          <Check
                            className="h-4 w-4 text-emerald-600 dark:text-emerald-400"
                            aria-label="Completed"
                          />
                        ) : isCurrent ? (
                          <Clock
                            className="h-4 w-4 text-[#FF7657]"
                            aria-label="Current Stage"
                          />
                        ) : null}
                      </div>
                      <p className="mt-2.5 font-display text-sm font-bold text-[#172B45] dark:text-white">
                        {stage}
                      </p>
                      <p className="mt-0.5 text-[11px] font-medium text-[var(--cp-text-muted)]">
                        {isCompleted
                          ? 'Completed'
                          : isCurrent
                            ? 'Active Stage'
                            : 'Pending'}
                      </p>
                    </li>
                  );
                })}
              </ol>
            </div>
          </div>

          {/* Chronological Status History Log */}
          <div className="cp-card p-6 sm:p-8">
            <h3 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
              Detailed Status History &amp; Official Notes
            </h3>
            <ol className="mt-4 divide-y divide-[var(--cp-border)]">
              {[...matchedIssue.statusHistory].reverse().map((entry, idx) => (
                <li
                  key={`${entry.status}-${idx}`}
                  className="flex flex-col justify-between gap-2 py-4 sm:flex-row sm:items-start"
                >
                  <div>
                    <p className={`text-sm font-bold ${getStatusTextClass(entry.status)}`}>
                      {entry.status}
                    </p>
                    <p className="mt-1 text-sm text-[var(--cp-text)]">{entry.note}</p>
                    <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
                      Updated by: {entry.updatedBy}
                    </p>
                  </div>
                  <time
                    dateTime={entry.timestamp}
                    className="shrink-0 font-mono-tabular text-xs text-[var(--cp-text-muted)]"
                  >
                    {new Date(entry.timestamp).toLocaleString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </time>
                </li>
              ))}
            </ol>
          </div>
        </article>
      )}
    </div>
  );
}
