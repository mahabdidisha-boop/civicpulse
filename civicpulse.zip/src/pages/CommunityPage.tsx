import { useMemo, useState } from 'react';
import { MapPin, ThumbsUp, Users } from 'lucide-react';
import { IssueCard } from '../components/IssueCard';
import { CivicIssue, PageRoute } from '../types/issue';

interface CommunityPageProps {
  issues: CivicIssue[];
  votedIds: string[];
  onSelectIssue: (issue: CivicIssue) => void;
  onUpvote: (issueId: string) => void;
  onTrackIssue: (issueId: string) => void;
  onNavigate: (page: PageRoute) => void;
}

/**
 * Community Watch Page:
 * Enables residents to browse neighbour reports, support recurring issues (1 vote per issue),
 * see frequently supported problems, and review nearby locality impact.
 */
export function CommunityPage({
  issues,
  votedIds,
  onSelectIssue,
  onUpvote,
  onTrackIssue,
  onNavigate,
}: CommunityPageProps) {
  const [selectedLocalityFilter, setSelectedLocalityFilter] = useState<string>('All');

  const localities = useMemo(() => {
    const set = new Set(issues.map((i) => i.locality));
    return ['All', ...Array.from(set)];
  }, [issues]);

  const sortedBySupport = useMemo(() => {
    const list =
      selectedLocalityFilter === 'All'
        ? issues
        : issues.filter((i) => i.locality === selectedLocalityFilter);
    return [...list].sort((a, b) => b.upvotes - a.upvotes);
  }, [issues, selectedLocalityFilter]);

  const topFrequentIssues = useMemo(
    () => [...issues].filter((i) => i.status !== 'Resolved').sort((a, b) => b.upvotes - a.upvotes).slice(0, 3),
    [issues]
  );

  const totalVotes = issues.reduce((sum, i) => sum + i.upvotes, 0);
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;

  return (
    <div className="space-y-10 py-10">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--cp-border)] pb-6">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
            Civic Collaboration
          </p>
          <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl">
            Community Neighbourhood Watch
          </h1>
          <p className="mt-1.5 text-sm sm:text-base text-[var(--cp-text-muted)]">
            Support reports in your locality to signal recurring infrastructure priorities. One
            support vote is permitted per issue per verified account.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('report')}
          className="cp-btn-primary px-5 py-2.5 text-sm whitespace-nowrap min-h-[44px]"
        >
          Add Neighbourhood Report
        </button>
      </div>

      {/* Community Impact Summary */}
      <section aria-label="Community Impact Statistics" className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div className="cp-card p-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-[var(--cp-text-muted)]">
            <Users className="h-4 w-4 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
            <span>Active Neighbourhood Reports</span>
          </div>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#172B45] dark:text-white tabular-nums">
            {issues.length - resolvedCount}
          </p>
        </div>

        <div className="cp-card p-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-[var(--cp-text-muted)]">
            <ThumbsUp className="h-4 w-4 text-[#FF7657]" aria-hidden="true" />
            <span>Combined Community Supports</span>
          </div>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#172B45] dark:text-white tabular-nums">
            {totalVotes}
          </p>
        </div>

        <div className="cp-card p-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-[var(--cp-text-muted)]">
            <MapPin className="h-4 w-4 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
            <span>Your Supported Issues</span>
          </div>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#0F7E75] dark:text-[#2DD4BF] tabular-nums">
            {votedIds.length}
          </p>
        </div>
      </section>

      {/* Frequently Reported / Top Supported Issues */}
      <section aria-labelledby="frequent-issues-heading">
        <h2
          id="frequent-issues-heading"
          className="font-display text-2xl font-extrabold text-[#172B45] dark:text-white"
        >
          Most Supported Active Issues
        </h2>
        <p className="mt-1 text-sm text-[var(--cp-text-muted)]">
          Unresolved issues receiving the highest citizen support across urban neighbourhoods.
        </p>

        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-3">
          {topFrequentIssues.map((issue, index) => {
            const hasVoted = votedIds.includes(issue.id);
            return (
              <article key={issue.id} className="cp-card cp-card-interactive flex flex-col justify-between p-6">
                <div>
                  <p className="font-mono-tabular text-xs font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
                    0{index + 1}. {issue.locality}, {issue.city}
                  </p>
                  <h3 className="mt-2 font-display text-base font-bold text-[#172B45] dark:text-white">
                    <button
                      type="button"
                      onClick={() => onSelectIssue(issue)}
                      className="text-left hover:text-[#0F7E75] dark:hover:text-[#2DD4BF] transition-colors"
                    >
                      {issue.title}
                    </button>
                  </h3>
                  <p className="mt-1.5 text-xs text-[var(--cp-text-muted)]">
                    {issue.category} · {issue.status}
                  </p>
                </div>

                <div className="mt-5 flex items-center justify-between border-t border-[var(--cp-border)] pt-3.5">
                  <button
                    type="button"
                    onClick={() => onUpvote(issue.id)}
                    disabled={hasVoted}
                    className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                      hasVoted
                        ? 'border-[#159C91] bg-[var(--cp-accent-soft)] text-[#0F7E75] dark:text-[#2DD4BF]'
                        : 'border-[var(--cp-border)] bg-[var(--cp-bg)] text-[var(--cp-text)] hover:border-[#159C91]'
                    }`}
                  >
                    <ThumbsUp className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="tabular-nums">
                      {hasVoted ? 'Supported' : 'Support'} ({issue.upvotes})
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTrackIssue(issue.id)}
                    className="text-xs font-bold text-[#172B45] dark:text-[#2DD4BF] hover:underline"
                  >
                    Track {issue.id}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Locality Filter + Full Community Feed */}
      <section aria-labelledby="community-feed-heading" className="space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2
            id="community-feed-heading"
            className="font-display text-2xl font-extrabold text-[#172B45] dark:text-white"
          >
            Browse by Neighbourhood
          </h2>

          <div className="flex items-center gap-2.5">
            <label
              htmlFor="community-locality-select"
              className="text-xs font-bold text-[var(--cp-text-muted)]"
            >
              Filter Locality:
            </label>
            <select
              id="community-locality-select"
              value={selectedLocalityFilter}
              onChange={(e) => setSelectedLocalityFilter(e.target.value)}
              className="rounded-lg border border-[var(--cp-border)] bg-[var(--cp-surface)] px-3.5 py-2 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
            >
              {localities.map((loc) => (
                <option key={loc} value={loc}>
                  {loc === 'All' ? 'All Localities' : loc}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {sortedBySupport.map((issue) => (
            <IssueCard
              key={issue.id}
              issue={issue}
              hasVoted={votedIds.includes(issue.id)}
              onSelect={onSelectIssue}
              onUpvote={onUpvote}
              onTrack={onTrackIssue}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
