import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import {
  AlertTriangle,
  CheckCircle2,
  Cloud,
  ImagePlus,
  Loader2,
  LogIn,
  MapPin,
  Trash2,
} from 'lucide-react';
import { IssuesMap } from '../components/IssuesMap';
import { VideoAnimatorCard } from '../components/VideoAnimatorCard';
import { LOCALITY_PRESETS } from '../data/sampleIssues';
import {
  findPotentialDuplicates,
  suggestIssuePriority,
} from '../services/issueStorage';
import {
  CivicIssue,
  ISSUE_CATEGORIES,
  ISSUE_PRIORITIES,
  IssueCategory,
  IssuePriority,
  PageRoute,
} from '../types/issue';

interface ReportPageProps {
  existingIssues: CivicIssue[];
  votedIds: string[];
  user: User | null;
  onSignIn: () => void;
  onSubmitIssue: (payload: {
    title: string;
    category: IssueCategory;
    description: string;
    locality: string;
    city: string;
    latitude: number;
    longitude: number;
    priority: IssuePriority;
    imageUrl?: string;
  }) => CivicIssue;
  onUpvote: (issueId: string) => void;
  onNavigate: (page: PageRoute) => void;
  onTrackIssue: (issueId: string) => void;
}

/**
 * Compress an uploaded image DataURL via canvas so it stays comfortably
 * under Firestore's 150,000-char imageUrl rule limit while preserving clarity.
 */
async function compressImageDataUrl(dataUrl: string): Promise<string> {
  if (dataUrl.length <= 135000) return dataUrl;

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const maxDim = 900;
      let width = img.naturalWidth || img.width;
      let height = img.naturalHeight || img.height;

      if (width > maxDim || height > maxDim) {
        if (width >= height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      let compressed = canvas.toDataURL('image/jpeg', 0.72);
      if (compressed.length > 140000) {
        compressed = canvas.toDataURL('image/jpeg', 0.5);
      }
      resolve(compressed);
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

/**
 * Report an Issue Page:
 * Semantic HTML5 <form> featuring live duplicate detection, automatic priority suggestion,
 * interactive Google Map pin selection, image compression + preview,
 * embedded Photo-to-Video Animation Studio, and Cloud Firestore sync when signed in.
 */
export function ReportPage({
  existingIssues,
  votedIds,
  user,
  onSignIn,
  onSubmitIssue,
  onUpvote,
  onNavigate,
  onTrackIssue,
}: ReportPageProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Road damage / Potholes');
  const [description, setDescription] = useState('');
  const [locality, setLocality] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [coordinates, setCoordinates] = useState<{ latitude: number; longitude: number }>({
    latitude: 12.9784,
    longitude: 77.6408,
  });
  const [showMapPicker, setShowMapPicker] = useState(false);

  const [priority, setPriority] = useState<IssuePriority>('Medium');
  const [priorityManuallyEdited, setPriorityManuallyEdited] = useState(false);

  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | undefined>(undefined);
  const [compressedImageUrl, setCompressedImageUrl] = useState<string | undefined>(undefined);
  const [imageError, setImageError] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedIssue, setSubmittedIssue] = useState<CivicIssue | null>(null);

  // Automatically suggest priority unless the user manually picked a priority level
  const suggestedPriority = useMemo(
    () => suggestIssuePriority(category, title, description),
    [category, title, description]
  );

  useEffect(() => {
    if (!priorityManuallyEdited) {
      setPriority(suggestedPriority);
    }
  }, [suggestedPriority, priorityManuallyEdited]);

  // Smart Duplicate Issue Detection
  const potentialDuplicates = useMemo(
    () => findPotentialDuplicates(existingIssues, locality, category, title),
    [existingIssues, locality, category, title]
  );

  const handlePresetLocalityChange = (presetName: string) => {
    const match = LOCALITY_PRESETS.find((item) => item.name === presetName);
    if (match) {
      setLocality(match.name);
      setCity(match.city);
      setCoordinates({ latitude: match.latitude, longitude: match.longitude });
    }
  };

  const handleImageUpload = (event: ChangeEvent<HTMLInputElement>) => {
    setImageError(null);
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setImageError('Please select a valid image file (PNG, JPG, or WebP).');
      return;
    }

    if (file.size > 6 * 1024 * 1024) {
      setImageError('Please choose an image smaller than 6 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      if (typeof reader.result === 'string') {
        const rawUrl = reader.result;
        setImagePreviewUrl(rawUrl);
        const compressed = await compressImageDataUrl(rawUrl);
        setCompressedImageUrl(compressed);
      }
    };
    reader.readAsDataURL(file);
  };

  const validateForm = (): boolean => {
    const nextErrors: Record<string, string> = {};

    if (title.trim().length < 6) {
      nextErrors.title = 'Please enter a concise issue title (at least 6 characters).';
    }
    if (description.trim().length < 15) {
      nextErrors.description =
        'Please describe the location landmark and condition (at least 15 characters).';
    }
    if (locality.trim().length < 3) {
      nextErrors.locality = 'Please specify the neighbourhood or locality name.';
    }
    if (city.trim().length < 2) {
      nextErrors.city = 'Please enter the city name.';
    }

    setFormErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);

    setTimeout(() => {
      const created = onSubmitIssue({
        title: title.trim(),
        category,
        description: description.trim(),
        locality: locality.trim(),
        city: city.trim(),
        latitude: coordinates.latitude,
        longitude: coordinates.longitude,
        priority,
        imageUrl: compressedImageUrl || imagePreviewUrl,
      });

      setSubmittedIssue(created);
      setIsSubmitting(false);
      setTitle('');
      setDescription('');
      setImagePreviewUrl(undefined);
      setCompressedImageUrl(undefined);
      setPriorityManuallyEdited(false);
      setFormErrors({});
    }, 300);
  };

  // Submission Confirmation State
  if (submittedIssue) {
    return (
      <section
        aria-labelledby="submission-success-heading"
        className="mx-auto max-w-2xl py-12"
      >
        <div className="cp-card p-8 text-center">
          <CheckCircle2
            className="mx-auto h-12 w-12 text-emerald-600 dark:text-emerald-400"
            aria-hidden="true"
          />
          <h1
            id="submission-success-heading"
            className="mt-4 font-display text-2xl font-bold text-[#102A43] dark:text-white"
          >
            Complaint Submitted Successfully
          </h1>
          <p className="mt-2 text-sm text-[var(--cp-text-muted)]">
            {user
              ? 'Your report has been synced to Cloud Firestore and is visible across the dashboard, explorer map, and complaint tracker.'
              : 'Your report has been saved to your local browser session and is visible across the dashboard, explorer map, and complaint tracker.'}
          </p>

          <div className="mt-6 rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] p-5">
            <p className="text-xs font-medium text-[var(--cp-text-muted)]">
              Unique Complaint Tracking ID
            </p>
            <p className="mt-1 font-mono-tabular text-2xl font-bold text-[#0D9488] dark:text-[#14B8A6]">
              {submittedIssue.id}
            </p>
            <p className="mt-2 text-xs text-[var(--cp-text-muted)]">
              {submittedIssue.category} · {submittedIssue.locality}, {submittedIssue.city} ·{' '}
              {submittedIssue.priority} Priority
            </p>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => onTrackIssue(submittedIssue.id)}
              className="rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] transition-colors"
            >
              Track This Complaint
            </button>
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="rounded-md border border-[var(--cp-border)] px-5 py-2.5 text-sm font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors"
            >
              View on Dashboard
            </button>
            <button
              type="button"
              onClick={() => setSubmittedIssue(null)}
              className="rounded-md px-4 py-2.5 text-sm font-medium text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]"
            >
              Submit Another Report
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-8 py-8">
      <div className="border-b border-[var(--cp-border)] pb-5">
        <h1 className="font-display text-2xl font-bold text-[#102A43] dark:text-white sm:text-3xl">
          Report a Neighbourhood Issue
        </h1>
        <p className="mt-1 text-sm text-[var(--cp-text-muted)]">
          Document local infrastructure issues clearly. Avoid entering personal phone numbers,
          emails, or exact house numbers.
        </p>
      </div>

      {/* Cloud Persistence Sign-In Banner */}
      {!user ? (
        <aside
          aria-label="Cloud persistence account notice"
          className="flex flex-wrap items-center justify-between gap-4 rounded-[10px] border border-[var(--cp-border)] bg-[var(--cp-accent-soft)] px-5 py-4 text-xs"
        >
          <div className="flex items-start gap-2.5">
            <Cloud
              className="mt-0.5 h-4 w-4 shrink-0 text-[#0D9488] dark:text-[#14B8A6]"
              aria-hidden="true"
            />
            <p className="text-[var(--cp-text)] leading-relaxed">
              Sign in with Google to save reports directly to <strong>Cloud Firestore</strong>{' '}
              across sessions. Without signing in, your report is saved locally in this browser.
            </p>
          </div>
          <button
            type="button"
            onClick={onSignIn}
            className="inline-flex items-center gap-1.5 rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-3.5 py-2 text-xs font-semibold text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] transition-colors whitespace-nowrap"
          >
            <LogIn className="h-3.5 w-3.5" aria-hidden="true" />
            Sign In with Google
          </button>
        </aside>
      ) : (
        <aside
          aria-label="Cloud persistence active"
          className="flex items-center gap-2.5 rounded-[10px] border border-[#14B8A6]/40 bg-[var(--cp-accent-soft)] px-4 py-3 text-xs text-[var(--cp-text)]"
        >
          <Cloud
            className="h-4 w-4 shrink-0 text-[#0D9488] dark:text-[#14B8A6]"
            aria-hidden="true"
          />
          <span>
            Signed in as <strong>{user.displayName || user.email}</strong> — reports submitted
            here sync live to Cloud Firestore.
          </span>
        </aside>
      )}

      {/* Smart Duplicate Detection Advisory */}
      {potentialDuplicates.length > 0 && (
        <aside
          aria-label="Similar Existing Issues"
          className="rounded-[10px] border border-amber-300 dark:border-amber-700 bg-amber-50/70 dark:bg-amber-950/30 p-5"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle
              className="mt-0.5 h-5 w-5 shrink-0 text-amber-700 dark:text-amber-400"
              aria-hidden="true"
            />
            <div className="flex-1">
              <h2 className="font-display text-sm font-semibold text-[#102A43] dark:text-white">
                Similar Issue Already Reported in {locality}
              </h2>
              <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
                Supporting an existing report helps highlight recurring issues without creating
                duplicates. You can still continue submitting if your location is different.
              </p>

              <ul className="mt-3 space-y-2">
                {potentialDuplicates.slice(0, 3).map((match) => {
                  const alreadyVoted = votedIds.includes(match.id);
                  return (
                    <li
                      key={match.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-3.5 py-2.5 text-xs"
                    >
                      <div>
                        <span className="font-mono-tabular font-semibold text-[#102A43] dark:text-white">
                          {match.id}
                        </span>
                        <span className="mx-1.5 text-[var(--cp-text-muted)]">·</span>
                        <span className="font-medium text-[var(--cp-text)]">{match.title}</span>
                        <span className="ml-2 text-[var(--cp-text-muted)]">({match.status})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onUpvote(match.id)}
                          disabled={alreadyVoted}
                          className="rounded border border-[var(--cp-border)] px-2.5 py-1 font-medium text-[#0D9488] dark:text-[#14B8A6] hover:bg-[var(--cp-accent-soft)] disabled:opacity-60"
                        >
                          {alreadyVoted ? 'Supported' : `Support (${match.upvotes})`}
                        </button>
                        <button
                          type="button"
                          onClick={() => onTrackIssue(match.id)}
                          className="font-medium text-[#102A43] dark:text-white underline"
                        >
                          Track
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </aside>
      )}

      {/* Semantic HTML5 Reporting Form */}
      <form
        onSubmit={handleSubmit}
        noValidate
        className="cp-card space-y-6 p-6 sm:p-8"
      >
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {/* Issue Title */}
          <div className="sm:col-span-2">
            <label
              htmlFor="issue-title"
              className="block text-sm font-medium text-[#102A43] dark:text-white"
            >
              Issue Title <span className="text-rose-600">*</span>
            </label>
            <input
              id="issue-title"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Deep pothole near bus bay causing traffic slowdown"
              className="mt-1.5 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            />
            {formErrors.title && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400" role="alert">
                {formErrors.title}
              </p>
            )}
          </div>

          {/* Issue Category */}
          <div>
            <label
              htmlFor="issue-category"
              className="block text-sm font-medium text-[#102A43] dark:text-white"
            >
              Issue Category <span className="text-rose-600">*</span>
            </label>
            <select
              id="issue-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as IssueCategory)}
              className="mt-1.5 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            >
              {ISSUE_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Classification */}
          <div>
            <div className="flex items-center justify-between gap-2">
              <label
                htmlFor="issue-priority"
                className="block text-sm font-medium text-[#102A43] dark:text-white"
              >
                Issue Priority
              </label>
              <span className="text-xs text-[#0D9488] dark:text-[#14B8A6]">
                Suggested: {suggestedPriority}
              </span>
            </div>
            <select
              id="issue-priority"
              value={priority}
              onChange={(e) => {
                setPriority(e.target.value as IssuePriority);
                setPriorityManuallyEdited(true);
              }}
              className="mt-1.5 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            >
              {ISSUE_PRIORITIES.map((level) => (
                <option key={level} value={level}>
                  {level} Priority
                </option>
              ))}
            </select>
          </div>

          {/* Locality Preset Quick Fill + Manual Locality Input */}
          <div>
            <label
              htmlFor="issue-locality"
              className="block text-sm font-medium text-[#102A43] dark:text-white"
            >
              Locality / Area Name <span className="text-rose-600">*</span>
            </label>
            <input
              id="issue-locality"
              type="text"
              required
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              placeholder="e.g., Indiranagar 100 Feet Road"
              list="indian-locality-presets"
              className="mt-1.5 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            />
            <datalist id="indian-locality-presets">
              {LOCALITY_PRESETS.map((preset) => (
                <option key={preset.name} value={preset.name} />
              ))}
            </datalist>
            {formErrors.locality && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400" role="alert">
                {formErrors.locality}
              </p>
            )}
          </div>

          {/* City + Quick Preset Selector */}
          <div>
            <label
              htmlFor="issue-city"
              className="block text-sm font-medium text-[#102A43] dark:text-white"
            >
              City <span className="text-rose-600">*</span>
            </label>
            <div className="mt-1.5 flex gap-2">
              <input
                id="issue-city"
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g., Bengaluru"
                className="w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
              />
              <select
                aria-label="Quick select Indian urban locality preset"
                onChange={(e) => handlePresetLocalityChange(e.target.value)}
                defaultValue=""
                className="rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-2.5 py-2 text-xs text-[var(--cp-text)]"
              >
                <option value="" disabled>
                  Preset area…
                </option>
                {LOCALITY_PRESETS.map((preset) => (
                  <option key={preset.name} value={preset.name}>
                    {preset.city} — {preset.name}
                  </option>
                ))}
              </select>
            </div>
            {formErrors.city && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400" role="alert">
                {formErrors.city}
              </p>
            )}
          </div>

          {/* Detailed Description */}
          <div className="sm:col-span-2">
            <label
              htmlFor="issue-description"
              className="block text-sm font-medium text-[#102A43] dark:text-white"
            >
              Detailed Description <span className="text-rose-600">*</span>
            </label>
            <textarea
              id="issue-description"
              rows={4}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the nearby public landmark, severity, and how it affects pedestrians or commuters. Do not include personal residential addresses."
              className="mt-1.5 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3.5 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            />
            {formErrors.description && (
              <p className="mt-1 text-xs text-rose-600 dark:text-rose-400" role="alert">
                {formErrors.description}
              </p>
            )}
          </div>
        </div>

        {/* Optional Interactive Map Location Picker */}
        <div className="border-t border-[var(--cp-border)] pt-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-[#102A43] dark:text-white">
                Optional Map Pin Location
              </p>
              <p className="font-mono-tabular text-xs text-[var(--cp-text-muted)]">
                Selected Coordinates: {coordinates.latitude.toFixed(4)},{' '}
                {coordinates.longitude.toFixed(4)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowMapPicker((prev) => !prev)}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] px-3.5 py-2 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors"
            >
              <MapPin className="h-3.5 w-3.5 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
              {showMapPicker ? 'Hide Map Picker' : 'Pick Location on Map'}
            </button>
          </div>

          {showMapPicker && (
            <div className="mt-4 space-y-2">
              <p className="text-xs text-[var(--cp-text-muted)]">
                Click anywhere on the interactive map below to place the approximate street pin.
              </p>
              <IssuesMap
                mode="pick"
                selectedCoordinates={coordinates}
                onPickLocation={(lat, lng) => setCoordinates({ latitude: lat, longitude: lng })}
                heightClass="h-[300px]"
              />
            </div>
          )}
        </div>

        {/* Photographic Evidence Upload with Live Preview */}
        <div className="border-t border-[var(--cp-border)] pt-5">
          <label
            htmlFor="issue-image-upload"
            className="block text-sm font-medium text-[#102A43] dark:text-white"
          >
            Photographic Evidence (Optional)
          </label>
          <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
            Attach a clear photo of the street or infrastructure issue (JPG/PNG/WebP, max 6 MB;
            automatically optimized for storage).
          </p>

          <div className="mt-3 flex flex-wrap items-center gap-4">
            <label
              htmlFor="issue-image-upload"
              className="inline-flex cursor-pointer items-center gap-2 rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-4 py-2.5 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors"
            >
              <ImagePlus className="h-4 w-4 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
              Choose Image File
            </label>
            <input
              id="issue-image-upload"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="sr-only"
            />

            {imagePreviewUrl && (
              <button
                type="button"
                onClick={() => {
                  setImagePreviewUrl(undefined);
                  setCompressedImageUrl(undefined);
                }}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 hover:underline"
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                Remove Photo
              </button>
            )}
          </div>

          {imageError && (
            <p className="mt-2 text-xs text-rose-600 dark:text-rose-400" role="alert">
              {imageError}
            </p>
          )}

          {imagePreviewUrl && (
            <figure className="mt-4 max-w-sm overflow-hidden rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)]">
              <img
                src={imagePreviewUrl}
                alt="Preview of uploaded civic issue evidence"
                className="max-h-56 w-full object-cover"
              />
              <figcaption className="border-t border-[var(--cp-border)] px-3 py-1.5 text-xs text-[var(--cp-text-muted)]">
                Image preview ready for submission
              </figcaption>
            </figure>
          )}
        </div>

        {/* Submit Button Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[var(--cp-border)] pt-6">
          <p className="text-xs text-[var(--cp-text-muted)]">
            {user
              ? 'Submitted directly to Cloud Firestore.'
              : 'Saved locally in your browser demonstration workspace.'}
          </p>
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-6 py-3 text-sm font-semibold text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] transition-colors disabled:opacity-60 min-h-[44px]"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                Submitting Report…
              </>
            ) : (
              'Submit Civic Report'
            )}
          </button>
        </div>
      </form>

      {/* Embedded Photo-to-Video Animation Studio */}
      <VideoAnimatorCard
        key={imagePreviewUrl ? imagePreviewUrl.slice(0, 64) : 'standalone'}
        initialImageDataUrl={imagePreviewUrl}
        defaultPrompt={
          title.trim()
            ? `Slow, steady civic documentation pan showing ${title.trim()} in natural daylight.`
            : undefined
        }
      />
    </div>
  );
}

