import { ArrowRight } from 'lucide-react';
import { IssuesChart } from '../components/IssuesChart';
import { getStatusTextClass } from '../components/IssueCard';
import { CivicIssue, ISSUE_CATEGORIES, PageRoute } from '../types/issue';

interface DashboardPageProps {
  issues: CivicIssue[];
  isDark: boolean;
  onNavigate: (page: PageRoute) => void;
  onSelectIssue: (issue: CivicIssue) => void;
}

/**
 * Citizen Dashboard:
 * Displays summary counts, Chart.js analytics by category and status,
 * neighbourhood breakdown table, and recent activity feed.
 */
export function DashboardPage({
  issues,
  isDark,
  onNavigate,
  onSelectIssue,
}: DashboardPageProps) {
  const totalIssues = issues.length;
  const resolvedIssues = issues.filter((i) => i.status === 'Resolved').length;
  const inProgressIssues = issues.filter((i) => i.status === 'In Progress').length;
  const pendingIssues = issues.filter(
    (i) => i.status === 'Submitted' || i.status === 'Under Review' || i.status === 'Verified'
  ).length;

  // Category-wise aggregation for Chart.js bar chart
  const categoryLabels = ISSUE_CATEGORIES.map((cat) =>
    cat.length > 22 ? `${cat.slice(0, 20)}…` : cat
  );
  const categoryValues = ISSUE_CATEGORIES.map(
    (cat) => issues.filter((issue) => issue.category === cat).length
  );

  // Status distribution for Chart.js doughnut chart
  const statusLabels = ['Submitted', 'Under Review', 'Verified', 'In Progress', 'Resolved'];
  const statusValues = statusLabels.map(
    (status) => issues.filter((issue) => issue.status === status).length
  );

  // Neighbourhood aggregation
  const localityMap = new Map<
    string,
    { locality: string; city: string; total: number; resolved: number; active: number }
  >();

  for (const issue of issues) {
    const key = `${issue.locality}|${issue.city}`;
    const existing = localityMap.get(key) ?? {
      locality: issue.locality,
      city: issue.city,
      total: 0,
      resolved: 0,
      active: 0,
    };
    existing.total += 1;
    if (issue.status === 'Resolved') {
      existing.resolved += 1;
    } else {
      existing.active += 1;
    }
    localityMap.set(key, existing);
  }

  const localityStats = Array.from(localityMap.values()).sort((a, b) => b.total - a.total);
  const recentActivity = [...issues]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 6);

  return (
    <div className="space-y-10 py-10">
      {/* Page Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--cp-border)] pb-6">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
            Civic Analytics
          </p>
          <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl">
            Citizen Infrastructure Dashboard
          </h1>
          <p className="mt-1.5 text-sm sm:text-base text-[var(--cp-text-muted)]">
            Live overview of demonstration records and reports persisted across neighbourhoods.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('report')}
          className="cp-btn-primary inline-flex items-center gap-2 px-5 py-2.5 text-sm whitespace-nowrap min-h-[44px]"
        >
          Report New Issue
          <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>

      {/* KPI Metrics Grid */}
      <section aria-label="Dashboard Summary Metrics" className="grid grid-cols-2 gap-5 lg:grid-cols-4">
        <div className="cp-card p-6">
          <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Total Reported Issues</p>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#172B45] dark:text-white tabular-nums">
            {totalIssues}
          </p>
        </div>
        <div className="cp-card p-6">
          <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Resolved Issues</p>
          <p className="mt-2 font-display text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
            {resolvedIssues}
          </p>
        </div>
        <div className="cp-card p-6">
          <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Pending Complaints</p>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#D64026] dark:text-[#FF7657] tabular-nums">
            {pendingIssues}
          </p>
        </div>
        <div className="cp-card p-6">
          <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Currently In Progress</p>
          <p className="mt-2 font-display text-3xl font-extrabold text-[#0F7E75] dark:text-[#2DD4BF] tabular-nums">
            {inProgressIssues}
          </p>
        </div>
      </section>

      {/* Chart.js Visual Analytics Section */}
      <section aria-labelledby="analytics-heading" className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="cp-card p-6 sm:p-7 lg:col-span-7">
          <h2
            id="analytics-heading"
            className="font-display text-lg font-bold text-[#172B45] dark:text-white"
          >
            Category-Wise Issue Distribution
          </h2>
          <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
            Number of logged civic complaints grouped across the eight infrastructure categories.
          </p>
          <div className="mt-6">
            <IssuesChart
              type="bar"
              horizontal
              labels={categoryLabels}
              values={categoryValues}
              datasetLabel="Reports"
              isDark={isDark}
              heightClass="h-72"
            />
          </div>
        </div>

        <div className="cp-card p-6 sm:p-7 lg:col-span-5">
          <h2 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
            Resolution Stage Breakdown
          </h2>
          <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
            Current distribution across the 5-stage tracking lifecycle.
          </p>
          <div className="mt-6">
            <IssuesChart
              type="doughnut"
              labels={statusLabels}
              values={statusValues}
              datasetLabel="Complaints"
              colors={['#4B5E76', '#E09F3E', '#159C91', '#FF7657', '#16A34A']}
              isDark={isDark}
              heightClass="h-72"
            />
          </div>
        </div>
      </section>

      {/* Neighbourhood Activity & Recent Feed */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Locality Summary Table */}
        <div className="cp-card overflow-hidden lg:col-span-7">
          <div className="border-b border-[var(--cp-border)] px-6 py-4.5">
            <h2 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
              Neighbourhood Activity Summary
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-[var(--cp-border)] bg-[var(--cp-bg)] text-xs text-[var(--cp-text-muted)]">
                <tr>
                  <th className="px-6 py-3.5 font-bold">Locality</th>
                  <th className="px-4 py-3.5 font-bold">City</th>
                  <th className="px-4 py-3.5 text-right font-bold">Total</th>
                  <th className="px-4 py-3.5 text-right font-bold">Active</th>
                  <th className="px-6 py-3.5 text-right font-bold">Resolved</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--cp-border)]">
                {localityStats.map((row) => (
                  <tr
                    key={`${row.locality}-${row.city}`}
                    className="hover:bg-[var(--cp-accent-soft)]/50 transition-colors"
                  >
                    <td className="px-6 py-3.5 font-semibold text-[#172B45] dark:text-white">
                      {row.locality}
                    </td>
                    <td className="px-4 py-3.5 text-[var(--cp-text-muted)]">{row.city}</td>
                    <td className="px-4 py-3.5 text-right font-mono-tabular font-semibold">{row.total}</td>
                    <td className="px-4 py-3.5 text-right font-mono-tabular font-semibold text-[#D64026] dark:text-[#FF7657]">
                      {row.active}
                    </td>
                    <td className="px-6 py-3.5 text-right font-mono-tabular font-semibold text-emerald-700 dark:text-emerald-400">
                      {row.resolved}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activity List */}
        <div className="cp-card overflow-hidden lg:col-span-5">
          <div className="border-b border-[var(--cp-border)] px-6 py-4.5">
            <h2 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
              Recent Activity
            </h2>
          </div>
          <ul className="divide-y divide-[var(--cp-border)]">
            {recentActivity.map((issue) => (
              <li key={issue.id}>
                <button
                  type="button"
                  onClick={() => onSelectIssue(issue)}
                  className="w-full px-6 py-4 text-left hover:bg-[var(--cp-accent-soft)]/50 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 text-xs text-[var(--cp-text-muted)]">
                    <span className="font-mono-tabular font-semibold text-[var(--cp-text)]">
                      {issue.id}
                    </span>
                    <span className={`font-bold ${getStatusTextClass(issue.status)}`}>
                      {issue.status}
                    </span>
                  </div>
                  <p className="mt-1 truncate text-sm font-bold text-[#172B45] dark:text-white">
                    {issue.title}
                  </p>
                  <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
                    {issue.locality}, {issue.city} · Updated{' '}
                    {new Date(issue.updatedAt).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </p>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
