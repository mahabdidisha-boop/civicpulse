import { FormEvent, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import { Database, ImageOff, Info, LogIn, Search } from 'lucide-react';
import { getPriorityTextClass, getStatusTextClass } from '../components/IssueCard';
import { IssuesChart } from '../components/IssuesChart';
import {
  CivicIssue,
  ISSUE_CATEGORIES,
  ISSUE_STATUSES,
  IssueCategory,
  IssueStatus,
} from '../types/issue';

interface AdminPageProps {
  issues: CivicIssue[];
  isDark: boolean;
  user: User | null;
  isAdmin: boolean;
  onSignIn: () => void;
  onSeedDemoIssues: () => Promise<void>;
  onUpdateStatus: (issue: CivicIssue, newStatus: IssueStatus, note: string) => Promise<void>;
  onMarkDuplicate: (issue: CivicIssue, duplicateOfId: string) => Promise<void>;
}

/**
 * Demonstration Administrator Console:
 * Protected by Firebase Auth & Firestore security rules (admin email or /admins/{uid}).
 */
export function AdminPage({
  issues,
  isDark,
  user,
  isAdmin,
  onSignIn,
  onSeedDemoIssues,
  onUpdateStatus,
  onMarkDuplicate,
}: AdminPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | IssueStatus>('All');
  const [categoryFilter, setCategoryFilter] = useState<'All' | IssueCategory>('All');

  const [selectedId, setSelectedId] = useState<string>(issues[0]?.id ?? '');
  const [nextStatus, setNextStatus] = useState<IssueStatus>('Under Review');
  const [progressNote, setProgressNote] = useState('');
  const [duplicateTargetId, setDuplicateTargetId] = useState('');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);
  const [imgError, setImgError] = useState(false);

  const filteredIssues = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return issues.filter((issue) => {
      if (statusFilter !== 'All' && issue.status !== statusFilter) return false;
      if (categoryFilter !== 'All' && issue.category !== categoryFilter) return false;
      if (q) {
        const text = `${issue.id} ${issue.title} ${issue.locality} ${issue.city}`.toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [issues, searchQuery, statusFilter, categoryFilter]);

  const selectedIssue =
    issues.find((item) => item.id === selectedId) ?? filteredIssues[0] ?? null;

  const handleSelectRow = (issue: CivicIssue) => {
    setSelectedId(issue.id);
    setNextStatus(issue.status);
    setProgressNote('');
    setDuplicateTargetId(issue.duplicateOfId ?? '');
    setActionFeedback(null);
    setImgError(false);
  };

  const handleStatusSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedIssue || !isAdmin) return;

    setIsBusy(true);
    try {
      await onUpdateStatus(selectedIssue, nextStatus, progressNote);
      setProgressNote('');
      setActionFeedback(`Updated ${selectedIssue.id} to "${nextStatus}" in Cloud Firestore.`);
    } catch (err) {
      setActionFeedback(
        err instanceof Error ? err.message : 'Unable to update status in Firestore.'
      );
    } finally {
      setIsBusy(false);
    }
  };

  const handleDuplicateSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedIssue || !duplicateTargetId.trim() || !isAdmin) return;
    if (duplicateTargetId.trim() === selectedIssue.id) {
      setActionFeedback('Cannot mark a complaint as a duplicate of itself.');
      return;
    }

    setIsBusy(true);
    try {
      await onMarkDuplicate(selectedIssue, duplicateTargetId.trim().toUpperCase());
      setActionFeedback(
        `Marked ${selectedIssue.id} as a duplicate reference of ${duplicateTargetId
          .trim()
          .toUpperCase()}.`
      );
    } catch (err) {
      setActionFeedback(
        err instanceof Error ? err.message : 'Unable to mark duplicate in Firestore.'
      );
    } finally {
      setIsBusy(false);
    }
  };

  const handleSeedClick = async () => {
    setIsBusy(true);
    try {
      await onSeedDemoIssues();
      setActionFeedback('Sample Indian urban locality issues synced to Cloud Firestore.');
    } catch (err) {
      setActionFeedback(
        err instanceof Error ? err.message : 'Unable to seed sample issues.'
      );
    } finally {
      setIsBusy(false);
    }
  };

  const localityFrequency = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const item of issues) {
      const label = `${item.locality}, ${item.city}`;
      counts[label] = (counts[label] ?? 0) + 1;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1]);
  }, [issues]);

  return (
    <div className="space-y-8 py-10">
      {/* Header + Honest Demonstration Banner */}
      <div className="space-y-5 border-b border-[var(--cp-border)] pb-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
              Moderation &amp; Status Controls
            </p>
            <h1 className="mt-1 font-display text-3xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl">
              Demonstration Admin Console
            </h1>
            <p className="mt-1.5 text-sm sm:text-base text-[var(--cp-text-muted)]">
              Review citizen complaints, inspect attached photographs, update progress milestones,
              and manage duplicate records in Cloud Firestore.
            </p>
          </div>

          {isAdmin && (
            <button
              type="button"
              onClick={handleSeedClick}
              disabled={isBusy}
              className="cp-btn-secondary inline-flex items-center gap-2 px-4 py-2 text-xs disabled:opacity-60"
            >
              <Database className="h-3.5 w-3.5 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
              Sync Sample Records to Firestore
            </button>
          )}
        </div>

        <aside
          aria-label="Demonstration Environment Notice"
          className="flex flex-wrap items-center justify-between gap-3 rounded-[14px] border border-[#159C91]/35 bg-[var(--cp-accent-soft)] p-4 text-xs text-[var(--cp-text)]"
        >
          <div className="flex items-start gap-3">
            <Info
              className="mt-0.5 h-4 w-4 shrink-0 text-[#0F7E75] dark:text-[#2DD4BF]"
              aria-hidden="true"
            />
            <p className="leading-relaxed">
              <strong>Firestore Security Enforcement:</strong> Status updates and duplicate flags are
              authorized exclusively for verified administrator accounts via Firestore Security
              Rules. Demonstration actions here do not transmit complaints to an external municipal
              agency.
            </p>
          </div>

          {!user ? (
            <button
              type="button"
              onClick={onSignIn}
              className="cp-btn-primary inline-flex items-center gap-1.5 px-4 py-2 text-xs whitespace-nowrap"
            >
              <LogIn className="h-3.5 w-3.5" aria-hidden="true" />
              Sign in as Admin
            </button>
          ) : !isAdmin ? (
            <span className="font-semibold text-[#D64026] dark:text-[#FF7657]">
              Signed in as {user.email} (Read-Only Citizen View)
            </span>
          ) : null}
        </aside>
      </div>

      {/* Filter Toolbar */}
      <div className="cp-card grid grid-cols-1 gap-4 p-5 sm:grid-cols-3">
        <div>
          <label
            htmlFor="admin-search"
            className="block text-xs font-bold text-[var(--cp-text-muted)]"
          >
            Search ID, Title, or Locality
          </label>
          <div className="relative mt-1.5">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--cp-text-muted)]"
              aria-hidden="true"
            />
            <input
              id="admin-search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search complaints…"
              className="w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] py-2 pl-9 pr-3 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="admin-status-filter"
            className="block text-xs font-bold text-[var(--cp-text-muted)]"
          >
            Filter Status
          </label>
          <select
            id="admin-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'All' | IssueStatus)}
            className="mt-1.5 w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
          >
            <option value="All">All Statuses</option>
            {ISSUE_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="admin-category-filter"
            className="block text-xs font-bold text-[var(--cp-text-muted)]"
          >
            Filter Category
          </label>
          <select
            id="admin-category-filter"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as 'All' | IssueCategory)}
            className="mt-1.5 w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
          >
            <option value="All">All Categories</option>
            {ISSUE_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Split: Complaints Table + Inspector Panel */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Complaints Table */}
        <div className="cp-card overflow-hidden lg:col-span-7">
          <div className="border-b border-[var(--cp-border)] px-5 py-4 flex items-center justify-between">
            <h2 className="font-display text-sm font-bold text-[#172B45] dark:text-white">
              All Logged Complaints ({filteredIssues.length})
            </h2>
            <span className="text-xs text-[var(--cp-text-muted)]">Select a row to inspect</span>
          </div>

          {filteredIssues.length === 0 ? (
            <p className="p-8 text-center text-sm text-[var(--cp-text-muted)]">
              No complaints match your current filter criteria.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="border-b border-[var(--cp-border)] bg-[var(--cp-bg)] text-xs text-[var(--cp-text-muted)]">
                  <tr>
                    <th className="px-4 py-3 font-bold">ID</th>
                    <th className="px-4 py-3 font-bold">Issue &amp; Locality</th>
                    <th className="px-4 py-3 font-bold">Priority</th>
                    <th className="px-4 py-3 font-bold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--cp-border)]">
                  {filteredIssues.map((issue) => {
                    const isSelected = selectedIssue?.id === issue.id;
                    return (
                      <tr
                        key={issue.id}
                        onClick={() => handleSelectRow(issue)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-[var(--cp-accent-soft)]'
                            : 'hover:bg-[var(--cp-accent-soft)]/45'
                        }`}
                      >
                        <td className="px-4 py-3.5 font-mono-tabular font-semibold text-[#172B45] dark:text-white whitespace-nowrap">
                          {issue.id}
                        </td>
                        <td className="px-4 py-3.5">
                          <p className="font-semibold text-[#172B45] dark:text-white line-clamp-1">
                            {issue.title}
                          </p>
                          <p className="text-xs text-[var(--cp-text-muted)]">
                            {issue.locality}, {issue.city}
                            {issue.duplicateOfId ? ` · Duplicate of ${issue.duplicateOfId}` : ''}
                          </p>
                        </td>
                        <td
                          className={`px-4 py-3.5 font-semibold whitespace-nowrap ${getPriorityTextClass(
                            issue.priority
                          )}`}
                        >
                          {issue.priority}
                        </td>
                        <td
                          className={`px-4 py-3.5 font-bold whitespace-nowrap ${getStatusTextClass(
                            issue.status
                          )}`}
                        >
                          {issue.status}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Selected Complaint Inspector & Action Panel */}
        <aside aria-label="Selected Complaint Inspector" className="cp-card p-6 lg:col-span-5">
          {!selectedIssue ? (
            <p className="text-sm text-[var(--cp-text-muted)]">
              Select any complaint from the table to review evidence and update status.
            </p>
          ) : (
            <div className="space-y-5">
              <div>
                <p className="font-mono-tabular text-xs font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
                  {selectedIssue.id} ·{' '}
                  {selectedIssue.isDemoRecord ? 'Sample Record' : 'Firestore Report'}
                </p>
                <h2 className="mt-1 font-display text-lg font-extrabold text-[#172B45] dark:text-white">
                  {selectedIssue.title}
                </h2>
                <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
                  {selectedIssue.category} · {selectedIssue.locality}, {selectedIssue.city}
                </p>
              </div>

              {/* Photo Inspection */}
              <div className="overflow-hidden rounded-xl border border-[var(--cp-border)] bg-[var(--cp-bg)]">
                {selectedIssue.imageUrl && !imgError ? (
                  <img
                    src={selectedIssue.imageUrl}
                    alt={`Submitted evidence for ${selectedIssue.id}`}
                    referrerPolicy="no-referrer"
                    onError={() => setImgError(true)}
                    className="h-44 w-full object-cover"
                  />
                ) : (
                  <div className="flex h-32 flex-col items-center justify-center text-xs text-[var(--cp-text-muted)]">
                    <ImageOff className="h-5 w-5 opacity-60" aria-hidden="true" />
                    <span className="mt-1">No photograph uploaded</span>
                  </div>
                )}
              </div>

              {actionFeedback && (
                <p
                  role="status"
                  className="rounded-lg border border-[#159C91] bg-[var(--cp-accent-soft)] px-3.5 py-2.5 text-xs font-semibold text-[#0F7E75] dark:text-[#2DD4BF]"
                >
                  {actionFeedback}
                </p>
              )}

              {/* Status Update Form */}
              <form
                onSubmit={handleStatusSubmit}
                className="space-y-3 border-t border-[var(--cp-border)] pt-4"
              >
                <h3 className="text-xs font-bold uppercase tracking-wide text-[var(--cp-text-muted)]">
                  Update Complaint Status
                </h3>

                <div>
                  <label
                    htmlFor="admin-next-status"
                    className="block text-xs font-semibold text-[var(--cp-text)]"
                  >
                    New Stage
                  </label>
                  <select
                    id="admin-next-status"
                    value={nextStatus}
                    disabled={!isAdmin || isBusy}
                    onChange={(e) => setNextStatus(e.target.value as IssueStatus)}
                    className="mt-1 w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none disabled:opacity-60"
                  >
                    {ISSUE_STATUSES.map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="admin-progress-note"
                    className="block text-xs font-semibold text-[var(--cp-text)]"
                  >
                    Official-Style Progress Note
                  </label>
                  <textarea
                    id="admin-progress-note"
                    rows={2}
                    disabled={!isAdmin || isBusy}
                    value={progressNote}
                    onChange={(e) => setProgressNote(e.target.value)}
                    placeholder="e.g., Inspection logged; maintenance crew scheduled."
                    className="mt-1 w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none disabled:opacity-60"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!isAdmin || isBusy}
                  className="cp-btn-primary w-full px-4 py-2.5 text-sm disabled:opacity-50"
                >
                  Save Status Update
                </button>
              </form>

              {/* Mark Duplicate Form */}
              <form
                onSubmit={handleDuplicateSubmit}
                className="space-y-2.5 border-t border-[var(--cp-border)] pt-4"
              >
                <label
                  htmlFor="admin-duplicate-id"
                  className="block text-xs font-bold uppercase tracking-wide text-[var(--cp-text-muted)]"
                >
                  Mark as Duplicate of Existing ID
                </label>
                <div className="flex gap-2">
                  <input
                    id="admin-duplicate-id"
                    type="text"
                    disabled={!isAdmin || isBusy}
                    value={duplicateTargetId}
                    onChange={(e) => setDuplicateTargetId(e.target.value)}
                    placeholder="e.g., CP-2026-1001"
                    className="flex-1 rounded-lg border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 font-mono-tabular text-xs text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={!isAdmin || isBusy}
                    className="cp-btn-secondary px-3.5 py-2 text-xs whitespace-nowrap disabled:opacity-50"
                  >
                    Mark Duplicate
                  </button>
                </div>
              </form>
            </div>
          )}
        </aside>
      </div>

      {/* Bottom Analytics Row */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="cp-card p-6 lg:col-span-6">
          <h2 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
            Frequently Reported Localities
          </h2>
          <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
            Hotspot areas ranked by total complaint volume.
          </p>
          <ul className="mt-4 divide-y divide-[var(--cp-border)]">
            {localityFrequency.map(([loc, count]) => (
              <li key={loc} className="flex items-center justify-between py-3 text-sm">
                <span className="font-semibold text-[var(--cp-text)]">{loc}</span>
                <span className="font-mono-tabular font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
                  {count} {count === 1 ? 'report' : 'reports'}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="cp-card p-6 lg:col-span-6">
          <h2 className="font-display text-lg font-bold text-[#172B45] dark:text-white">
            Complaints by Priority Level
          </h2>
          <p className="mt-1 text-xs text-[var(--cp-text-muted)]">
            Distribution of High, Medium, and Low priority classifications.
          </p>
          <div className="mt-4">
            <IssuesChart
              type="bar"
              labels={['High Priority', 'Medium Priority', 'Low Priority']}
              values={[
                issues.filter((i) => i.priority === 'High').length,
                issues.filter((i) => i.priority === 'Medium').length,
                issues.filter((i) => i.priority === 'Low').length,
              ]}
              datasetLabel="Reports"
              colors={['#FF7657', '#E09F3E', '#159C91']}
              isDark={isDark}
              heightClass="h-60"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
