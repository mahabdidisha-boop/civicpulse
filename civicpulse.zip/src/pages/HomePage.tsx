import { useState } from 'react';
import { ArrowRight, CheckCircle2, ClipboardList, Compass, ShieldCheck } from 'lucide-react';
import { CivicIssue, PageRoute } from '../types/issue';
import { IssueCard } from '../components/IssueCard';

const SAAS_HERO_ILLUSTRATION = '/src/assets/images/hero_civicpulse_saas_1794929047704.jpg';
const COMMUNITY_ILLUSTRATION =
  '/src/assets/images/community_civic_illustration_1794929049331.jpg';

interface HomePageProps {
  issues: CivicIssue[];
  votedIds: string[];
  onNavigate: (page: PageRoute) => void;
  onSelectIssue: (issue: CivicIssue) => void;
  onUpvote: (issueId: string) => void;
  onTrackIssue: (issueId: string) => void;
}

/**
 * Home Page:
 * HubSpot-inspired warm editorial SaaS landing page for CivicPulse.
 * Preserves all live KPIs, 3-step workflow, recent reports, and navigation CTAs.
 */
export function HomePage({
  issues,
  votedIds,
  onNavigate,
  onSelectIssue,
  onUpvote,
  onTrackIssue,
}: HomePageProps) {
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [communityImgFailed, setCommunityImgFailed] = useState(false);

  const totalCount = issues.length;
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;
  const activeCount = totalCount - resolvedCount;
  const uniqueLocalities = new Set(issues.map((i) => `${i.locality}, ${i.city}`)).size;
  const recentIssues = [...issues]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3);

  return (
    <div className="space-y-20 pb-6">
      {/* Section 1: Spacious SaaS Hero Split + 4-Column KPI Strip */}
      <section aria-labelledby="hero-heading" className="relative pt-10 sm:pt-16">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Hero Copy */}
          <div className="flex flex-col justify-center lg:col-span-6">
            <p className="text-sm font-bold tracking-wide text-[#0F7E75] dark:text-[#2DD4BF]">
              Hyperlocal Civic Infrastructure Platform
            </p>
            <h1
              id="hero-heading"
              className="mt-3.5 font-display text-[clamp(2.3rem,4.3vw,3.55rem)] font-extrabold tracking-tight text-[#172B45] dark:text-white leading-[1.08]"
            >
              Make Your Neighbourhood Better.
            </h1>
            <p className="mt-5 max-w-xl text-base sm:text-lg leading-relaxed text-[var(--cp-text-muted)]">
              CivicPulse connects residents with neighbourhood infrastructure visibility. Document
              road damage, water leaks, waste accumulation, or streetlight outages with
              photographic evidence and follow every stage from submission to resolution.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate('report')}
                className="cp-btn-primary inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm sm:text-base whitespace-nowrap min-h-[48px]"
              >
                Report an Issue
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('explore')}
                className="cp-btn-secondary inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm sm:text-base whitespace-nowrap min-h-[48px]"
              >
                <Compass className="h-4 w-4 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
                Explore Local Issues
              </button>
            </div>
          </div>

          {/* Hero Urban Infrastructure Illustration with Decorative SaaS Framing */}
          <div className="relative lg:col-span-6">
            {/* Subtle geometric warm decorative accents behind illustration */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-3 -top-3 hidden h-24 w-24 rounded-2xl bg-[#FF7657]/15 sm:block"
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-3 -left-3 hidden h-28 w-28 rounded-2xl bg-[#159C91]/15 sm:block"
            />

            <figure className="cp-card relative overflow-hidden p-2 sm:p-2.5">
              <div className="overflow-hidden rounded-[10px] bg-[#FFF8F0] dark:bg-[#0E1A2B]">
                {!heroImgFailed ? (
                  <img
                    src={SAAS_HERO_ILLUSTRATION}
                    alt="Editorial SaaS illustration of a clean urban neighbourhood streetscape with map pins, streetlights, and transit"
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgFailed(true)}
                    className="aspect-[16/9] h-full w-full object-cover"
                  />
                ) : (
                  <div className="flex aspect-[16/9] h-full w-full flex-col items-center justify-center p-8 text-center">
                    <ShieldCheck className="h-12 w-12 text-[#159C91]" aria-hidden="true" />
                    <p className="mt-3 font-display text-lg font-bold text-[#172B45] dark:text-white">
                      CivicPulse Neighbourhood Infrastructure Network
                    </p>
                  </div>
                )}
              </div>
            </figure>
          </div>
        </div>

        {/* Full-Width 4-Column KPI Strip */}
        <div
          aria-label="Platform Statistics"
          className="cp-card mt-12 grid grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-[var(--cp-border)] overflow-hidden sm:grid-cols-4"
        >
          <div className="p-6">
            <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Total Reports Logged</p>
            <p className="mt-1.5 font-display text-3xl font-extrabold text-[#172B45] dark:text-white tabular-nums">
              {totalCount}
            </p>
            <p className="mt-1 text-xs text-[var(--cp-text-muted)]">Sample + Firestore records</p>
          </div>
          <div className="p-6">
            <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Resolved Issues</p>
            <p className="mt-1.5 font-display text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 tabular-nums">
              {resolvedCount}
            </p>
            <p className="mt-1 text-xs text-[var(--cp-text-muted)]">Verified closures</p>
          </div>
          <div className="p-6">
            <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Active Complaints</p>
            <p className="mt-1.5 font-display text-3xl font-extrabold text-[#D64026] dark:text-[#FF7657] tabular-nums">
              {activeCount}
            </p>
            <p className="mt-1 text-xs text-[var(--cp-text-muted)]">Under review or progress</p>
          </div>
          <div className="p-6">
            <p className="text-xs font-semibold text-[var(--cp-text-muted)]">Localities Monitored</p>
            <p className="mt-1.5 font-display text-3xl font-extrabold text-[#0F7E75] dark:text-[#2DD4BF] tabular-nums">
              {uniqueLocalities}
            </p>
            <p className="mt-1 text-xs text-[var(--cp-text-muted)]">Urban neighbourhoods</p>
          </div>
        </div>
      </section>

      {/* Section 2: How CivicPulse Works (Report -> Verify -> Resolve) */}
      <section aria-labelledby="workflow-heading" className="space-y-8">
        <div className="max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
            Transparent Lifecycle
          </p>
          <h2
            id="workflow-heading"
            className="mt-2 font-display text-2xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl"
          >
            How CivicPulse Works
          </h2>
          <p className="mt-3 text-base leading-relaxed text-[var(--cp-text-muted)]">
            A structured three-stage workflow designed for accountability, clarity, and measurable
            neighbourhood maintenance.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <article className="cp-card cp-card-interactive overflow-hidden p-7">
            <div className="h-1 w-12 rounded-full bg-[#FF7657]" aria-hidden="true" />
            <p className="mt-5 font-mono-tabular text-xs font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
              01. Report
            </p>
            <h3 className="mt-2 font-display text-xl font-bold text-[#172B45] dark:text-white">
              Submit Structured Evidence
            </h3>
            <p className="mt-2.5 text-sm leading-relaxed text-[var(--cp-text-muted)]">
              Select the issue category, attach a clear photograph, pin the street locality on the
              map, and receive a unique tracking ID immediately.
            </p>
          </article>

          <article className="cp-card cp-card-interactive overflow-hidden p-7">
            <div className="h-1 w-12 rounded-full bg-[#159C91]" aria-hidden="true" />
            <p className="mt-5 font-mono-tabular text-xs font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
              02. Verify
            </p>
            <h3 className="mt-2 font-display text-xl font-bold text-[#172B45] dark:text-white">
              Deduplicate &amp; Prioritize
            </h3>
            <p className="mt-2.5 text-sm leading-relaxed text-[var(--cp-text-muted)]">
              Duplicate detection alerts residents to existing reports nearby so neighbours can
              upvote recurring problems and highlight urgent safety priorities.
            </p>
          </article>

          <article className="cp-card cp-card-interactive overflow-hidden p-7">
            <div className="h-1 w-12 rounded-full bg-[#172B45] dark:bg-[#2DD4BF]" aria-hidden="true" />
            <p className="mt-5 font-mono-tabular text-xs font-bold text-[#0F7E75] dark:text-[#2DD4BF]">
              03. Resolve
            </p>
            <h3 className="mt-2 font-display text-xl font-bold text-[#172B45] dark:text-white">
              Track Every Stage Transparently
            </h3>
            <p className="mt-2.5 text-sm leading-relaxed text-[var(--cp-text-muted)]">
              Follow timestamped progress milestones from Submitted through Under Review, Verified,
              In Progress, and Resolved using your Complaint ID.
            </p>
          </article>
        </div>
      </section>

      {/* Section 3: Recently Reported Problems */}
      <section aria-labelledby="recent-issues-heading" className="space-y-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
              Live Activity
            </p>
            <h2
              id="recent-issues-heading"
              className="mt-1.5 font-display text-2xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-4xl"
            >
              Recently Reported Problems
            </h2>
            <p className="mt-2 text-base text-[var(--cp-text-muted)]">
              Latest demonstration samples and citizen-submitted neighbourhood reports.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('explore')}
            className="cp-btn-secondary inline-flex items-center gap-2 px-4 py-2.5 text-sm whitespace-nowrap"
          >
            View All Issues
            <ArrowRight className="h-4 w-4 text-[#FF7657]" aria-hidden="true" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {recentIssues.map((issue) => (
            <IssueCard
              key={issue.id}
              issue={issue}
              hasVoted={votedIds.includes(issue.id)}
              onSelect={onSelectIssue}
              onUpvote={onUpvote}
              onTrack={onTrackIssue}
            />
          ))}
        </div>
      </section>

      {/* Section 4: Community Impact & Quick Track Callout */}
      <section
        aria-labelledby="community-impact-heading"
        className="cp-card overflow-hidden p-7 sm:p-10"
      >
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <p className="text-xs font-bold uppercase tracking-wider text-[#0F7E75] dark:text-[#2DD4BF]">
              Community Impact
            </p>
            <h2
              id="community-impact-heading"
              className="mt-2 font-display text-2xl font-extrabold tracking-tight text-[#172B45] dark:text-white sm:text-3xl"
            >
              Collective Neighbourhood Visibility
            </h2>
            <p className="mt-3 text-base leading-relaxed text-[var(--cp-text-muted)]">
              When multiple residents support the same local issue, maintenance priorities become
              clearer and easier to verify. Explore community-backed reports, view locality
              analytics, or look up an existing Complaint ID in seconds.
            </p>

            {/* Clean inline impact summary */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="rounded-xl border border-[var(--cp-border)] bg-[var(--cp-bg)] p-4">
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">
                  Total Citizen Supports
                </p>
                <p className="mt-1 font-display text-2xl font-extrabold text-[#172B45] dark:text-white tabular-nums">
                  {issues.reduce((sum, item) => sum + item.upvotes, 0)}
                </p>
              </div>
              <div className="rounded-xl border border-[var(--cp-border)] bg-[var(--cp-bg)] p-4">
                <p className="text-xs font-semibold text-[var(--cp-text-muted)]">
                  High-Priority Flags
                </p>
                <p className="mt-1 font-display text-2xl font-extrabold text-[#D64026] dark:text-[#FF7657] tabular-nums">
                  {issues.filter((i) => i.priority === 'High' && i.status !== 'Resolved').length}
                </p>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => onNavigate('community')}
                className="cp-btn-primary inline-flex items-center gap-2 px-5 py-3 text-sm whitespace-nowrap min-h-[44px]"
              >
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                Explore Community Watch
              </button>
              <button
                type="button"
                onClick={() => onNavigate('track')}
                className="cp-btn-secondary inline-flex items-center gap-2 px-5 py-3 text-sm whitespace-nowrap min-h-[44px]"
              >
                <ClipboardList className="h-4 w-4 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
                Track a Complaint ID
              </button>
            </div>
          </div>

          <div className="space-y-4 lg:col-span-6">
            <figure className="overflow-hidden rounded-xl border border-[var(--cp-border)] bg-[var(--cp-bg)]">
              {!communityImgFailed ? (
                <img
                  src={COMMUNITY_ILLUSTRATION}
                  alt="Editorial illustration of neighbourhood residents collaborating around a street infrastructure map"
                  referrerPolicy="no-referrer"
                  onError={() => setCommunityImgFailed(true)}
                  className="aspect-[4/3] w-full object-cover"
                />
              ) : (
                <div className="flex aspect-[4/3] w-full flex-col items-center justify-center p-6 text-center text-[var(--cp-text-muted)]">
                  <CheckCircle2 className="h-10 w-10 text-[#159C91]" aria-hidden="true" />
                  <p className="mt-2 font-display text-sm font-bold text-[#172B45] dark:text-white">
                    Collaborative Neighbourhood Watch
                  </p>
                </div>
              )}
            </figure>
            <p className="text-xs leading-relaxed text-[var(--cp-text-muted)]">
              Demonstration Transparency: Preloaded records illustrate typical urban civic
              categories across Indian cities. Signed-in citizen reports and votes persist in Cloud
              Firestore.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
