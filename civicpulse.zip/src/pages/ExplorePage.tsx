import { useMemo, useState } from 'react';
import { List, Map as MapIcon, Search, XCircle } from 'lucide-react';
import { CivicSearchPanel } from '../components/CivicSearchPanel';
import { IssueCard } from '../components/IssueCard';
import { IssuesMap } from '../components/IssuesMap';
import {
  CivicIssue,
  ISSUE_CATEGORIES,
  ISSUE_STATUSES,
  IssueCategory,
  IssueStatus,
  PageRoute,
} from '../types/issue';

interface ExplorePageProps {
  issues: CivicIssue[];
  votedIds: string[];
  onSelectIssue: (issue: CivicIssue) => void;
  onUpvote: (issueId: string) => void;
  onTrackIssue: (issueId: string) => void;
  onNavigate: (page: PageRoute) => void;
}

type DateFilterOption = 'all' | '7d' | '30d' | '90d';

/**
 * Explore Local Issues Page:
 * Interactive Google Maps Platform explorer + List View + Live Google Search Grounded Civic Lookup.
 */
export function ExplorePage({
  issues,
  votedIds,
  onSelectIssue,
  onUpvote,
  onTrackIssue,
  onNavigate,
}: ExplorePageProps) {
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | IssueCategory>('All');
  const [selectedStatus, setSelectedStatus] = useState<'All' | IssueStatus>('All');
  const [dateFilter, setDateFilter] = useState<DateFilterOption>('all');

  const filteredIssues = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const now = Date.now();

    return issues.filter((issue) => {
      if (selectedCategory !== 'All' && issue.category !== selectedCategory) {
        return false;
      }
      if (selectedStatus !== 'All' && issue.status !== selectedStatus) {
        return false;
      }
      if (dateFilter !== 'all') {
        const createdMs = new Date(issue.createdAt).getTime();
        const days = dateFilter === '7d' ? 7 : dateFilter === '30d' ? 30 : 90;
        if (now - createdMs > days * 24 * 60 * 60 * 1000) {
          return false;
        }
      }
      if (query) {
        const haystack =
          `${issue.id} ${issue.title} ${issue.locality} ${issue.city} ${issue.category}`.toLowerCase();
        if (!haystack.includes(query)) {
          return false;
        }
      }
      return true;
    });
  }, [issues, searchQuery, selectedCategory, selectedStatus, dateFilter]);

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedStatus('All');
    setDateFilter('all');
  };

  return (
    <div className="space-y-8 py-8">
      {/* Header + View Switcher */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--cp-border)] pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#102A43] dark:text-white sm:text-3xl">
            Explore Local Issues
          </h1>
          <p className="mt-1 text-sm text-[var(--cp-text-muted)]">
            Filter neighbourhood reports by locality, category, status, or date. Sample records are
            explicitly labelled.
          </p>
        </div>

        {/* Segmented Control for Map / List View */}
        <div
          role="group"
          aria-label="Issue display mode"
          className="inline-flex rounded-lg border border-[var(--cp-border)] bg-[var(--cp-surface)] p-1"
        >
          <button
            type="button"
            onClick={() => setViewMode('map')}
            aria-pressed={viewMode === 'map'}
            className={`inline-flex items-center gap-1.5 rounded-md px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              viewMode === 'map'
                ? 'bg-[#102A43] text-white dark:bg-[#14B8A6] dark:text-[#0B1522]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            <MapIcon className="h-3.5 w-3.5" aria-hidden="true" />
            Map View
          </button>
          <button
            type="button"
            onClick={() => setViewMode('list')}
            aria-pressed={viewMode === 'list'}
            className={`inline-flex items-center gap-1.5 rounded-md px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
              viewMode === 'list'
                ? 'bg-[#102A43] text-white dark:bg-[#14B8A6] dark:text-[#0B1522]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            <List className="h-3.5 w-3.5" aria-hidden="true" />
            List View
          </button>
        </div>
      </div>

      {/* Filter Controls Bar */}
      <section aria-label="Search and Filter Controls" className="cp-card p-4 sm:p-5">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label
              htmlFor="explore-search"
              className="block text-xs font-medium text-[var(--cp-text-muted)]"
            >
              Search Locality or Keyword
            </label>
            <div className="relative mt-1">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--cp-text-muted)]"
                aria-hidden="true"
              />
              <input
                id="explore-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="e.g., Indiranagar, Mumbai, pothole"
                className="w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] py-2 pl-9 pr-3 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="explore-category"
              className="block text-xs font-medium text-[var(--cp-text-muted)]"
            >
              Category
            </label>
            <select
              id="explore-category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value as 'All' | IssueCategory)}
              className="mt-1 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            >
              <option value="All">All Categories</option>
              {ISSUE_CATEGORIES.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="explore-status"
              className="block text-xs font-medium text-[var(--cp-text-muted)]"
            >
              Complaint Status
            </label>
            <select
              id="explore-status"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value as 'All' | IssueStatus)}
              className="mt-1 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            >
              <option value="All">All Statuses</option>
              {ISSUE_STATUSES.map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="explore-date"
              className="block text-xs font-medium text-[var(--cp-text-muted)]"
            >
              Date Window
            </label>
            <select
              id="explore-date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as DateFilterOption)}
              className="mt-1 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            >
              <option value="all">All Dates</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="90d">Last 90 Days</option>
            </select>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--cp-text-muted)]">
          <p className="tabular-nums">
            Showing <strong className="text-[var(--cp-text)]">{filteredIssues.length}</strong> of{' '}
            {issues.length} logged issues
          </p>
          {(searchQuery || selectedCategory !== 'All' || selectedStatus !== 'All' || dateFilter !== 'all') && (
            <button
              type="button"
              onClick={clearFilters}
              className="inline-flex items-center gap-1 font-medium text-[#0D9488] dark:text-[#14B8A6] hover:underline"
            >
              <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
              Reset Filters
            </button>
          )}
        </div>
      </section>

      {/* Empty State or Map/List Content */}
      {filteredIssues.length === 0 ? (
        <div className="cp-card py-14 px-6 text-center">
          <p className="font-display text-lg font-semibold text-[#102A43] dark:text-white">
            No Matching Issues Found
          </p>
          <p className="mt-1.5 text-sm text-[var(--cp-text-muted)]">
            Try widening your locality search or resetting the category and status filters.
          </p>
          <div className="mt-5 flex justify-center gap-3">
            <button
              type="button"
              onClick={clearFilters}
              className="rounded-md border border-[var(--cp-border)] px-4 py-2 text-sm font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)]"
            >
              Clear All Filters
            </button>
            <button
              type="button"
              onClick={() => onNavigate('report')}
              className="rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-4 py-2 text-sm font-medium text-white dark:text-[#0B1522]"
            >
              Report an Issue
            </button>
          </div>
        </div>
      ) : viewMode === 'map' ? (
        <div className="space-y-4">
          <IssuesMap
            mode="explore"
            issues={filteredIssues}
            onSelectIssue={onSelectIssue}
            heightClass="h-[480px]"
          />
          <p className="text-xs text-[var(--cp-text-muted)]">
            Tip: Click any map pin to inspect the issue summary and open its full evidence
            record.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredIssues.map((issue) => (
            <IssueCard
              key={issue.id}
              issue={issue}
              hasVoted={votedIds.includes(issue.id)}
              onSelect={onSelectIssue}
              onUpvote={onUpvote}
              onTrack={onTrackIssue}
            />
          ))}
        </div>
      )}

      {/* Grounded Google Search Municipal Portal & Advisory Lookup */}
      <CivicSearchPanel />
    </div>
  );
}
