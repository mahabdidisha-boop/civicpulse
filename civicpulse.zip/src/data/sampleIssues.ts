import { CivicIssue } from '../types/issue';

/**
 * Generated hero illustration asset path for the Home page.
 */
export const HERO_CIVIC_IMAGE =
  '/src/assets/images/hero_civic_infrastructure_1794927093769.jpg';

/**
 * Preset Indian urban localities with approximate centre coordinates
 * so citizens can quickly pick a neighbourhood or click the interactive map.
 */
export interface LocalityPreset {
  name: string;
  city: string;
  latitude: number;
  longitude: number;
}

export const LOCALITY_PRESETS: LocalityPreset[] = [
  { name: 'Indiranagar 100 Feet Road', city: 'Bengaluru', latitude: 12.9784, longitude: 77.6408 },
  { name: 'Koramangala 4th Block', city: 'Bengaluru', latitude: 12.9352, longitude: 77.6245 },
  { name: 'Bandra West Link Road', city: 'Mumbai', latitude: 19.0607, longitude: 72.8362 },
  { name: 'Kothrud Paud Road', city: 'Pune', latitude: 18.5074, longitude: 73.8077 },
  { name: 'Adyar LB Road', city: 'Chennai', latitude: 13.0012, longitude: 80.2565 },
  { name: 'Salt Lake Sector V', city: 'Kolkata', latitude: 22.5726, longitude: 88.4319 },
  { name: 'Madhapur Hi-Tech Road', city: 'Hyderabad', latitude: 17.4486, longitude: 78.3908 },
  { name: 'Dwarka Sector 12', city: 'New Delhi', latitude: 28.5921, longitude: 77.046 },
];

/**
 * Demonstration sample issues from Indian urban localities.
 * Note: All entries have `isDemoRecord: true` and are clearly labelled in the UI
 * as sample/demonstration data rather than live municipal filings.
 */
export const SAMPLE_DEMO_ISSUES: CivicIssue[] = [
  {
    id: 'CP-2026-1001',
    title: 'Deep rainwater-filled pothole near bus stop junction',
    category: 'Road damage / Potholes',
    description:
      'A wide asphalt crater has formed along the left lane near the Indiranagar commercial bus bay, causing two-wheelers to swerve abruptly during evening peak traffic.',
    locality: 'Indiranagar 100 Feet Road',
    city: 'Bengaluru',
    latitude: 12.9784,
    longitude: 77.6408,
    status: 'In Progress',
    priority: 'High',
    createdAt: '2026-11-10T09:15:00.000Z',
    updatedAt: '2026-11-15T14:30:00.000Z',
    imageUrl: '/src/assets/images/sample_pothole_road_1794927094357.jpg',
    upvotes: 42,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-10T09:15:00.000Z',
        note: 'Sample citizen report logged with photographic evidence.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Under Review',
        timestamp: '2026-11-11T11:00:00.000Z',
        note: 'Assigned to demonstration road-surface triage queue.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'Verified',
        timestamp: '2026-11-12T16:20:00.000Z',
        note: 'Field dimensions verified; flagged as High Priority arterial hazard.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'In Progress',
        timestamp: '2026-11-15T14:30:00.000Z',
        note: 'Cold-mix patching crew scheduled for off-peak resurfacing.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1002',
    title: 'Overflowing twin waste bins beside market walkway',
    category: 'Garbage and waste management',
    description:
      'Biodegradable and dry waste bins near the neighbourhood vegetable market have overflowed onto the pedestrian footpath for two consecutive mornings.',
    locality: 'Salt Lake Sector V',
    city: 'Kolkata',
    latitude: 22.5726,
    longitude: 88.4319,
    status: 'Verified',
    priority: 'Medium',
    createdAt: '2026-11-12T07:45:00.000Z',
    updatedAt: '2026-11-14T10:15:00.000Z',
    imageUrl: '/src/assets/images/sample_garbage_waste_1794927095063.jpg',
    upvotes: 29,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-12T07:45:00.000Z',
        note: 'Demonstration sanitation report submitted with corner photo.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Under Review',
        timestamp: '2026-11-13T08:30:00.000Z',
        note: 'Sanitation route timing checked against ward collection logs.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'Verified',
        timestamp: '2026-11-14T10:15:00.000Z',
        note: 'Confirmed recurring spillover; recommended morning twin-bin clearance.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1003',
    title: 'Unlit municipal LED streetlight pole on residential stretch',
    category: 'Streetlight problems',
    description:
      'Three consecutive streetlamps along the pedestrian pavement near the community park remain dark after 6:30 PM, creating low-visibility crossings for pedestrians.',
    locality: 'Koramangala 4th Block',
    city: 'Bengaluru',
    latitude: 12.9352,
    longitude: 77.6245,
    status: 'Resolved',
    priority: 'High',
    createdAt: '2026-11-02T18:20:00.000Z',
    updatedAt: '2026-11-09T17:10:00.000Z',
    imageUrl: '/src/assets/images/sample_streetlight_outage_1794927095634.jpg',
    upvotes: 36,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-02T18:20:00.000Z',
        note: 'Dusk outage photograph attached in demonstration submission.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Under Review',
        timestamp: '2026-11-03T10:00:00.000Z',
        note: 'Feeder pole circuit check logged.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'Verified',
        timestamp: '2026-11-04T15:40:00.000Z',
        note: 'Faulty timer relay confirmed at distribution box.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'In Progress',
        timestamp: '2026-11-07T11:25:00.000Z',
        note: 'Electrical maintenance ladder unit dispatched (demo workflow).',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'Resolved',
        timestamp: '2026-11-09T17:10:00.000Z',
        note: 'LED luminaire driver replaced and dusk-to-dawn sensor verified working.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1004',
    title: 'Continuous water leakage from roadside pipeline flange',
    category: 'Water leakage',
    description:
      'Clean treated water has been steadily leaking from an exposed roadside cast-iron valve joint since early morning, pooling across the curb gutter.',
    locality: 'Bandra West Link Road',
    city: 'Mumbai',
    latitude: 19.0607,
    longitude: 72.8362,
    status: 'Under Review',
    priority: 'High',
    createdAt: '2026-11-14T08:05:00.000Z',
    updatedAt: '2026-11-15T09:50:00.000Z',
    imageUrl: '/src/assets/images/sample_water_leakage_1794927095412.jpg',
    upvotes: 51,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-14T08:05:00.000Z',
        note: 'Sample report submitted highlighting daily potable water loss.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Under Review',
        timestamp: '2026-11-15T09:50:00.000Z',
        note: 'Flagged for gasket pressure inspection in demonstration queue.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1005',
    title: 'Blocked stormwater drainage grate causing kerb waterlogging',
    category: 'Drainage and sewage',
    description:
      'Silt and plastic debris have clogged the stormwater catch-pit near the school crossing, leaving ankle-deep stagnant water along the kerb.',
    locality: 'Kothrud Paud Road',
    city: 'Pune',
    latitude: 18.5074,
    longitude: 73.8077,
    status: 'Submitted',
    priority: 'Medium',
    createdAt: '2026-11-16T11:30:00.000Z',
    updatedAt: '2026-11-16T11:30:00.000Z',
    upvotes: 18,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-16T11:30:00.000Z',
        note: 'Initial demonstration report registered.',
        updatedBy: 'Citizen Portal (Demo)',
      },
    ],
  },
  {
    id: 'CP-2026-1006',
    title: 'Damaged pedestrian guardrail and broken tactile paving tiles',
    category: 'Public infrastructure damage',
    description:
      'A 4-metre section of metal pedestrian railing and concrete paving slabs near the bus shelter has dislodged, forcing pedestrians onto the carriageway.',
    locality: 'Adyar LB Road',
    city: 'Chennai',
    latitude: 13.0012,
    longitude: 80.2565,
    status: 'Resolved',
    priority: 'Medium',
    createdAt: '2026-10-28T13:10:00.000Z',
    updatedAt: '2026-11-06T16:45:00.000Z',
    upvotes: 24,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-10-28T13:10:00.000Z',
        note: 'Demonstration sidewalk damage report created.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Verified',
        timestamp: '2026-10-30T11:00:00.000Z',
        note: 'Footpath hazard verified during demonstration audit.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'In Progress',
        timestamp: '2026-11-03T09:20:00.000Z',
        note: 'Precast footpath slabs delivered to site.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'Resolved',
        timestamp: '2026-11-06T16:45:00.000Z',
        note: 'Guardrail welded and tactile paving re-laid cleanly.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1007',
    title: 'Faded zebra crossing markings at four-way junction',
    category: 'Traffic and road safety',
    description:
      'Thermoplastic pedestrian crossing stripes and stop lines at the residential sector intersection have worn off, making night-time crossings hazardous.',
    locality: 'Dwarka Sector 12',
    city: 'New Delhi',
    latitude: 28.5921,
    longitude: 77.046,
    status: 'In Progress',
    priority: 'Medium',
    createdAt: '2026-11-08T10:00:00.000Z',
    updatedAt: '2026-11-15T12:00:00.000Z',
    upvotes: 31,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-11-08T10:00:00.000Z',
        note: 'Safety marking request logged.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Verified',
        timestamp: '2026-11-11T14:20:00.000Z',
        note: 'Intersection visibility check completed.',
        updatedBy: 'Demo Moderator',
      },
      {
        status: 'In Progress',
        timestamp: '2026-11-15T12:00:00.000Z',
        note: 'Reflective road-marking paint scheduled.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
  {
    id: 'CP-2026-1008',
    title: 'Overhanging tree branches blocking corner traffic mirror',
    category: 'Other civic issues',
    description:
      'Untrimmed avenue foliage at the blind T-junction obscures the convex safety mirror and street signage for approaching motorists.',
    locality: 'Madhapur Hi-Tech Road',
    city: 'Hyderabad',
    latitude: 17.4486,
    longitude: 78.3908,
    status: 'Resolved',
    priority: 'Low',
    createdAt: '2026-10-25T15:40:00.000Z',
    updatedAt: '2026-11-01T11:15:00.000Z',
    upvotes: 15,
    isDemoRecord: true,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: '2026-10-25T15:40:00.000Z',
        note: 'Demonstration pruning request submitted.',
        updatedBy: 'Citizen Portal (Demo)',
      },
      {
        status: 'Resolved',
        timestamp: '2026-11-01T11:15:00.000Z',
        note: 'Canopy trimmed to restore clear junction sightline.',
        updatedBy: 'Demo Moderator',
      },
    ],
  },
];
