import { useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { AlertTriangle, X } from 'lucide-react';
import { CivicChatDrawer } from './components/CivicChatDrawer';
import { Footer } from './components/Footer';
import { IssueDetailModal } from './components/IssueDetailModal';
import { Navbar } from './components/Navbar';
import { UtilityBar } from './components/UtilityBar';
import { AdminPage } from './pages/AdminPage';
import { CommunityPage } from './pages/CommunityPage';
import { DashboardPage } from './pages/DashboardPage';
import { ExplorePage } from './pages/ExplorePage';
import { HomePage } from './pages/HomePage';
import { ReportPage } from './pages/ReportPage';
import { TrackPage } from './pages/TrackPage';
import {
  auth,
  createFirestoreIssue,
  createFirestoreNotification,
  markFirestoreIssueDuplicate,
  markFirestoreNotificationsRead,
  signInWithGoogle,
  signOutCitizen,
  subscribeToFirestoreIssues,
  subscribeToUserNotifications,
  syncUserProfileDocuments,
  updateFirestoreIssueStatus,
  upvoteFirestoreIssue,
} from './services/firebaseClient';
import {
  applyStatusUpdate,
  generateComplaintId,
  loadIssues,
  loadNotifications,
  loadVotedIssueIds,
  resetDemoStorage,
  saveIssues,
  saveNotifications,
  saveVotedIssueIds,
} from './services/issueStorage';
import {
  AppNotification,
  CivicIssue,
  IssueCategory,
  IssuePriority,
  IssueStatus,
  PageRoute,
} from './types/issue';

/**
 * Root CivicPulse Application Component.
 * Manages page navigation, Firebase Google Sign-In & Cloud Firestore persistence
 * with seamless local demonstration fallback, Light/Dark theme,
 * Google Maps quota notices, and the multi-turn CivicPulse Assistant.
 */
export default function App() {
  const [currentPage, setCurrentPage] = useState<PageRoute>('home');
  const [localIssues, setLocalIssues] = useState<CivicIssue[]>(() => loadIssues());
  const [firestoreIssues, setFirestoreIssues] = useState<CivicIssue[]>([]);
  const [votedIds, setVotedIds] = useState<string[]>(() => loadVotedIssueIds());

  const [localNotifications, setLocalNotifications] = useState<AppNotification[]>(() =>
    loadNotifications()
  );
  const [firestoreNotifications, setFirestoreNotifications] = useState<AppNotification[]>([]);
  const [activeToast, setActiveToast] = useState<AppNotification | null>(null);

  const [selectedIssue, setSelectedIssue] = useState<CivicIssue | null>(null);
  const [trackedIssueId, setTrackedIssueId] = useState<string>('CP-2026-1001');

  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [cloudNotice, setCloudNotice] = useState<string | null>(null);
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      return localStorage.getItem('civicpulse_theme') === 'dark';
    } catch {
      return false;
    }
  });

  // Sync Tailwind .dark class on <html> element
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem('civicpulse_theme', isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage failures
    }
  }, [isDark]);

  // Listen for Google Maps Platform quota exceeded events (Case A)
  useEffect(() => {
    const onQuotaExceeded = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Listen for Firebase Authentication state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
      if (currentUser) {
        syncUserProfileDocuments(currentUser).catch((err) => {
          console.error('Profile sync failed:', err);
        });
      } else {
        setFirestoreIssues([]);
        setFirestoreNotifications([]);
      }
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to Cloud Firestore issues & user notifications when authenticated
  useEffect(() => {
    if (!user) return;

    const unsubIssues = subscribeToFirestoreIssues(
      (cloudList) => {
        setFirestoreIssues(cloudList);
        setCloudNotice(null);
      },
      (err) => {
        console.error('Firestore issues listener error:', err);
        setCloudNotice('Could not sync live Cloud Firestore records. Showing local workspace.');
      }
    );

    const unsubNotifications = subscribeToUserNotifications(
      user.uid,
      (cloudNotifs) => {
        setFirestoreNotifications(cloudNotifs);
      },
      (err) => {
        console.error('Firestore notifications listener error:', err);
      }
    );

    return () => {
      unsubIssues();
      unsubNotifications();
    };
  }, [user]);

  // Merge live Cloud Firestore records with local/demo records (Cloud takes precedence on same ID)
  const firestoreIssueIds = useMemo(
    () => new Set(firestoreIssues.map((item) => item.id)),
    [firestoreIssues]
  );

  const issues = useMemo(() => {
    if (firestoreIssues.length === 0) return localIssues;
    const remainder = localIssues.filter((item) => !firestoreIssueIds.has(item.id));
    return [...firestoreIssues, ...remainder];
  }, [firestoreIssues, localIssues, firestoreIssueIds]);

  const firestoreNotifIds = useMemo(
    () => new Set(firestoreNotifications.map((item) => item.id)),
    [firestoreNotifications]
  );

  const notifications = useMemo(() => {
    if (firestoreNotifications.length === 0) return localNotifications;
    const remainder = localNotifications.filter((item) => !firestoreNotifIds.has(item.id));
    return [...firestoreNotifications, ...remainder];
  }, [firestoreNotifications, localNotifications, firestoreNotifIds]);

  // Auto-dismiss live notification toast after 6 seconds
  useEffect(() => {
    if (!activeToast) return;
    const timer = setTimeout(() => setActiveToast(null), 6000);
    return () => clearTimeout(timer);
  }, [activeToast]);

  const navigateTo = (page: PageRoute) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleTrackIssue = (issueId: string) => {
    setTrackedIssueId(issueId);
    navigateTo('track');
  };

  const handleSignIn = async () => {
    setCloudNotice(null);
    try {
      await signInWithGoogle();
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      if (!msg.includes('popup-closed-by-user')) {
        setCloudNotice('Google Sign-In did not complete. Please allow popups and try again.');
      }
    }
  };

  const handleSignOut = async () => {
    setCloudNotice(null);
    try {
      await signOutCitizen();
    } catch (error) {
      console.error('Sign out failed:', error);
    }
  };

  const pushNotification = (issueId: string, title: string, message: string) => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      issueId,
      title,
      message,
      createdAt: new Date().toISOString(),
      read: false,
    };

    setLocalNotifications((prev) => {
      const updated = [newNotif, ...prev];
      saveNotifications(updated);
      return updated;
    });
    setActiveToast(newNotif);

    if (user) {
      createFirestoreNotification(user.uid, newNotif).catch((err) => {
        console.error('Failed to save Firestore notification:', err);
      });
    }
  };

  const handleSubmitNewIssue = (payload: {
    title: string;
    category: IssueCategory;
    description: string;
    locality: string;
    city: string;
    latitude: number;
    longitude: number;
    priority: IssuePriority;
    imageUrl?: string;
  }): CivicIssue => {
    const now = new Date().toISOString();
    const newId = generateComplaintId(issues);

    const newIssue: CivicIssue = {
      id: newId,
      authorId: user?.uid,
      title: payload.title,
      category: payload.category,
      description: payload.description,
      locality: payload.locality,
      city: payload.city,
      latitude: payload.latitude,
      longitude: payload.longitude,
      status: 'Submitted',
      priority: payload.priority,
      createdAt: now,
      updatedAt: now,
      imageUrl: payload.imageUrl,
      upvotes: 1,
      isDemoRecord: false,
      statusHistory: [
        {
          status: 'Submitted',
          timestamp: now,
          note: user
            ? 'Report submitted and verified via Google account on CivicPulse.'
            : 'Report submitted via CivicPulse Citizen Portal.',
          updatedBy: user?.displayName || 'Citizen Portal (Browser Session)',
        },
      ],
    };

    if (user) {
      createFirestoreIssue(newIssue, user.uid).catch((err) => {
        console.error('Failed to persist report to Firestore:', err);
        setCloudNotice(
          'Your report was saved locally, but Cloud Firestore sync encountered an error.'
        );
      });
    } else {
      const updatedLocal = [newIssue, ...localIssues];
      setLocalIssues(updatedLocal);
      saveIssues(updatedLocal);
    }

    // Count creator's automatic initial support locally
    if (!votedIds.includes(newId)) {
      const updatedVotes = [...votedIds, newId];
      setVotedIds(updatedVotes);
      saveVotedIssueIds(updatedVotes);
    }

    pushNotification(
      newId,
      `Report Logged: ${newId}`,
      `${newIssue.title} recorded for ${newIssue.locality}.`
    );

    return newIssue;
  };

  const handleUpvoteIssue = (issueId: string) => {
    if (votedIds.includes(issueId)) return;

    if (user && firestoreIssueIds.has(issueId)) {
      upvoteFirestoreIssue(issueId, user.uid).catch((err) => {
        console.error('Failed to persist upvote to Firestore:', err);
      });
    } else {
      const updatedLocal = localIssues.map((item) =>
        item.id === issueId ? { ...item, upvotes: item.upvotes + 1 } : item
      );
      setLocalIssues(updatedLocal);
      saveIssues(updatedLocal);
    }

    const updatedVotes = [...votedIds, issueId];
    setVotedIds(updatedVotes);
    saveVotedIssueIds(updatedVotes);

    if (selectedIssue?.id === issueId) {
      setSelectedIssue({ ...selectedIssue, upvotes: selectedIssue.upvotes + 1 });
    }
  };

  const handleAdminUpdateStatus = (
    issueId: string,
    newStatus: IssueStatus,
    note: string
  ) => {
    const targetIssue = issues.find((item) => item.id === issueId);
    if (!targetIssue) return;

    if (user && firestoreIssueIds.has(issueId)) {
      updateFirestoreIssueStatus(
        targetIssue,
        newStatus,
        note,
        user.displayName || 'Admin Console'
      ).catch((err) => {
        console.error('Failed to update Firestore issue status:', err);
        setCloudNotice('Firestore status update requires admin authorization.');
      });
    } else {
      const updatedLocal = localIssues.map((item) =>
        item.id === issueId ? applyStatusUpdate(item, newStatus, note) : item
      );
      setLocalIssues(updatedLocal);
      saveIssues(updatedLocal);
    }

    pushNotification(
      issueId,
      `Status Updated: ${issueId}`,
      `Complaint moved to "${newStatus}". ${note ? note : ''}`.trim()
    );
  };

  const handleAdminMarkDuplicate = (issueId: string, duplicateOfId: string) => {
    const targetIssue = issues.find((item) => item.id === issueId);
    if (!targetIssue) return;

    if (user && firestoreIssueIds.has(issueId)) {
      markFirestoreIssueDuplicate(targetIssue, duplicateOfId).catch((err) => {
        console.error('Failed to mark duplicate in Firestore:', err);
        setCloudNotice('Marking duplicates in Cloud Firestore requires admin authorization.');
      });
    } else {
      const now = new Date().toISOString();
      const updatedLocal = localIssues.map((item) =>
        item.id === issueId
          ? {
              ...item,
              duplicateOfId,
              updatedAt: now,
              statusHistory: [
                ...item.statusHistory,
                {
                  status: item.status,
                  timestamp: now,
                  note: `Linked as duplicate of ${duplicateOfId} in demonstration review.`,
                  updatedBy: 'Demo Admin Console',
                },
              ],
            }
          : item
      );
      setLocalIssues(updatedLocal);
      saveIssues(updatedLocal);
    }
  };

  const handleMarkAllNotificationsRead = () => {
    const updatedLocal = localNotifications.map((item) => ({ ...item, read: true }));
    setLocalNotifications(updatedLocal);
    saveNotifications(updatedLocal);

    if (user && firestoreNotifications.length > 0) {
      const unreadIds = firestoreNotifications
        .filter((n) => !n.read)
        .map((n) => n.id);
      if (unreadIds.length > 0) {
        markFirestoreNotificationsRead(user.uid, unreadIds).catch((err) => {
          console.error('Failed to mark Firestore notifications read:', err);
        });
      }
    }
  };

  const handleResetDemoData = () => {
    const fresh = resetDemoStorage();
    setLocalIssues(fresh);
    setVotedIds([]);
    setLocalNotifications(loadNotifications());
    setSelectedIssue(null);
    setTrackedIssueId('CP-2026-1001');
  };

  return (
    <div className="flex min-h-screen flex-col bg-[var(--cp-bg)] text-[var(--cp-text)]">
      {/* Primary Top Navigation */}
      <Navbar currentPage={currentPage} onNavigate={navigateTo} />

      {/* Workspace Utility Strip (Auth, Assistant, Notifications, Theme Switch) */}
      <UtilityBar
        isDark={isDark}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllNotificationsRead}
        onSelectNotificationIssue={handleTrackIssue}
        activeToast={activeToast}
        onDismissToast={() => setActiveToast(null)}
        user={user}
        authLoading={authLoading}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onOpenChat={() => setChatOpen(true)}
      />

      {/* Google Maps Platform Case A Quota Notice Banner */}
      {mapsQuotaExceeded && (
        <div
          role="alert"
          className="border-b border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 px-4 py-2.5 text-xs text-amber-900 dark:text-amber-200"
        >
          <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-3 sm:px-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
              <p>
                Google Maps Platform free trial quota exceeded. Add your own Google Cloud API key
                to continue using Maps.{' '}
                <a
                  href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold underline"
                >
                  Learn how to resolve quota errors
                </a>
                .
              </p>
            </div>
            <button
              type="button"
              onClick={() => setMapsQuotaExceeded(false)}
              aria-label="Dismiss Google Maps quota notice"
              className="rounded p-1 hover:bg-amber-200/50 dark:hover:bg-amber-900/50"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Non-blocking Auth/Firestore Notice Banner */}
      {cloudNotice && (
        <div
          role="status"
          className="border-b border-[var(--cp-border)] bg-[var(--cp-accent-soft)] px-4 py-2 text-xs text-[var(--cp-text)]"
        >
          <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-3 sm:px-2">
            <span>{cloudNotice}</span>
            <button
              type="button"
              onClick={() => setCloudNotice(null)}
              aria-label="Dismiss notice"
              className="rounded p-1 hover:bg-[var(--cp-surface)]"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Semantic Main Content Viewport */}
      <main className="mx-auto w-full max-w-[1200px] flex-1 px-4 sm:px-6">
        {currentPage === 'home' && (
          <HomePage
            issues={issues}
            votedIds={votedIds}
            onNavigate={navigateTo}
            onSelectIssue={setSelectedIssue}
            onUpvote={handleUpvoteIssue}
            onTrackIssue={handleTrackIssue}
          />
        )}

        {currentPage === 'dashboard' && (
          <DashboardPage
            issues={issues}
            isDark={isDark}
            onNavigate={navigateTo}
            onSelectIssue={setSelectedIssue}
          />
        )}

        {currentPage === 'report' && (
          <ReportPage
            existingIssues={issues}
            votedIds={votedIds}
            user={user}
            onSignIn={handleSignIn}
            onSubmitIssue={handleSubmitNewIssue}
            onUpvote={handleUpvoteIssue}
            onNavigate={navigateTo}
            onTrackIssue={handleTrackIssue}
          />
        )}

        {currentPage === 'explore' && (
          <ExplorePage
            issues={issues}
            votedIds={votedIds}
            onSelectIssue={setSelectedIssue}
            onUpvote={handleUpvoteIssue}
            onTrackIssue={handleTrackIssue}
            onNavigate={navigateTo}
          />
        )}

        {currentPage === 'track' && (
          <TrackPage issues={issues} initialTrackId={trackedIssueId} />
        )}

        {currentPage === 'community' && (
          <CommunityPage
            issues={issues}
            votedIds={votedIds}
            onSelectIssue={setSelectedIssue}
            onUpvote={handleUpvoteIssue}
            onTrackIssue={handleTrackIssue}
            onNavigate={navigateTo}
          />
        )}

        {currentPage === 'admin' && (
          <AdminPage
            issues={issues}
            isDark={isDark}
            onUpdateStatus={handleAdminUpdateStatus}
            onMarkDuplicate={handleAdminMarkDuplicate}
          />
        )}
      </main>

      {/* Semantic Footer */}
      <Footer onNavigate={navigateTo} onResetDemoData={handleResetDemoData} />

      {/* Accessible Issue Detail Inspection Modal */}
      <IssueDetailModal
        issue={selectedIssue}
        hasVoted={selectedIssue ? votedIds.includes(selectedIssue.id) : false}
        onClose={() => setSelectedIssue(null)}
        onUpvote={handleUpvoteIssue}
        onTrack={handleTrackIssue}
      />

      {/* Multi-Turn CivicPulse Neighbourhood Assistant Drawer */}
      <CivicChatDrawer isOpen={chatOpen} onClose={() => setChatOpen(false)} />
    </div>
  );
}

