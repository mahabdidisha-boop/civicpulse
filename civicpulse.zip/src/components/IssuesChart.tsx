import { useEffect, useRef } from 'react';
import {
  ArcElement,
  BarController,
  BarElement,
  CategoryScale,
  Chart,
  ChartConfiguration,
  DoughnutController,
  Legend,
  LinearScale,
  LineController,
  LineElement,
  PointElement,
  Tooltip,
} from 'chart.js';

// Register only the Chart.js controllers & elements we actually use
Chart.register(
  BarController,
  BarElement,
  DoughnutController,
  ArcElement,
  LineController,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

interface IssuesChartProps {
  type: 'bar' | 'doughnut' | 'line';
  labels: string[];
  values: number[];
  datasetLabel: string;
  colors?: string[];
  horizontal?: boolean;
  isDark: boolean;
  heightClass?: string;
}

/**
 * Reusable Chart.js wrapper component.
 * Renders a responsive HTML5 <canvas> chart and cleans up on unmount or data change.
 */
export function IssuesChart({
  type,
  labels,
  values,
  datasetLabel,
  colors,
  horizontal = false,
  isDark,
  heightClass = 'h-72',
}: IssuesChartProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Destroy previous instance before creating a fresh chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const textColor = isDark ? '#CBD5E1' : '#4B5E76';
    const gridColor = isDark ? 'rgba(148, 163, 184, 0.14)' : 'rgba(23, 43, 69, 0.08)';
    const defaultColors = [
      '#172B45',
      '#159C91',
      '#FF7657',
      '#2B6CB0',
      '#0F7E75',
      '#E09F3E',
      '#4B5E76',
      '#64748B',
    ];

    const backgroundColor =
      type === 'doughnut'
        ? colors ?? defaultColors.slice(0, labels.length)
        : type === 'line'
          ? 'rgba(21, 156, 145, 0.16)'
          : colors ?? '#159C91';

    const borderColor =
      type === 'doughnut'
        ? isDark
          ? '#162740'
          : '#FFFFFF'
        : type === 'line'
          ? '#159C91'
          : '#0F7E75';

    const config: ChartConfiguration = {
      type,
      data: {
        labels,
        datasets: [
          {
            label: datasetLabel,
            data: values,
            backgroundColor,
            borderColor,
            borderWidth: type === 'doughnut' ? 2 : 1.5,
            borderRadius: type === 'bar' ? 6 : 0,
            tension: type === 'line' ? 0.32 : 0,
            fill: type === 'line',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: type === 'bar' && horizontal ? 'y' : 'x',
        plugins: {
          legend: {
            display: type === 'doughnut',
            position: 'bottom',
            labels: {
              color: textColor,
              boxWidth: 12,
              padding: 16,
              font: {
                family: 'Manrope, sans-serif',
                size: 12,
                weight: 600,
              },
            },
          },
          tooltip: {
            backgroundColor: isDark ? '#0E1A2B' : '#172B45',
            titleColor: '#FFFFFF',
            bodyColor: '#E2E8F0',
            padding: 12,
            cornerRadius: 8,
          },
        },
        scales:
          type === 'doughnut'
            ? undefined
            : {
                x: {
                  beginAtZero: true,
                  ticks: {
                    color: textColor,
                    precision: 0,
                    font: { size: 11, family: 'Manrope, sans-serif' },
                  },
                  grid: {
                    display: horizontal,
                    color: gridColor,
                  },
                },
                y: {
                  beginAtZero: true,
                  ticks: {
                    color: textColor,
                    precision: 0,
                    font: { size: 11, family: 'Manrope, sans-serif' },
                  },
                  grid: {
                    display: !horizontal,
                    color: gridColor,
                  },
                },
              },
      },
    };

    chartInstanceRef.current = new Chart(canvas, config);

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [type, labels, values, datasetLabel, colors, horizontal, isDark]);

  return (
    <div className={`relative w-full ${heightClass}`}>
      <canvas ref={canvasRef} aria-label={datasetLabel} role="img" />
    </div>
  );
}
