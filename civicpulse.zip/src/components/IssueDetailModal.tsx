import { useEffect, useState } from 'react';
import { X, MapPin, Calendar, ThumbsUp, ImageOff, ArrowRight, Film } from 'lucide-react';
import { CivicIssue } from '../types/issue';
import { getPriorityTextClass, getStatusTextClass } from './IssueCard';
import { VideoAnimatorCard } from './VideoAnimatorCard';

interface IssueDetailModalProps {
  issue: CivicIssue | null;
  hasVoted: boolean;
  onClose: () => void;
  onUpvote: (issueId: string) => void;
  onTrack: (issueId: string) => void;
}

/**
 * Accessible Issue Inspection Modal.
 * Displays full complaint details, uploaded photographic evidence,
 * optional photo-to-video animation studio, locality coordinates, and status history.
 */
export function IssueDetailModal({
  issue,
  hasVoted,
  onClose,
  onUpvote,
  onTrack,
}: IssueDetailModalProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const [showAnimator, setShowAnimator] = useState(false);

  useEffect(() => {
    setImgFailed(false);
    setShowAnimator(false);
  }, [issue?.id]);

  useEffect(() => {
    if (!issue) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [issue, onClose]);

  if (!issue) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="issue-modal-title"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-[10px] border border-[var(--cp-border)] bg-[var(--cp-surface)] shadow-xl"
        onClick={(event) => event.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-4 border-b border-[var(--cp-border)] px-6 py-4">
          <div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[var(--cp-text-muted)]">
              <span className="font-mono-tabular font-semibold text-[var(--cp-text)]">
                {issue.id}
              </span>
              <span aria-hidden="true">·</span>
              <span className={`font-semibold ${getStatusTextClass(issue.status)}`}>
                {issue.status}
              </span>
              <span aria-hidden="true">·</span>
              <span className={getPriorityTextClass(issue.priority)}>
                {issue.priority} Priority
              </span>
              {issue.isDemoRecord && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Demonstration Sample</span>
                </>
              )}
            </div>
            <h2
              id="issue-modal-title"
              className="mt-1 font-display text-lg font-bold text-[#102A43] dark:text-white"
            >
              {issue.title}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close issue details"
            className="rounded-md border border-[var(--cp-border)] p-2 text-[var(--cp-text-muted)] hover:bg-[var(--cp-accent-soft)] hover:text-[var(--cp-text)] min-h-[40px] min-w-[40px] flex items-center justify-center"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="space-y-6 p-6">
          {/* Photograph / Evidence */}
          <figure className="overflow-hidden rounded-lg border border-[var(--cp-border)] bg-[var(--cp-accent-soft)]">
            {issue.imageUrl && !imgFailed ? (
              <img
                src={issue.imageUrl}
                alt={`Uploaded evidence for ${issue.title}`}
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="max-h-72 w-full object-cover"
              />
            ) : (
              <div className="flex h-44 flex-col items-center justify-center text-[var(--cp-text-muted)]">
                <ImageOff className="h-7 w-7 opacity-60" aria-hidden="true" />
                <p className="mt-2 text-xs">No photograph attached for this record</p>
              </div>
            )}
            <figcaption className="flex flex-wrap items-center justify-between gap-2 border-t border-[var(--cp-border)] bg-[var(--cp-surface)] px-4 py-2 text-xs text-[var(--cp-text-muted)]">
              <span>
                Category: {issue.category}
                {issue.duplicateOfId ? ` · Marked duplicate of ${issue.duplicateOfId}` : ''}
              </span>
              {issue.imageUrl && !imgFailed && (
                <button
                  type="button"
                  onClick={() => setShowAnimator((prev) => !prev)}
                  className="inline-flex items-center gap-1 font-semibold text-[#0D9488] dark:text-[#14B8A6] hover:underline"
                >
                  <Film className="h-3.5 w-3.5" aria-hidden="true" />
                  {showAnimator ? 'Hide Video Animator' : 'Animate Photo to Video'}
                </button>
              )}
            </figcaption>
          </figure>

          {showAnimator && issue.imageUrl && !imgFailed && (
            <VideoAnimatorCard
              initialImageDataUrl={issue.imageUrl}
              defaultPrompt={`Slow documentary inspection pan showing ${issue.title} in ${issue.locality}, natural daylight.`}
            />
          )}

          {/* Description & Location */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wide text-[var(--cp-text-muted)]">
              Description
            </h3>
            <p className="mt-1.5 text-sm leading-relaxed text-[var(--cp-text)]">
              {issue.description}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 border-y border-[var(--cp-border)] py-4 text-sm sm:grid-cols-2">
            <div className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
              <div>
                <p className="text-xs text-[var(--cp-text-muted)]">Reported Locality</p>
                <p className="font-medium text-[var(--cp-text)]">
                  {issue.locality}, {issue.city}
                </p>
                <p className="font-mono-tabular text-xs text-[var(--cp-text-muted)]">
                  {issue.latitude.toFixed(4)}, {issue.longitude.toFixed(4)}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Calendar className="mt-0.5 h-4 w-4 shrink-0 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
              <div>
                <p className="text-xs text-[var(--cp-text-muted)]">Submission &amp; Last Update</p>
                <p className="font-medium text-[var(--cp-text)]">
                  Submitted{' '}
                  {new Date(issue.createdAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </p>
                <p className="text-xs text-[var(--cp-text-muted)]">
                  Updated{' '}
                  {new Date(issue.updatedAt).toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                  })}
                </p>
              </div>
            </div>
          </div>

          {/* Chronological Status Log */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wide text-[var(--cp-text-muted)]">
              Status History
            </h3>
            <ol className="mt-3 space-y-3">
              {issue.statusHistory.map((entry, index) => (
                <li
                  key={`${entry.status}-${index}`}
                  className="flex items-start justify-between gap-4 border-b border-[var(--cp-border)] pb-3 last:border-b-0 last:pb-0 text-sm"
                >
                  <div>
                    <p className={`font-semibold ${getStatusTextClass(entry.status)}`}>
                      {entry.status}
                    </p>
                    <p className="mt-0.5 text-xs text-[var(--cp-text)]">{entry.note}</p>
                    <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
                      Logged by {entry.updatedBy}
                    </p>
                  </div>
                  <time
                    dateTime={entry.timestamp}
                    className="shrink-0 font-mono-tabular text-xs text-[var(--cp-text-muted)]"
                  >
                    {new Date(entry.timestamp).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'short',
                    })}
                  </time>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--cp-border)] bg-[var(--cp-bg)] px-6 py-4">
          <button
            type="button"
            onClick={() => onUpvote(issue.id)}
            disabled={hasVoted}
            className={`inline-flex items-center gap-2 rounded-md border px-4 py-2 text-sm font-medium transition-colors min-h-[40px] ${
              hasVoted
                ? 'border-[#14B8A6] bg-[var(--cp-accent-soft)] text-[#0D9488] dark:text-[#14B8A6] cursor-default'
                : 'border-[var(--cp-border)] bg-[var(--cp-surface)] text-[var(--cp-text)] hover:border-[#14B8A6]'
            }`}
          >
            <ThumbsUp className="h-4 w-4" aria-hidden="true" />
            <span className="tabular-nums">
              {hasVoted ? 'Supported by You' : 'Support This Issue'} ({issue.upvotes})
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              onClose();
              onTrack(issue.id);
            }}
            className="inline-flex items-center gap-2 rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-4 py-2 text-sm font-medium text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] transition-colors min-h-[40px]"
          >
            Open Complaint Tracker
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}
