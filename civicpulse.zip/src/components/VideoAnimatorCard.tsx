import { ChangeEvent, useState } from 'react';
import { Film, ImagePlus, Loader2, Download } from 'lucide-react';

interface VideoAnimatorCardProps {
  initialImageDataUrl?: string;
  defaultPrompt?: string;
}

/**
 * Photo-to-Video Animation Studio powered by `gemini-omni-1.2-flash`
 * via the server-side Gemini Interactions API (`POST /api/animate-video`).
 * Supports 16:9 (landscape) and 9:16 (portrait) aspect ratios.
 */
export function VideoAnimatorCard({
  initialImageDataUrl,
  defaultPrompt = 'Slow, steady documentary camera pan across the street scene showing realistic daylight shadows and gentle ambient motion.',
}: VideoAnimatorCardProps) {
  const [sourceImage, setSourceImage] = useState<string | undefined>(
    initialImageDataUrl
  );
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [motionPrompt, setMotionPrompt] = useState(defaultPrompt);
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const activeImage = sourceImage || initialImageDataUrl;

  const handlePhotoUpload = (event: ChangeEvent<HTMLInputElement>) => {
    setErrorMessage(null);
    setVideoUrl(null);
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please choose a valid image file (PNG, JPG, or WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSourceImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleGenerateVideo = async () => {
    if (!activeImage) {
      setErrorMessage('Upload or attach a street photograph first to animate it.');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);
    setVideoUrl(null);

    try {
      let base64Data = '';
      let mimeType = 'image/jpeg';

      if (activeImage.startsWith('data:')) {
        const match = activeImage.match(/^data:([^;]+);base64,(.+)$/);
        if (!match) {
          throw new Error('Could not parse uploaded image data.');
        }
        mimeType = match[1];
        base64Data = match[2];
      } else {
        // Convert local static image URL to base64
        const imgRes = await fetch(activeImage);
        const blob = await imgRes.blob();
        mimeType = blob.type || 'image/jpeg';
        base64Data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const out = String(reader.result || '');
            const idx = out.indexOf(',');
            resolve(idx >= 0 ? out.slice(idx + 1) : out);
          };
          reader.onerror = () => reject(new Error('Failed to encode image.'));
          reader.readAsDataURL(blob);
        });
      }

      const response = await fetch('/api/animate-video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64Data,
          mimeType,
          prompt: motionPrompt,
          aspectRatio,
        }),
      });

      const payload = (await response.json()) as {
        videoUrl?: string;
        error?: string;
      };

      if (!response.ok || !payload.videoUrl) {
        throw new Error(
          payload.error || 'Video generation failed on the server.'
        );
      }

      setVideoUrl(payload.videoUrl);
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : 'Unable to animate image into video.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <section
      aria-label="Animate Photo into Video Studio"
      className="cp-card space-y-4 p-5 sm:p-6"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="inline-flex items-center gap-2 font-display text-base font-semibold text-[#102A43] dark:text-white">
            <Film
              className="h-4 w-4 text-[#0D9488] dark:text-[#14B8A6]"
              aria-hidden="true"
            />
            Animate Evidence Photo into Video
          </h3>
          <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
            Generate a short civic inspection clip from a street photo using{' '}
            <span className="font-mono-tabular">gemini-omni-1.2-flash</span>.
          </p>
        </div>

        {/* Aspect Ratio Selector (16:9 Landscape / 9:16 Portrait) */}
        <div
          role="group"
          aria-label="Video aspect ratio"
          className="inline-flex rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] p-0.5"
        >
          <button
            type="button"
            onClick={() => setAspectRatio('16:9')}
            aria-pressed={aspectRatio === '16:9'}
            className={`rounded px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
              aspectRatio === '16:9'
                ? 'bg-[#102A43] text-white dark:bg-[#14B8A6] dark:text-[#0B1522]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            16:9 Landscape
          </button>
          <button
            type="button"
            onClick={() => setAspectRatio('9:16')}
            aria-pressed={aspectRatio === '9:16'}
            className={`rounded px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
              aspectRatio === '9:16'
                ? 'bg-[#102A43] text-white dark:bg-[#14B8A6] dark:text-[#0B1522]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            9:16 Portrait
          </button>
        </div>
      </div>

      {/* Optional standalone upload if no photo attached yet */}
      <div className="flex flex-wrap items-center gap-3">
        <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)]">
          <ImagePlus className="h-3.5 w-3.5 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
          {activeImage ? 'Choose Different Photo' : 'Upload Photo to Animate'}
          <input
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
            className="sr-only"
          />
        </label>
        {activeImage && (
          <span className="text-xs text-[var(--cp-text-muted)]">
            Source frame ready
          </span>
        )}
      </div>

      {activeImage && (
        <div className="max-w-xs overflow-hidden rounded-md border border-[var(--cp-border)]">
          <img
            src={activeImage}
            alt="Source frame selected for video animation"
            className="max-h-40 w-full object-cover"
          />
        </div>
      )}

      <div>
        <label
          htmlFor="video-motion-prompt"
          className="block text-xs font-medium text-[var(--cp-text)]"
        >
          Motion Instruction
        </label>
        <input
          id="video-motion-prompt"
          type="text"
          value={motionPrompt}
          onChange={(e) => setMotionPrompt(e.target.value)}
          className="mt-1 w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-xs text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={handleGenerateVideo}
          disabled={isGenerating || !activeImage}
          className="inline-flex items-center gap-2 rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-4 py-2 text-xs font-semibold text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] disabled:opacity-60 transition-colors min-h-[38px]"
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              Generating {aspectRatio} Video…
            </>
          ) : (
            <>
              <Film className="h-3.5 w-3.5" aria-hidden="true" />
              Animate Photo into Video
            </>
          )}
        </button>
      </div>

      {errorMessage && (
        <p
          role="alert"
          className="rounded-md border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-3 py-2 text-xs text-rose-700 dark:text-rose-300"
        >
          {errorMessage}
        </p>
      )}

      {videoUrl && (
        <div className="space-y-2 border-t border-[var(--cp-border)] pt-4">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold text-[#0D9488] dark:text-[#14B8A6]">
              Generated Video ({aspectRatio})
            </p>
            <a
              href={videoUrl}
              download={`civicpulse-evidence-${aspectRatio.replace(':', 'x')}.mp4`}
              className="inline-flex items-center gap-1 text-xs font-medium text-[#102A43] dark:text-[#14B8A6] hover:underline"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              Download MP4
            </a>
          </div>
          <video
            src={videoUrl}
            controls
            playsInline
            className={`w-full rounded-md border border-[var(--cp-border)] bg-black ${
              aspectRatio === '9:16' ? 'mx-auto max-w-[260px]' : 'max-h-72'
            }`}
          />
        </div>
      )}
    </section>
  );
}
