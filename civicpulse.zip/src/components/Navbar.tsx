import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { PageRoute } from '../types/issue';

interface NavbarProps {
  currentPage: PageRoute;
  onNavigate: (page: PageRoute) => void;
}

const NAV_ITEMS: { id: PageRoute; label: string }[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'explore', label: 'Explore' },
  { id: 'track', label: 'Track' },
  { id: 'community', label: 'Community' },
  { id: 'admin', label: 'Admin' },
];

/**
 * Semantic <header> and <nav> adhering to a clean 3-zone SaaS top bar contract:
 * Zone 1: CivicPulse wordmark (navigates Home)
 * Zone 2: 5 concise single-line navigation links
 * Zone 3: Single Coral Orange primary CTA ("Report Issue")
 */
export function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSelectPage = (page: PageRoute) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--cp-border)] bg-[var(--cp-surface)]/95 backdrop-blur-md">
      <div className="mx-auto flex h-[72px] max-w-[1200px] items-center justify-between gap-8 px-4 sm:px-6">
        {/* Zone 1: Single-element Brand Wordmark */}
        <a
          href="#home"
          onClick={(event) => {
            event.preventDefault();
            handleSelectPage('home');
          }}
          className="font-display text-xl font-extrabold tracking-tight text-[#172B45] dark:text-white whitespace-nowrap shrink-0"
          aria-label="CivicPulse Home"
        >
          Civic<span className="text-[#159C91] dark:text-[#2DD4BF]">Pulse</span>
        </a>

        {/* Zone 2: Primary Desktop Navigation Links */}
        <nav aria-label="Primary Navigation" className="hidden md:flex items-center gap-8">
          {NAV_ITEMS.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(event) => {
                  event.preventDefault();
                  handleSelectPage(item.id);
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`text-sm font-semibold whitespace-nowrap shrink-0 py-1.5 border-b-2 transition-colors ${
                  isActive
                    ? 'border-[#FF7657] text-[#172B45] dark:text-white'
                    : 'border-transparent text-[#4B5E76] dark:text-slate-300 hover:text-[#172B45] dark:hover:text-white hover:border-[#159C91]/50'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Coral CTA + Mobile Drawer Toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleSelectPage('report')}
            className="cp-btn-primary hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-sm whitespace-nowrap shrink-0 min-h-[42px]"
          >
            Report Issue
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="inline-flex md:hidden items-center justify-center rounded-lg border border-[var(--cp-border)] p-2 text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] min-h-[44px] min-w-[44px]"
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-navigation-drawer"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Responsive Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          id="mobile-navigation-drawer"
          aria-label="Mobile Navigation"
          className="md:hidden border-t border-[var(--cp-border)] bg-[var(--cp-surface)] px-4 py-4 shadow-lg"
        >
          <ul className="flex flex-col gap-1">
            <li>
              <button
                type="button"
                onClick={() => handleSelectPage('home')}
                className={`w-full text-left rounded-lg px-3.5 py-2.5 text-sm font-semibold min-h-[44px] transition-colors ${
                  currentPage === 'home'
                    ? 'bg-[var(--cp-accent-soft)] text-[#172B45] dark:text-white'
                    : 'text-[var(--cp-text)] hover:bg-[var(--cp-bg-subtle)] dark:hover:bg-slate-800'
                }`}
              >
                Home
              </button>
            </li>
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => handleSelectPage(item.id)}
                  className={`w-full text-left rounded-lg px-3.5 py-2.5 text-sm font-semibold min-h-[44px] transition-colors ${
                    currentPage === item.id
                      ? 'bg-[var(--cp-accent-soft)] text-[#172B45] dark:text-white'
                      : 'text-[var(--cp-text)] hover:bg-[var(--cp-bg-subtle)] dark:hover:bg-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              </li>
            ))}
            <li className="pt-2">
              <button
                type="button"
                onClick={() => handleSelectPage('report')}
                className="cp-btn-primary w-full px-4 py-3 text-sm min-h-[44px]"
              >
                Report an Issue
              </button>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
