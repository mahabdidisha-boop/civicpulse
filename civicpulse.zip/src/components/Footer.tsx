import { RotateCcw } from 'lucide-react';
import { PageRoute } from '../types/issue';

interface FooterProps {
  onNavigate: (page: PageRoute) => void;
  onResetDemoData: () => void;
}

/**
 * Semantic <footer> with platform links, demonstration data notice,
 * Google Maps Platform End User Terms link, contact details (<address>), and demo reset control.
 */
export function Footer({ onNavigate, onResetDemoData }: FooterProps) {
  return (
    <footer className="mt-16 border-t border-[var(--cp-border)] bg-[var(--cp-surface)]">
      <div className="mx-auto max-w-[1200px] px-4 py-12 sm:px-6">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {/* Brand Summary */}
          <div className="md:col-span-2">
            <p className="font-display text-lg font-bold text-[#102A43] dark:text-white">
              Civic<span className="text-[#0D9488] dark:text-[#14B8A6]">Pulse</span>
            </p>
            <p className="mt-2 max-w-md text-sm text-[var(--cp-text-muted)]">
              Your Neighbourhood. Your Voice. Your Impact. A hyperlocal civic issue reporting
              and infrastructure transparency platform built to help residents document and track
              local maintenance needs.
            </p>
            <p className="mt-3 text-xs text-[var(--cp-text-muted)]">
              Notice: Preloaded records are clearly marked as demonstration samples from Indian
              urban localities. Sign in with Google to save and sync your own citizen reports in
              Cloud Firestore.
            </p>
            <p className="mt-2 text-xs text-[var(--cp-text-muted)]">
              Maps features integrate Google Maps Platform subject to{' '}
              <a
                href="https://maps.google.com/help/terms_maps/?utm_campaign=gmp_mcp_codeassist_v1_aistudio"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-[#102A43] dark:hover:text-white"
              >
                Google Maps End User Terms
              </a>{' '}
              and{' '}
              <a
                href="https://policies.google.com/privacy?utm_campaign=gmp_mcp_codeassist_v1_aistudio"
                target="_blank"
                rel="noopener noreferrer"
                className="underline hover:text-[#102A43] dark:hover:text-white"
              >
                Google Privacy Policy
              </a>
              .
            </p>
          </div>

          {/* Platform Links */}
          <div>
            <h2 className="font-display text-sm font-semibold text-[#102A43] dark:text-white">
              Platform
            </h2>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('report')}
                  className="text-[var(--cp-text-muted)] hover:text-[#102A43] dark:hover:text-white transition-colors"
                >
                  Report an Issue
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('explore')}
                  className="text-[var(--cp-text-muted)] hover:text-[#102A43] dark:hover:text-white transition-colors"
                >
                  Explore Local Issues
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('track')}
                  className="text-[var(--cp-text-muted)] hover:text-[#102A43] dark:hover:text-white transition-colors"
                >
                  Track Complaint
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('dashboard')}
                  className="text-[var(--cp-text-muted)] hover:text-[#102A43] dark:hover:text-white transition-colors"
                >
                  Citizen Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Contact & Demo Controls */}
          <div>
            <h2 className="font-display text-sm font-semibold text-[#102A43] dark:text-white">
              Civic Desk &amp; Demo
            </h2>
            <address className="mt-3 not-italic space-y-1.5 text-sm text-[var(--cp-text-muted)]">
              <p>CivicPulse Open Infrastructure Lab</p>
              <p>
                Email:{' '}
                <a
                  href="mailto:civicdesk@civicpulse.example"
                  className="underline decoration-slate-300 dark:decoration-slate-600 hover:text-[#102A43] dark:hover:text-white"
                >
                  civicdesk@civicpulse.example
                </a>
              </p>
              <p>Support Hours: Mon–Sat, 09:00–18:00 IST</p>
            </address>

            <button
              type="button"
              onClick={onResetDemoData}
              className="mt-4 inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] px-3 py-1.5 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              Reset Demo Data
            </button>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-[var(--cp-border)] pt-6 text-xs text-[var(--cp-text-muted)] sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} CivicPulse Platform. Built for transparent neighbourhoods.</p>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => onNavigate('community')}
              className="hover:text-[#102A43] dark:hover:text-white"
            >
              Community Watch
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className="hover:text-[#102A43] dark:hover:text-white"
            >
              Demo Admin Console
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
