import { FormEvent, useEffect, useRef, useState } from 'react';
import { ExternalLink, Loader2, MessageSquare, Send, Trash2, X } from 'lucide-react';
import { ChatMessage } from '../types/issue';

interface CivicChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

type ChatMode = 'general' | 'fast' | 'complex' | 'deep';

const INITIAL_ASSISTANT_MESSAGE: ChatMessage = {
  id: 'welcome-msg',
  role: 'model',
  text: 'Hello! I am the CivicPulse Neighbourhood Assistant. Ask me how to categorize a civic issue, estimate priority, draft a clear privacy-safe description, or check municipal escalation channels.',
  modelUsed: 'gemini-4-hydrogen',
  timestamp: new Date().toISOString(),
};

/**
 * Multi-turn Gemini Chatbot Drawer maintaining conversation history,
 * scrollable message thread, role system instruction, model selector,
 * and optional Google Search grounding.
 */
export function CivicChatDrawer({ isOpen, onClose }: CivicChatDrawerProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('civicpulse_chat_history_v1');
      if (saved) {
        const parsed = JSON.parse(saved) as ChatMessage[];
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [INITIAL_ASSISTANT_MESSAGE];
  });

  const [inputText, setInputText] = useState('');
  const [mode, setMode] = useState<ChatMode>('general');
  const [useSearch, setUseSearch] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('civicpulse_chat_history_v1', JSON.stringify(messages));
    } catch {
      // Ignore storage quota errors
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSend = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || isSending) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: trimmed,
      timestamp: new Date().toISOString(),
    };

    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    setInputText('');
    setIsSending(true);
    setError(null);

    try {
      const apiMessages = nextHistory
        .filter((m) => m.id !== 'welcome-msg')
        .map((m) => ({ role: m.role, text: m.text }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          mode,
          useSearch,
        }),
      });

      const payload = (await response.json()) as {
        reply?: string;
        modelUsed?: string;
        sources?: Array<{ title: string; uri: string }>;
        error?: string;
      };

      if (!response.ok || !payload.reply) {
        throw new Error(payload.error || 'Failed to get response from Civic Assistant.');
      }

      const botMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: payload.reply,
        modelUsed: payload.modelUsed,
        sources: payload.sources,
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to connect to Civic Assistant.'
      );
    } finally {
      setIsSending(false);
    }
  };

  const handleClear = () => {
    setMessages([INITIAL_ASSISTANT_MESSAGE]);
    setError(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-950/50 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="CivicPulse Neighbourhood Assistant Chat"
      onClick={onClose}
    >
      <aside
        className="flex h-full w-full max-w-md flex-col border-l border-[var(--cp-border)] bg-[var(--cp-surface)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-[var(--cp-border)] px-5 py-4">
          <div className="flex items-center gap-2">
            <MessageSquare
              className="h-5 w-5 text-[#0D9488] dark:text-[#14B8A6]"
              aria-hidden="true"
            />
            <div>
              <h2 className="font-display text-sm font-bold text-[#102A43] dark:text-white">
                CivicPulse Assistant
              </h2>
              <p className="text-[11px] text-[var(--cp-text-muted)]">
                Multi-turn civic reporting &amp; municipal guide
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleClear}
              title="Clear conversation history"
              aria-label="Clear conversation history"
              className="rounded p-2 text-[var(--cp-text-muted)] hover:bg-[var(--cp-accent-soft)] hover:text-[var(--cp-text)]"
            >
              <Trash2 className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close CivicPulse Assistant"
              className="rounded p-2 text-[var(--cp-text-muted)] hover:bg-[var(--cp-accent-soft)] hover:text-[var(--cp-text)]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Model Mode & Search Grounding Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--cp-border)] bg-[var(--cp-bg)] px-4 py-2.5 text-xs">
          <div className="flex items-center gap-1.5">
            <label htmlFor="chat-model-mode" className="text-[var(--cp-text-muted)]">
              Task Mode:
            </label>
            <select
              id="chat-model-mode"
              value={mode}
              onChange={(e) => setMode(e.target.value as ChatMode)}
              className="rounded border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2 py-1 text-xs text-[var(--cp-text)]"
            >
              <option value="general">General (gemini-4-hydrogen)</option>
              <option value="fast">Fast (gemini-3.1-flash-lite)</option>
              <option value="complex">Complex (gemini-4-argon)</option>
              <option value="deep">Deep Reasoning (gemini-4-carbon)</option>
            </select>
          </div>

          <label className="inline-flex cursor-pointer items-center gap-1.5 text-[var(--cp-text)]">
            <input
              type="checkbox"
              checked={useSearch}
              onChange={(e) => setUseSearch(e.target.checked)}
              className="rounded accent-[#14B8A6]"
            />
            <span>Google Search</span>
          </label>
        </div>

        {/* Scrollable Message Thread */}
        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.role === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[88%] rounded-lg px-3.5 py-2.5 text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-[#102A43] text-white dark:bg-[#14B8A6] dark:text-[#0B1522]'
                    : 'border border-[var(--cp-border)] bg-[var(--cp-bg)] text-[var(--cp-text)]'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>

                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-2.5 border-t border-[var(--cp-border)] pt-2">
                    <p className="text-[11px] font-semibold text-[var(--cp-text-muted)]">
                      Grounded Sources:
                    </p>
                    <ul className="mt-1 space-y-1">
                      {msg.sources.slice(0, 4).map((src, i) => (
                        <li key={`${src.uri}-${i}`}>
                          <a
                            href={src.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-[#0D9488] dark:text-[#14B8A6] hover:underline"
                          >
                            <span className="max-w-[230px] truncate">{src.title}</span>
                            <ExternalLink className="h-3 w-3 shrink-0" />
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              <span className="mt-1 px-1 font-mono-tabular text-[10px] text-[var(--cp-text-muted)]">
                {msg.role === 'user' ? 'You' : msg.modelUsed || 'Assistant'}
              </span>
            </div>
          ))}

          {isSending && (
            <div className="flex items-center gap-2 text-xs text-[var(--cp-text-muted)]">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-[#14B8A6]" />
              <span>Thinking…</span>
            </div>
          )}

          {error && (
            <p
              role="alert"
              className="rounded-md border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-3 py-2 text-xs text-rose-700 dark:text-rose-300"
            >
              {error}
            </p>
          )}

          <div ref={scrollEndRef} />
        </div>

        {/* Message Input Form */}
        <form
          onSubmit={handleSend}
          className="border-t border-[var(--cp-border)] bg-[var(--cp-surface)] p-4"
        >
          <div className="flex gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about reporting, priority, or local portals…"
              aria-label="Message CivicPulse Assistant"
              className="flex-1 rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2.5 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            />
            <button
              type="submit"
              disabled={isSending || !inputText.trim()}
              aria-label="Send message"
              className="inline-flex items-center justify-center rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-4 py-2.5 text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </form>
      </aside>
    </div>
  );
}
