import { FormEvent, useState } from 'react';
import { ExternalLink, Globe, Loader2, Search } from 'lucide-react';
import { GroundedSource } from '../types/issue';

interface CivicSearchPanelProps {
  defaultLocality?: string;
  defaultCity?: string;
}

/**
 * Live Municipal & Civic Advisories Lookup powered by Gemini Search Grounding
 * (`gemini-4-hydrogen` with `googleSearch` tool on the server).
 */
export function CivicSearchPanel({
  defaultLocality = '',
  defaultCity = '',
}: CivicSearchPanelProps) {
  const [query, setQuery] = useState(
    defaultLocality
      ? `Official municipal ward grievance portal and road/drainage helpline for ${defaultLocality}`
      : 'Official municipal civic grievance portal and helpline for Indiranagar Bengaluru'
  );
  const [locality, setLocality] = useState(defaultLocality);
  const [city, setCity] = useState(defaultCity);
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<string | null>(null);
  const [sources, setSources] = useState<GroundedSource[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/search-civic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: query.trim(), locality, city }),
      });

      const payload = (await response.json()) as {
        answer?: string;
        sources?: GroundedSource[];
        error?: string;
      };

      if (!response.ok || !payload.answer) {
        throw new Error(payload.error || 'Search lookup failed.');
      }

      setAnswer(payload.answer);
      setSources(Array.isArray(payload.sources) ? payload.sources : []);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to fetch grounded civic information.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      aria-labelledby="civic-search-heading"
      className="cp-card p-5 sm:p-6"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2
            id="civic-search-heading"
            className="inline-flex items-center gap-2 font-display text-base font-semibold text-[#102A43] dark:text-white"
          >
            <Globe
              className="h-4 w-4 text-[#0D9488] dark:text-[#14B8A6]"
              aria-hidden="true"
            />
            Live Municipal &amp; Civic Info Lookup (Google Search)
          </h2>
          <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
            Query current municipal portals, ward contacts, or local weather and
            infrastructure advisories grounded with Google Search.
          </p>
        </div>
      </div>

      <form onSubmit={handleSearch} className="mt-4 space-y-3">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <input
            type="text"
            value={locality}
            onChange={(e) => setLocality(e.target.value)}
            placeholder="Locality (optional, e.g., Bandra West)"
            aria-label="Locality name"
            className="rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-xs text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
          />
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="City (optional, e.g., Mumbai)"
            aria-label="City name"
            className="rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] px-3 py-2 text-xs text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
          />
        </div>

        <div className="flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--cp-text-muted)]"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask for municipal portals, ward numbers, or current advisories…"
              aria-label="Civic search query"
              className="w-full rounded-md border border-[var(--cp-border)] bg-[var(--cp-bg)] py-2 pl-9 pr-3 text-sm text-[var(--cp-text)] focus:border-[#14B8A6] focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-[#102A43] dark:bg-[#14B8A6] px-4 py-2 text-xs font-semibold text-white dark:text-[#0B1522] hover:bg-[#1A3B5C] dark:hover:bg-[#0D9488] disabled:opacity-60 whitespace-nowrap min-h-[38px]"
          >
            {loading ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                Searching…
              </>
            ) : (
              'Search Web Info'
            )}
          </button>
        </div>
      </form>

      {error && (
        <p
          role="alert"
          className="mt-3 rounded-md border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/30 px-3 py-2 text-xs text-rose-700 dark:text-rose-300"
        >
          {error}
        </p>
      )}

      {answer && (
        <div className="mt-4 space-y-3 border-t border-[var(--cp-border)] pt-4">
          <div className="whitespace-pre-wrap text-sm leading-relaxed text-[var(--cp-text)]">
            {answer}
          </div>

          {sources.length > 0 && (
            <div className="pt-2">
              <p className="text-xs font-semibold text-[var(--cp-text-muted)]">
                Verified Search Sources:
              </p>
              <ul className="mt-1.5 flex flex-wrap gap-2">
                {sources.slice(0, 6).map((source, index) => (
                  <li key={`${source.uri}-${index}`}>
                    <a
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 rounded border border-[var(--cp-border)] bg-[var(--cp-bg)] px-2.5 py-1 text-xs text-[#0D9488] dark:text-[#14B8A6] hover:underline"
                    >
                      <span className="max-w-[200px] truncate">{source.title}</span>
                      <ExternalLink className="h-3 w-3 shrink-0" aria-hidden="true" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
