import { useState } from 'react';
import { Download, Film, Loader2 } from 'lucide-react';

interface VideoEvidenceAnimatorProps {
  imageDataUrl: string;
  defaultPrompt?: string;
}

/**
 * Photo-to-Video Animation studio component.
 * Sends an uploaded image DataURL to `/api/animate-photo` (server-side Gemini
 * Interactions API using `gemini-omni-1.2-flash`) in either 16:9 or 9:16 aspect ratio.
 */
export function VideoEvidenceAnimator({
  imageDataUrl,
  defaultPrompt,
}: VideoEvidenceAnimatorProps) {
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [motionPrompt, setMotionPrompt] = useState(
    defaultPrompt ||
      'Smooth documentary camera pan across this street scene showing realistic daylight movement and civic context.'
  );
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);

  const handleGenerateVideo = async () => {
    setErrorMessage(null);
    setIsGenerating(true);
    setVideoSrc(null);

    try {
      // Extract mimeType and base64 payload from DataURL
      let mimeType = 'image/jpeg';
      let base64 = imageDataUrl;

      if (imageDataUrl.startsWith('data:')) {
        const [header, data] = imageDataUrl.split(',');
        const mimeMatch = header.match(/data:([^;]+);/);
        if (mimeMatch?.[1]) mimeType = mimeMatch[1];
        base64 = data || '';
      } else {
        // Fetch static/local image asset and convert to base64
        const imgRes = await fetch(imageDataUrl);
        const blob = await imgRes.blob();
        mimeType = blob.type || 'image/jpeg';
        base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            const out = typeof reader.result === 'string' ? reader.result.split(',')[1] || '' : '';
            resolve(out);
          };
          reader.onerror = () => reject(new Error('Failed to read image bytes.'));
          reader.readAsDataURL(blob);
        });
      }

      const response = await fetch('/api/animate-photo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType,
          prompt: motionPrompt,
          aspectRatio,
        }),
      });

      const payload = (await response.json()) as {
        videoBase64?: string | null;
        videoUri?: string | null;
        mimeType?: string;
        error?: string;
      };

      if (!response.ok) {
        throw new Error(payload.error || 'Video generation request failed.');
      }

      if (payload.videoBase64) {
        setVideoSrc(`data:${payload.mimeType || 'video/mp4'};base64,${payload.videoBase64}`);
      } else if (payload.videoUri) {
        setVideoSrc(payload.videoUri);
      } else {
        throw new Error('No video stream was returned by the server.');
      }
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to generate video right now.'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="mt-4 rounded-xl border border-[var(--cp-border)] bg-[var(--cp-bg)] p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Film className="h-4 w-4 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
          <h3 className="font-display text-sm font-bold text-[#172B45] dark:text-white">
            Animate Photo into Video Evidence
          </h3>
        </div>

        {/* Aspect Ratio Selector: 16:9 or 9:16 */}
        <div
          role="group"
          aria-label="Video Aspect Ratio"
          className="inline-flex rounded-lg border border-[var(--cp-border)] bg-[var(--cp-surface)] p-0.5 text-xs"
        >
          <button
            type="button"
            onClick={() => setAspectRatio('16:9')}
            aria-pressed={aspectRatio === '16:9'}
            className={`rounded-md px-2.5 py-1 font-semibold transition-colors ${
              aspectRatio === '16:9'
                ? 'bg-[#172B45] text-white dark:bg-[#2DD4BF] dark:text-[#0E1A2B]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            16:9 Landscape
          </button>
          <button
            type="button"
            onClick={() => setAspectRatio('9:16')}
            aria-pressed={aspectRatio === '9:16'}
            className={`rounded-md px-2.5 py-1 font-semibold transition-colors ${
              aspectRatio === '9:16'
                ? 'bg-[#172B45] text-white dark:bg-[#2DD4BF] dark:text-[#0E1A2B]'
                : 'text-[var(--cp-text-muted)] hover:text-[var(--cp-text)]'
            }`}
          >
            9:16 Portrait
          </button>
        </div>
      </div>

      <div>
        <label
          htmlFor="video-motion-prompt"
          className="block text-xs font-semibold text-[var(--cp-text-muted)]"
        >
          Motion Instruction
        </label>
        <input
          id="video-motion-prompt"
          type="text"
          value={motionPrompt}
          onChange={(e) => setMotionPrompt(e.target.value)}
          className="mt-1.5 w-full rounded-lg border border-[var(--cp-border)] bg-[var(--cp-surface)] px-3.5 py-2 text-xs text-[var(--cp-text)] focus:border-[#159C91] focus:outline-none"
        />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={handleGenerateVideo}
          disabled={isGenerating}
          className="cp-btn-primary inline-flex items-center gap-2 px-4 py-2 text-xs disabled:opacity-60"
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
              Generating {aspectRatio} Video…
            </>
          ) : (
            <>
              <Film className="h-3.5 w-3.5" aria-hidden="true" />
              Generate {aspectRatio} Video
            </>
          )}
        </button>

        {videoSrc && (
          <a
            href={videoSrc}
            download={`civicpulse-evidence-${aspectRatio.replace(':', 'x')}.mp4`}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0F7E75] dark:text-[#2DD4BF] hover:underline"
          >
            <Download className="h-3.5 w-3.5" aria-hidden="true" />
            Download MP4
          </a>
        )}
      </div>

      {errorMessage && (
        <p
          role="alert"
          className="rounded-lg border border-rose-300 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/30 px-3.5 py-2.5 text-xs text-rose-700 dark:text-rose-300"
        >
          {errorMessage}
        </p>
      )}

      {videoSrc && (
        <div className="overflow-hidden rounded-xl border border-[var(--cp-border)] bg-black">
          <video
            src={videoSrc}
            controls
            playsInline
            className={
              aspectRatio === '9:16'
                ? 'mx-auto max-h-96 aspect-[9/16]'
                : 'w-full aspect-video'
            }
          />
        </div>
      )}
    </div>
  );
}
