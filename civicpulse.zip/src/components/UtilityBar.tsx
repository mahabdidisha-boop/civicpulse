import { useState } from 'react';
import { User } from 'firebase/auth';
import {
  Bell,
  Check,
  LogIn,
  LogOut,
  MessageSquare,
  Moon,
  Sun,
  X,
} from 'lucide-react';
import { AppNotification } from '../types/issue';

interface UtilityBarProps {
  isDark: boolean;
  onToggleTheme: () => void;
  notifications: AppNotification[];
  onMarkAllRead: () => void;
  onSelectNotificationIssue: (issueId: string) => void;
  activeToast: AppNotification | null;
  onDismissToast: () => void;
  user: User | null;
  authLoading: boolean;
  onSignIn: () => void;
  onSignOut: () => void;
  onOpenChat: () => void;
}

/**
 * Clean non-sticky workspace utility strip placed below the main navigation bar.
 * Provides Google Sign-In status, Civic Assistant chat launcher, status notifications, and Light/Dark toggle.
 */
export function UtilityBar({
  isDark,
  onToggleTheme,
  notifications,
  onMarkAllRead,
  onSelectNotificationIssue,
  activeToast,
  onDismissToast,
  user,
  authLoading,
  onSignIn,
  onSignOut,
  onOpenChat,
}: UtilityBarProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <>
      <div className="border-b border-[var(--cp-border)] bg-[var(--cp-bg)]">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-3 px-4 py-2 text-xs sm:px-6">
          <p className="text-[var(--cp-text-muted)] truncate">
            Your Neighbourhood. Your Voice. Your Impact.
          </p>

          <div className="relative flex flex-wrap items-center gap-2 shrink-0">
            {/* Firebase Google Sign-In / Account Control */}
            {authLoading ? (
              <span className="px-2 py-1 text-xs text-[var(--cp-text-muted)]">
                Checking account…
              </span>
            ) : user ? (
              <div className="inline-flex items-center gap-2 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2.5 py-1">
                <span className="max-w-[140px] truncate font-medium text-[#102A43] dark:text-white">
                  {user.displayName || user.email}
                </span>
                <button
                  type="button"
                  onClick={onSignOut}
                  className="inline-flex items-center gap-1 text-[var(--cp-text-muted)] hover:text-rose-600 dark:hover:text-rose-400 whitespace-nowrap"
                  title="Sign out"
                >
                  <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={onSignIn}
                className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2.5 py-1.5 text-xs font-medium text-[#102A43] dark:text-white hover:bg-[var(--cp-accent-soft)] transition-colors whitespace-nowrap"
              >
                <LogIn className="h-3.5 w-3.5 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
                <span>Sign In with Google</span>
              </button>
            )}

            {/* Multi-Turn Gemini Civic Assistant Trigger */}
            <button
              type="button"
              onClick={onOpenChat}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2.5 py-1.5 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors whitespace-nowrap"
            >
              <MessageSquare
                className="h-3.5 w-3.5 text-[#0D9488] dark:text-[#14B8A6]"
                aria-hidden="true"
              />
              <span>Civic Assistant</span>
            </button>

            {/* Notification Center Button */}
            <button
              type="button"
              onClick={() => setDrawerOpen((prev) => !prev)}
              aria-expanded={drawerOpen}
              aria-label={`Notifications (${unreadCount} unread)`}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2.5 py-1.5 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors whitespace-nowrap"
            >
              <Bell className="h-3.5 w-3.5 text-[#0D9488] dark:text-[#14B8A6]" aria-hidden="true" />
              <span>Updates</span>
              {unreadCount > 0 && (
                <span className="font-mono-tabular font-semibold text-[#0D9488] dark:text-[#14B8A6]">
                  ({unreadCount})
                </span>
              )}
            </button>

            {/* Light / Dark Theme Toggle */}
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="inline-flex items-center gap-1.5 rounded-md border border-[var(--cp-border)] bg-[var(--cp-surface)] px-2.5 py-1.5 text-xs font-medium text-[var(--cp-text)] hover:bg-[var(--cp-accent-soft)] transition-colors whitespace-nowrap"
            >
              {isDark ? (
                <>
                  <Sun className="h-3.5 w-3.5 text-amber-400" aria-hidden="true" />
                  <span>Light</span>
                </>
              ) : (
                <>
                  <Moon className="h-3.5 w-3.5 text-[#102A43]" aria-hidden="true" />
                  <span>Dark</span>
                </>
              )}
            </button>

            {/* Dropdown Panel */}
            {drawerOpen && (
              <div
                className="absolute right-0 top-full z-30 mt-2 w-80 max-w-[90vw] rounded-[10px] border border-[var(--cp-border)] bg-[var(--cp-surface)] shadow-lg"
                role="region"
                aria-label="Status Notifications"
              >
                <div className="flex items-center justify-between border-b border-[var(--cp-border)] px-4 py-2.5">
                  <span className="font-display text-xs font-semibold text-[#102A43] dark:text-white">
                    Complaint Status Updates
                  </span>
                  {unreadCount > 0 && (
                    <button
                      type="button"
                      onClick={onMarkAllRead}
                      className="inline-flex items-center gap-1 text-xs font-medium text-[#0D9488] dark:text-[#14B8A6] hover:underline"
                    >
                      <Check className="h-3 w-3" aria-hidden="true" />
                      Mark read
                    </button>
                  )}
                </div>

                {notifications.length === 0 ? (
                  <p className="p-4 text-xs text-[var(--cp-text-muted)]">
                    No status notifications yet. Updates appear when a complaint progresses.
                  </p>
                ) : (
                  <ul className="max-h-72 divide-y divide-[var(--cp-border)] overflow-y-auto">
                    {notifications.slice(0, 8).map((item) => (
                      <li key={item.id}>
                        <button
                          type="button"
                          onClick={() => {
                            setDrawerOpen(false);
                            onSelectNotificationIssue(item.issueId);
                          }}
                          className={`w-full px-4 py-3 text-left transition-colors hover:bg-[var(--cp-accent-soft)] ${
                            item.read ? 'opacity-75' : ''
                          }`}
                        >
                          <p className="text-xs font-semibold text-[#102A43] dark:text-white">
                            {item.title}
                          </p>
                          <p className="mt-0.5 text-xs text-[var(--cp-text-muted)]">
                            {item.message}
                          </p>
                          <time
                            dateTime={item.createdAt}
                            className="mt-1 block font-mono-tabular text-[11px] text-[var(--cp-text-muted)]"
                          >
                            {new Date(item.createdAt).toLocaleString('en-IN', {
                              day: 'numeric',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </time>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Live Toast Alert for Status Updates */}
      {activeToast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 flex max-w-sm items-start justify-between gap-3 rounded-[10px] border border-[#14B8A6] bg-[var(--cp-surface)] p-4 shadow-lg"
        >
          <div>
            <p className="text-xs font-semibold text-[#0D9488] dark:text-[#14B8A6]">
              {activeToast.title}
            </p>
            <p className="mt-1 text-xs text-[var(--cp-text)]">{activeToast.message}</p>
            <button
              type="button"
              onClick={() => {
                onSelectNotificationIssue(activeToast.issueId);
                onDismissToast();
              }}
              className="mt-2 text-xs font-semibold text-[#102A43] dark:text-[#14B8A6] underline"
            >
              Track Complaint
            </button>
          </div>
          <button
            type="button"
            onClick={onDismissToast}
            aria-label="Dismiss notification"
            className="rounded p-1 text-[var(--cp-text-muted)] hover:bg-[var(--cp-accent-soft)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
    </>
  );
}
