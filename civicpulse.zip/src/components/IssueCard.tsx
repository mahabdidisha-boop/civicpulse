import { MapPin, ThumbsUp, ArrowRight, ImageOff } from 'lucide-react';
import { useState } from 'react';
import { CivicIssue } from '../types/issue';

interface IssueCardProps {
  issue: CivicIssue;
  hasVoted?: boolean;
  onSelect: (issue: CivicIssue) => void;
  onUpvote?: (issueId: string) => void;
  onTrack?: (issueId: string) => void;
}

/**
 * Returns accessible text color pair for complaint status (always paired with explicit text).
 */
export function getStatusTextClass(status: CivicIssue['status']): string {
  switch (status) {
    case 'Resolved':
      return 'text-emerald-700 dark:text-emerald-400';
    case 'In Progress':
      return 'text-[#0F7E75] dark:text-[#2DD4BF]';
    case 'Verified':
      return 'text-teal-700 dark:text-teal-400';
    case 'Under Review':
      return 'text-amber-700 dark:text-amber-400';
    default:
      return 'text-[#4B5E76] dark:text-slate-300';
  }
}

export function getPriorityTextClass(priority: CivicIssue['priority']): string {
  switch (priority) {
    case 'High':
      return 'text-[#D64026] dark:text-[#FF7657]';
    case 'Medium':
      return 'text-amber-700 dark:text-amber-400';
    default:
      return 'text-[#4B5E76] dark:text-slate-400';
  }
}

/**
 * Semantic <article> card representing a single hyperlocal civic issue.
 * Uses clean unboxed metadata with typographic separators (·) on a crisp white elevated card.
 */
export function IssueCard({
  issue,
  hasVoted = false,
  onSelect,
  onUpvote,
  onTrack,
}: IssueCardProps) {
  const [imageError, setImageError] = useState(false);

  const formattedDate = new Date(issue.createdAt).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <article className="cp-card cp-card-interactive flex flex-col overflow-hidden">
      {/* Optional Evidence Thumbnail with Graceful Fallback Container */}
      <div className="relative aspect-[16/10] w-full overflow-hidden bg-[var(--cp-accent-soft)] border-b border-[var(--cp-border)]">
        {issue.imageUrl && !imageError ? (
          <img
            src={issue.imageUrl}
            alt={`Reported civic issue: ${issue.title} in ${issue.locality}`}
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
            className="h-full w-full object-cover transition-transform duration-300 hover:scale-[1.02]"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center px-4 text-center text-[var(--cp-text-muted)]">
            <ImageOff className="h-6 w-6 opacity-60" aria-hidden="true" />
            <span className="mt-1.5 text-xs font-medium">{issue.category}</span>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="flex flex-1 flex-col p-6">
        {/* Clean unboxed metadata row */}
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[var(--cp-text-muted)]">
          <span className="font-mono-tabular font-semibold text-[var(--cp-text)]">{issue.id}</span>
          <span aria-hidden="true">·</span>
          <span className={`font-bold ${getStatusTextClass(issue.status)}`}>{issue.status}</span>
          <span aria-hidden="true">·</span>
          <span className={`font-semibold ${getPriorityTextClass(issue.priority)}`}>
            {issue.priority} Priority
          </span>
          {issue.isDemoRecord && (
            <>
              <span aria-hidden="true">·</span>
              <span>Sample Record</span>
            </>
          )}
        </div>

        {/* Issue Title */}
        <h3 className="mt-3 font-display text-base font-bold leading-snug text-[#172B45] dark:text-white">
          <button
            type="button"
            onClick={() => onSelect(issue)}
            className="text-left hover:text-[#0F7E75] dark:hover:text-[#2DD4BF] transition-colors"
          >
            {issue.title}
          </button>
        </h3>

        <p className="mt-1.5 text-xs font-semibold text-[#0F7E75] dark:text-[#2DD4BF]">
          {issue.category}
        </p>

        <p className="mt-2.5 line-clamp-2 text-sm leading-relaxed text-[var(--cp-text-muted)]">
          {issue.description}
        </p>

        {/* Location & Date Footer Metadata */}
        <div className="mt-auto pt-4">
          <div className="flex items-center justify-between gap-2 border-t border-[var(--cp-border)] pt-3.5 text-xs text-[var(--cp-text-muted)]">
            <span className="inline-flex items-center gap-1.5 truncate">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-[#159C91] dark:text-[#2DD4BF]" aria-hidden="true" />
              <span className="truncate font-medium">
                {issue.locality}, {issue.city}
              </span>
            </span>
            <time dateTime={issue.createdAt} className="shrink-0 tabular-nums">
              {formattedDate}
            </time>
          </div>

          {/* Action Row */}
          <div className="mt-4 flex items-center justify-between gap-2">
            {onUpvote ? (
              <button
                type="button"
                onClick={() => onUpvote(issue.id)}
                disabled={hasVoted}
                aria-pressed={hasVoted}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors min-h-[36px] ${
                  hasVoted
                    ? 'border-[#159C91] bg-[var(--cp-accent-soft)] text-[#0F7E75] dark:text-[#2DD4BF] cursor-default'
                    : 'border-[var(--cp-border)] bg-[var(--cp-bg)] text-[var(--cp-text)] hover:border-[#159C91] hover:bg-[var(--cp-accent-soft)]'
                }`}
              >
                <ThumbsUp className="h-3.5 w-3.5" aria-hidden="true" />
                <span className="tabular-nums">
                  {hasVoted ? 'Supported' : 'Support'} ({issue.upvotes})
                </span>
              </button>
            ) : (
              <span className="text-xs text-[var(--cp-text-muted)] tabular-nums">
                {issue.upvotes} citizen supports
              </span>
            )}

            <div className="flex items-center gap-3.5">
              {onTrack && (
                <button
                  type="button"
                  onClick={() => onTrack(issue.id)}
                  className="text-xs font-semibold text-[var(--cp-text-muted)] hover:text-[#172B45] dark:hover:text-white underline decoration-[var(--cp-border)] underline-offset-4 whitespace-nowrap transition-colors"
                >
                  Track
                </button>
              )}
              <button
                type="button"
                onClick={() => onSelect(issue)}
                className="inline-flex items-center gap-1 text-xs font-bold text-[#172B45] dark:text-[#2DD4BF] hover:text-[#0F7E75] whitespace-nowrap transition-colors"
              >
                Details
                <ArrowRight className="h-3.5 w-3.5 text-[#FF7657]" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}
