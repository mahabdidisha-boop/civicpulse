import { useEffect, useRef, useState } from 'react';
import {
  APILoadingStatus,
  APIProvider,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
} from '@vis.gl/react-google-maps';
import L from 'leaflet';
import { CivicIssue, IssueCategory } from '../types/issue';

interface IssuesMapProps {
  mode: 'explore' | 'pick';
  issues?: CivicIssue[];
  onSelectIssue?: (issue: CivicIssue) => void;
  selectedCoordinates?: { latitude: number; longitude: number } | null;
  onPickLocation?: (latitude: number, longitude: number) => void;
  heightClass?: string;
}

function getCategoryMarkerColor(category: IssueCategory): string {
  switch (category) {
    case 'Road damage / Potholes':
      return '#D97706';
    case 'Garbage and waste management':
      return '#15803D';
    case 'Water leakage':
      return '#0284C7';
    case 'Drainage and sewage':
      return '#7C3AED';
    case 'Streetlight problems':
      return '#EAB308';
    case 'Public infrastructure damage':
      return '#DC2626';
    case 'Traffic and road safety':
      return '#EA580C';
    default:
      return '#102A43';
  }
}

/**
 * Individual Google Maps AdvancedMarker with anchored InfoWindow.
 */
function IssueAdvancedMarker({
  issue,
  isOpen,
  onOpen,
  onClose,
  onSelectIssue,
}: {
  issue: CivicIssue;
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
  onSelectIssue?: (issue: CivicIssue) => void;
}) {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const pinColor = getCategoryMarkerColor(issue.category);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={{ lat: issue.latitude, lng: issue.longitude }}
        onClick={onOpen}
        title={`${issue.id}: ${issue.title}`}
      >
        <Pin
          background={pinColor}
          borderColor="#FFFFFF"
          glyphColor="#FFFFFF"
          scale={1.05}
        />
      </AdvancedMarker>

      {isOpen && marker && (
        <InfoWindow anchor={marker} maxWidth={260} onCloseClick={onClose}>
          <div className="space-y-1.5 p-1 text-slate-800">
            <p className="font-mono text-xs text-slate-500">
              {issue.id} · {issue.status}
            </p>
            <p className="text-sm font-semibold leading-snug text-slate-900">
              {issue.title}
            </p>
            <p className="text-xs text-slate-600">
              {issue.locality}, {issue.city}
            </p>
            <p className="text-xs font-medium" style={{ color: pinColor }}>
              {issue.category}
            </p>
            {onSelectIssue && (
              <button
                type="button"
                onClick={() => onSelectIssue(issue)}
                className="mt-1 w-full rounded bg-[#102A43] px-2.5 py-1.5 text-xs font-medium text-white hover:bg-[#1A3B5C]"
              >
                View Full Details
              </button>
            )}
          </div>
        </InfoWindow>
      )}
    </>
  );
}

/**
 * Inner Google Maps renderer wrapped inside APIProvider.
 * Monitors loading status and cleanly falls back if script loading fails.
 */
function GoogleMapsInner({
  mode,
  issues = [],
  onSelectIssue,
  selectedCoordinates,
  onPickLocation,
  heightClass = 'h-[440px]',
  onFallbackNeeded,
}: IssuesMapProps & { onFallbackNeeded: () => void }) {
  const loadingStatus = useApiLoadingStatus();
  const [activeIssueId, setActiveIssueId] = useState<string | null>(null);

  useEffect(() => {
    if (
      loadingStatus === APILoadingStatus.FAILED ||
      loadingStatus === APILoadingStatus.AUTH_FAILURE
    ) {
      onFallbackNeeded();
    }
  }, [loadingStatus, onFallbackNeeded]);

  if (
    loadingStatus === APILoadingStatus.NOT_LOADED ||
    loadingStatus === APILoadingStatus.LOADING
  ) {
    return (
      <div
        className={`flex w-full items-center justify-center bg-[var(--cp-bg)] text-sm text-[var(--cp-text-muted)] ${heightClass}`}
      >
        Loading Google Maps Platform…
      </div>
    );
  }

  if (
    loadingStatus === APILoadingStatus.FAILED ||
    loadingStatus === APILoadingStatus.AUTH_FAILURE
  ) {
    return null;
  }

  const defaultCenter =
    mode === 'pick' && selectedCoordinates
      ? { lat: selectedCoordinates.latitude, lng: selectedCoordinates.longitude }
      : issues.length > 0
        ? { lat: issues[0].latitude, lng: issues[0].longitude }
        : { lat: 19.076, lng: 72.8777 };

  const defaultZoom = mode === 'pick' ? 13 : issues.length === 1 ? 13 : 5;

  return (
    <div className={`w-full ${heightClass}`}>
      <GoogleMap
        mapId="DEMO_MAP_ID"
        defaultCenter={defaultCenter}
        defaultZoom={defaultZoom}
        gestureHandling="greedy"
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
        onClick={(event) => {
          if (mode === 'pick' && onPickLocation && event.detail.latLng) {
            onPickLocation(
              Number(event.detail.latLng.lat.toFixed(5)),
              Number(event.detail.latLng.lng.toFixed(5))
            );
          } else {
            setActiveIssueId(null);
          }
        }}
      >
        {mode === 'explore' &&
          issues.map((issue) => (
            <IssueAdvancedMarker
              key={issue.id}
              issue={issue}
              isOpen={activeIssueId === issue.id}
              onOpen={() => setActiveIssueId(issue.id)}
              onClose={() => setActiveIssueId(null)}
              onSelectIssue={onSelectIssue}
            />
          ))}

        {mode === 'pick' && selectedCoordinates && (
          <AdvancedMarker
            position={{
              lat: selectedCoordinates.latitude,
              lng: selectedCoordinates.longitude,
            }}
            title="Selected Issue Location"
          >
            <Pin
              background="#14B8A6"
              borderColor="#102A43"
              glyphColor="#FFFFFF"
              scale={1.15}
            />
          </AdvancedMarker>
        )}
      </GoogleMap>
    </div>
  );
}

/**
 * Fallback OpenStreetMap (Leaflet) view used only when a Google Maps API key
 * is unavailable in the environment or fails to authenticate.
 */
function LeafletFallbackMap({
  mode,
  issues = [],
  onSelectIssue,
  selectedCoordinates,
  onPickLocation,
  heightClass = 'h-[440px]',
}: IssuesMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    const container = mapContainerRef.current;
    if (!container || mapInstanceRef.current) return;

    const initialLat =
      mode === 'pick' && selectedCoordinates ? selectedCoordinates.latitude : 19.5;
    const initialLng =
      mode === 'pick' && selectedCoordinates ? selectedCoordinates.longitude : 77.2;

    const map = L.map(container, {
      center: [initialLat, initialLng],
      zoom: mode === 'pick' ? 12 : 5,
      scrollWheelZoom: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const layerGroup = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;
    markersLayerRef.current = layerGroup;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      markersLayerRef.current = null;
    };
  }, [mode]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || mode !== 'pick' || !onPickLocation) return;
    const handleClick = (event: L.LeafletMouseEvent) => {
      onPickLocation(
        Number(event.latlng.lat.toFixed(5)),
        Number(event.latlng.lng.toFixed(5))
      );
    };
    map.on('click', handleClick);
    return () => {
      map.off('click', handleClick);
    };
  }, [mode, onPickLocation]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    const layerGroup = markersLayerRef.current;
    if (!map || !layerGroup) return;
    layerGroup.clearLayers();

    if (mode === 'explore') {
      const bounds: L.LatLngTuple[] = [];
      issues.forEach((issue) => {
        const color = getCategoryMarkerColor(issue.category);
        const marker = L.circleMarker([issue.latitude, issue.longitude], {
          radius: 9,
          fillColor: color,
          color: '#FFFFFF',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.92,
        });

        const popupEl = document.createElement('div');
        popupEl.className = 'min-w-[200px] space-y-1 text-slate-800';

        const meta = document.createElement('p');
        meta.className = 'text-xs font-mono text-slate-500';
        meta.textContent = `${issue.id} · ${issue.status}`;

        const title = document.createElement('p');
        title.className = 'text-sm font-semibold text-slate-900';
        title.textContent = issue.title;

        const loc = document.createElement('p');
        loc.className = 'text-xs text-slate-600';
        loc.textContent = `${issue.locality}, ${issue.city}`;

        popupEl.append(meta, title, loc);

        if (onSelectIssue) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.textContent = 'View Full Details';
          btn.className =
            'mt-1 w-full rounded bg-[#102A43] px-2.5 py-1.5 text-xs font-medium text-white';
          btn.onclick = () => onSelectIssue(issue);
          popupEl.appendChild(btn);
        }

        marker.bindPopup(popupEl);
        marker.addTo(layerGroup);
        bounds.push([issue.latitude, issue.longitude]);
      });

      if (bounds.length > 0) {
        map.fitBounds(bounds, { padding: [36, 36], maxZoom: 13 });
      }
    } else if (mode === 'pick' && selectedCoordinates) {
      L.circleMarker(
        [selectedCoordinates.latitude, selectedCoordinates.longitude],
        {
          radius: 10,
          fillColor: '#14B8A6',
          color: '#102A43',
          weight: 3,
          fillOpacity: 0.95,
        }
      ).addTo(layerGroup);
      map.setView([selectedCoordinates.latitude, selectedCoordinates.longitude], 13);
    }
  }, [mode, issues, selectedCoordinates, onSelectIssue]);

  return <div ref={mapContainerRef} className={`w-full ${heightClass}`} />;
}

/**
 * Interactive CivicPulse Map powered by Google Maps Platform (@vis.gl/react-google-maps)
 * with AdvancedMarker + Pin + anchored InfoWindow, and graceful fallback if key is unavailable.
 */
export function IssuesMap(props: IssuesMapProps) {
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );
  const [configLoaded, setConfigLoaded] = useState<boolean>(
    Boolean(import.meta.env.VITE_GOOGLE_MAPS_API_KEY)
  );
  const [useFallback, setUseFallback] = useState(false);

  useEffect(() => {
    if (mapsApiKey) {
      setConfigLoaded(true);
      return;
    }
    let cancelled = false;
    fetch('/api/public-config')
      .then((res) => (res.ok ? res.json() : { mapsApiKey: '' }))
      .then((data: { mapsApiKey?: string }) => {
        if (!cancelled) {
          if (data.mapsApiKey) {
            setMapsApiKey(data.mapsApiKey);
          }
          setConfigLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setConfigLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [mapsApiKey]);

  return (
    <div className="overflow-hidden rounded-[10px] border border-[var(--cp-border)] bg-[var(--cp-surface)]">
      {!configLoaded ? (
        <div
          className={`flex w-full items-center justify-center text-sm text-[var(--cp-text-muted)] ${
            props.heightClass || 'h-[440px]'
          }`}
        >
          Initializing map service…
        </div>
      ) : mapsApiKey && !useFallback ? (
        <APIProvider
          apiKey={mapsApiKey}
          libraries={['marker']}
          language="en"
          region="IN"
        >
          <GoogleMapsInner
            {...props}
            onFallbackNeeded={() => setUseFallback(true)}
          />
        </APIProvider>
      ) : (
        <LeafletFallbackMap {...props} />
      )}

      {props.mode === 'explore' && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[var(--cp-border)] bg-[var(--cp-surface)] px-4 py-2.5 text-xs text-[var(--cp-text-muted)]">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="font-medium text-[var(--cp-text)]">
              Category Legend:
            </span>
            <span>● Roads (#D97706)</span>
            <span>● Waste (#15803D)</span>
            <span>● Water (#0284C7)</span>
            <span>● Streetlights (#EAB308)</span>
            <span>● Drainage (#7C3AED)</span>
            <span>● Safety (#EA580C)</span>
          </div>
          <span className="text-[11px]">
            {mapsApiKey && !useFallback
              ? 'Google Maps Platform'
              : 'OpenStreetMap Fallback'}
          </span>
        </div>
      )}
    </div>
  );
}
