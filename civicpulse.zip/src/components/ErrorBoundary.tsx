import { Component, ErrorInfo, ReactNode } from 'react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

/**
 * Top-level React ErrorBoundary catching unexpected runtime or Firestore permission errors.
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error.message || 'An unexpected application error occurred.',
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('CivicPulse ErrorBoundary caught error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto my-12 max-w-xl rounded-[10px] border border-[var(--cp-border)] bg-[var(--cp-surface)] p-6 text-center">
          <h1 className="font-display text-xl font-bold text-[#102A43] dark:text-white">
            Something went wrong
          </h1>
          <p className="mt-2 text-sm text-[var(--cp-text-muted)]">
            {this.state.message}
          </p>
          <button
            type="button"
            onClick={() => this.setState({ hasError: false, message: '' })}
            className="mt-4 rounded-md bg-[#102A43] px-4 py-2 text-sm font-medium text-white hover:bg-[#1A3B5C]"
          >
            Try Again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
