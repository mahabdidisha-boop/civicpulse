/**
 * Core TypeScript definitions for CivicPulse.
 */

export type PageRoute =
  | 'home'
  | 'dashboard'
  | 'report'
  | 'explore'
  | 'track'
  | 'community'
  | 'admin';

export type IssueCategory =
  | 'Road damage / Potholes'
  | 'Garbage and waste management'
  | 'Water leakage'
  | 'Drainage and sewage'
  | 'Streetlight problems'
  | 'Public infrastructure damage'
  | 'Traffic and road safety'
  | 'Other civic issues';

export type IssueStatus =
  | 'Submitted'
  | 'Under Review'
  | 'Verified'
  | 'In Progress'
  | 'Resolved';

export type IssuePriority = 'Low' | 'Medium' | 'High';

export interface StatusHistoryEntry {
  status: IssueStatus;
  timestamp: string;
  note: string;
  updatedBy: string;
}

export interface CivicIssue {
  id: string;
  authorId?: string;
  title: string;
  category: IssueCategory;
  description: string;
  locality: string;
  city: string;
  latitude: number;
  longitude: number;
  status: IssueStatus;
  priority: IssuePriority;
  createdAt: string;
  updatedAt: string;
  imageUrl?: string;
  upvotes: number;
  isDemoRecord: boolean;
  duplicateOfId?: string;
  statusHistory: StatusHistoryEntry[];
}

export interface AppNotification {
  id: string;
  issueId: string;
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
}

export interface GroundedSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  modelUsed?: string;
  sources?: GroundedSource[];
  timestamp: string;
}

export const ISSUE_CATEGORIES: IssueCategory[] = [
  'Road damage / Potholes',
  'Garbage and waste management',
  'Water leakage',
  'Drainage and sewage',
  'Streetlight problems',
  'Public infrastructure damage',
  'Traffic and road safety',
  'Other civic issues',
];

export const ISSUE_STATUSES: IssueStatus[] = [
  'Submitted',
  'Under Review',
  'Verified',
  'In Progress',
  'Resolved',
];

export const ISSUE_PRIORITIES: IssuePriority[] = ['Low', 'Medium', 'High'];
