import { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { SAMPLE_DEMO_ISSUES } from '../data/sampleIssues';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  AppNotification,
  CivicIssue,
  IssueCategory,
  IssuePriority,
  IssueStatus,
} from '../types/issue';

/**
 * Helper to convert Firestore Timestamp or ISO string cleanly into ISO string.
 */
function toIsoString(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (typeof val === 'string') {
    return val;
  }
  return new Date().toISOString();
}

/**
 * Upsert private user profile in `/users/{uid}` upon Google Sign-In.
 * Strictly follows firebase-blueprint.json schema limits.
 */
export async function upsertUserProfile(user: User): Promise<void> {
  const path = `users/${user.uid}`;
  const userRef = doc(db, 'users', user.uid);

  try {
    const existingSnap = await getDoc(userRef);
    const displayName = (user.displayName || user.email?.split('@')[0] || 'Citizen').slice(0, 80);
    const email = (user.email || '').slice(0, 160);
    const photoURL = user.photoURL ? user.photoURL.slice(0, 500) : undefined;

    if (!existingSnap.exists()) {
      await setDoc(userRef, {
        uid: user.uid,
        displayName,
        email,
        ...(photoURL ? { photoURL } : {}),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(userRef, {
        displayName,
        ...(photoURL ? { photoURL } : {}),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Subscribe in real time to `/issues` collection in Firestore.
 */
export function subscribeToIssues(
  onUpdate: (issues: CivicIssue[]) => void,
  onError?: (err: Error) => void
): () => void {
  const path = 'issues';
  return onSnapshot(
    collection(db, path),
    (snapshot) => {
      const records: CivicIssue[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: String(data.id || docSnap.id),
          title: String(data.title || ''),
          category: data.category as IssueCategory,
          description: String(data.description || ''),
          locality: String(data.locality || ''),
          city: String(data.city || ''),
          latitude: Number(data.latitude ?? 0),
          longitude: Number(data.longitude ?? 0),
          status: (data.status as IssueStatus) || 'Submitted',
          priority: (data.priority as IssuePriority) || 'Medium',
          authorUid: String(data.authorUid || ''),
          authorName: String(data.authorName || 'Citizen'),
          createdAt: toIsoString(data.createdAt),
          updatedAt: toIsoString(data.updatedAt),
          imageUrl: typeof data.imageUrl === 'string' ? data.imageUrl : undefined,
          upvotes: Number(data.upvotes ?? 1),
          isDemoRecord: Boolean(data.isDemoRecord),
          duplicateOfId:
            typeof data.duplicateOfId === 'string' ? data.duplicateOfId : undefined,
          statusHistory: Array.isArray(data.statusHistory) ? data.statusHistory : [],
        };
      });

      onUpdate(records);
    },
    (error) => {
      if (onError) {
        onError(error);
      } else {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    }
  );
}

/**
 * Fetch which issues the currently signed-in user has already upvoted
 * by checking `/issues/{issueId}/votes/{uid}` receipts.
 */
export async function fetchUserVotedIssueIds(
  uid: string,
  issueIds: string[]
): Promise<string[]> {
  const voted: string[] = [];
  await Promise.all(
    issueIds.map(async (issueId) => {
      const votePath = `issues/${issueId}/votes/${uid}`;
      try {
        const snap = await getDoc(doc(db, 'issues', issueId, 'votes', uid));
        if (snap.exists()) {
          voted.push(issueId);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, votePath);
      }
    })
  );
  return voted;
}

/**
 * Subscribe to user-scoped notifications (`/notifications` where userId == uid).
 */
export function subscribeToUserNotifications(
  uid: string,
  onUpdate: (notifications: AppNotification[]) => void,
  onError?: (err: Error) => void
): () => void {
  const path = 'notifications';
  const q = query(collection(db, path), where('userId', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items: AppNotification[] = snapshot.docs
        .map((docSnap) => {
          const data = docSnap.data();
          return {
            id: docSnap.id,
            issueId: String(data.issueId || ''),
            title: String(data.title || ''),
            message: String(data.message || ''),
            read: Boolean(data.read),
            createdAt: toIsoString(data.createdAt),
          };
        })
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      onUpdate(items);
    },
    (error) => {
      if (onError) {
        onError(error);
      } else {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    }
  );
}

/**
 * Create a new civic issue in Firestore while clamping field lengths to blueprint constraints.
 */
export async function createIssueInFirestore(
  issueId: string,
  payload: {
    title: string;
    category: IssueCategory;
    description: string;
    locality: string;
    city: string;
    latitude: number;
    longitude: number;
    priority: IssuePriority;
    imageUrl?: string;
  },
  user: User
): Promise<void> {
  const path = `issues/${issueId}`;
  const nowIso = new Date().toISOString();
  const safeAuthorName = (user.displayName || user.email?.split('@')[0] || 'Citizen').slice(0, 80);

  const safeImageUrl =
    payload.imageUrl && payload.imageUrl.length <= 350000 ? payload.imageUrl : undefined;

  const docData = {
    id: issueId.slice(0, 40),
    title: payload.title.trim().slice(0, 140),
    category: payload.category,
    description: payload.description.trim().slice(0, 2000),
    locality: payload.locality.trim().slice(0, 120),
    city: payload.city.trim().slice(0, 80),
    latitude: Math.max(-90, Math.min(90, payload.latitude)),
    longitude: Math.max(-180, Math.min(180, payload.longitude)),
    status: 'Submitted' as IssueStatus,
    priority: payload.priority,
    authorUid: user.uid,
    authorName: safeAuthorName,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    ...(safeImageUrl ? { imageUrl: safeImageUrl } : {}),
    upvotes: 1,
    isDemoRecord: false,
    statusHistory: [
      {
        status: 'Submitted',
        timestamp: nowIso,
        note: 'Report submitted via CivicPulse Portal.',
        updatedBy: safeAuthorName,
      },
    ],
  };

  try {
    await setDoc(doc(db, 'issues', issueId), docData);

    // Create a user-scoped notification confirming submission
    const notifId = `notif-${issueId}-${Date.now()}`;
    await setDoc(doc(db, 'notifications', notifId), {
      userId: user.uid,
      issueId,
      title: `Report Logged: ${issueId}`,
      message: `${docData.title} saved to Cloud Firestore for ${docData.locality}.`.slice(0, 500),
      read: false,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Atomically record a single upvote per user account using writeBatch:
 * 1. Creates `/issues/{issueId}/votes/{uid}`
 * 2. Increments `/issues/{issueId}.upvotes` by +1
 */
export async function upvoteIssueAtomically(
  issueId: string,
  currentUpvotes: number,
  uid: string
): Promise<void> {
  const path = `issues/${issueId}/votes/${uid}`;
  const batch = writeBatch(db);

  batch.set(doc(db, 'issues', issueId, 'votes', uid), {
    userId: uid,
    issueId,
    createdAt: serverTimestamp(),
  });

  batch.update(doc(db, 'issues', issueId), {
    upvotes: currentUpvotes + 1,
    updatedAt: serverTimestamp(),
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Admin action: Update complaint status in Firestore and create a status notification.
 */
export async function updateIssueStatusInFirestore(
  issue: CivicIssue,
  newStatus: IssueStatus,
  note: string,
  adminUser: User
): Promise<void> {
  const path = `issues/${issue.id}`;
  const nowIso = new Date().toISOString();
  const nextHistory = [
    ...issue.statusHistory.slice(-24),
    {
      status: newStatus,
      timestamp: nowIso,
      note: (note.trim() || `Status updated to ${newStatus} by administrator.`).slice(0, 300),
      updatedBy: (adminUser.displayName || adminUser.email || 'Admin Console').slice(0, 80),
    },
  ];

  try {
    await updateDoc(doc(db, 'issues', issue.id), {
      status: newStatus,
      statusHistory: nextHistory,
      updatedAt: serverTimestamp(),
    });

    const targetUid = issue.authorUid || adminUser.uid;
    const notifId = `notif-${issue.id}-${Date.now()}`;
    await setDoc(doc(db, 'notifications', notifId), {
      userId: targetUid,
      issueId: issue.id,
      title: `Status Updated: ${issue.id}`,
      message: `Complaint moved to "${newStatus}". ${note.trim()}`.trim().slice(0, 500),
      read: false,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Admin action: Mark an issue as duplicate of another Complaint ID in Firestore.
 */
export async function markIssueDuplicateInFirestore(
  issue: CivicIssue,
  duplicateOfId: string,
  adminUser: User
): Promise<void> {
  const path = `issues/${issue.id}`;
  const nowIso = new Date().toISOString();
  const safeDuplicateId = duplicateOfId.trim().toUpperCase().slice(0, 40);
  const nextHistory = [
    ...issue.statusHistory.slice(-24),
    {
      status: issue.status,
      timestamp: nowIso,
      note: `Linked as duplicate of ${safeDuplicateId}.`,
      updatedBy: (adminUser.displayName || adminUser.email || 'Admin Console').slice(0, 80),
    },
  ];

  try {
    await updateDoc(doc(db, 'issues', issue.id), {
      duplicateOfId: safeDuplicateId,
      statusHistory: nextHistory,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Mark a user notification as read in Firestore.
 */
export async function markNotificationReadInFirestore(notificationId: string): Promise<void> {
  const path = `notifications/${notificationId}`;
  try {
    await updateDoc(doc(db, 'notifications', notificationId), { read: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Admin-only helper to seed the initial Indian sample issues into Firestore
 * if the live collection has not been seeded yet.
 */
export async function seedSampleIssuesToFirestore(adminUser: User): Promise<void> {
  const batch = writeBatch(db);
  for (const sample of SAMPLE_DEMO_ISSUES) {
    batch.set(doc(db, 'issues', sample.id), {
      id: sample.id,
      title: sample.title,
      category: sample.category,
      description: sample.description,
      locality: sample.locality,
      city: sample.city,
      latitude: sample.latitude,
      longitude: sample.longitude,
      status: sample.status,
      priority: sample.priority,
      authorUid: adminUser.uid,
      authorName: 'CivicPulse Demo Seed',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      ...(sample.imageUrl ? { imageUrl: sample.imageUrl } : {}),
      upvotes: sample.upvotes,
      isDemoRecord: true,
      statusHistory: sample.statusHistory,
    });
  }

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'issues');
  }
}
