import { SAMPLE_DEMO_ISSUES } from '../data/sampleIssues';
import {
  AppNotification,
  CivicIssue,
  IssueCategory,
  IssuePriority,
  IssueStatus,
} from '../types/issue';

/**
 * LocalStorage keys used for browser-based persistence.
 * Later, these functions can be swapped with Firebase Firestore calls
 * (e.g., getDocs, addDoc, updateDoc) while keeping the exact same return types.
 */
const ISSUES_STORAGE_KEY = 'civicpulse_issues_v1';
const VOTED_IDS_STORAGE_KEY = 'civicpulse_voted_ids_v1';
const NOTIFICATIONS_STORAGE_KEY = 'civicpulse_notifications_v1';

/**
 * Load all civic issues from localStorage, seeding with demonstration records on first visit.
 */
export function loadIssues(): CivicIssue[] {
  try {
    const raw = localStorage.getItem(ISSUES_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(ISSUES_STORAGE_KEY, JSON.stringify(SAMPLE_DEMO_ISSUES));
      return [...SAMPLE_DEMO_ISSUES];
    }
    const parsed = JSON.parse(raw) as CivicIssue[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : [...SAMPLE_DEMO_ISSUES];
  } catch {
    return [...SAMPLE_DEMO_ISSUES];
  }
}

/**
 * Persist the full issues array back to localStorage.
 */
export function saveIssues(issues: CivicIssue[]): void {
  try {
    localStorage.setItem(ISSUES_STORAGE_KEY, JSON.stringify(issues));
  } catch {
    // Handle storage quota edge case gracefully without crashing UI
  }
}

/**
 * Generate a unique readable Complaint ID such as CP-2026-1042.
 */
export function generateComplaintId(existingIssues: CivicIssue[]): string {
  const year = new Date().getFullYear();
  let maxNumber = 1000;
  for (const issue of existingIssues) {
    const parts = issue.id.split('-');
    const numericSuffix = Number.parseInt(parts[2] ?? '', 10);
    if (!Number.isNaN(numericSuffix) && numericSuffix > maxNumber) {
      maxNumber = numericSuffix;
    }
  }
  return `CP-${year}-${maxNumber + 1}`;
}

/**
 * Automatic priority classification based on category and keywords in title/description.
 */
export function suggestIssuePriority(
  category: IssueCategory,
  title: string,
  description: string
): IssuePriority {
  const combined = `${title} ${description}`.toLowerCase();

  const urgentKeywords = [
    'flood',
    'accident',
    'hospital',
    'school',
    'spark',
    'live wire',
    'sewage overflow',
    'deep pothole',
    'burst',
    'collapse',
    'main road',
    'dark',
    'unsafe',
    'hazard',
  ];

  if (urgentKeywords.some((keyword) => combined.includes(keyword))) {
    return 'High';
  }

  if (
    category === 'Water leakage' ||
    category === 'Drainage and sewage' ||
    category === 'Traffic and road safety'
  ) {
    return 'High';
  }

  if (
    category === 'Road damage / Potholes' ||
    category === 'Streetlight problems' ||
    category === 'Garbage and waste management'
  ) {
    return 'Medium';
  }

  return 'Low';
}

/**
 * Smart Duplicate Issue Detection:
 * Finds existing non-resolved issues in the same locality and/or category with overlapping keywords.
 */
export function findPotentialDuplicates(
  issues: CivicIssue[],
  locality: string,
  category: IssueCategory,
  title: string
): CivicIssue[] {
  const normalizedLocality = locality.trim().toLowerCase();
  if (!normalizedLocality) return [];

  const titleWords = title
    .toLowerCase()
    .split(/\s+/)
    .filter((word) => word.length > 3);

  return issues.filter((issue) => {
    if (issue.status === 'Resolved') return false;

    const sameLocality =
      issue.locality.toLowerCase().includes(normalizedLocality) ||
      normalizedLocality.includes(issue.locality.toLowerCase());

    const sameCategory = issue.category === category;

    if (sameLocality && sameCategory) {
      return true;
    }

    if (sameLocality && titleWords.length > 0) {
      const targetText = `${issue.title} ${issue.description}`.toLowerCase();
      return titleWords.some((word) => targetText.includes(word));
    }

    return false;
  });
}

/**
 * Load the set of issue IDs this browser/account has already supported (upvoted),
 * preventing repeated votes from the same user.
 */
export function loadVotedIssueIds(): string[] {
  try {
    const raw = localStorage.getItem(VOTED_IDS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}

export function saveVotedIssueIds(ids: string[]): void {
  try {
    localStorage.setItem(VOTED_IDS_STORAGE_KEY, JSON.stringify(ids));
  } catch {
    // Ignore storage quota errors
  }
}

/**
 * Load and save in-app status notifications.
 */
export function loadNotifications(): AppNotification[] {
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as AppNotification[];
    }
    const starter: AppNotification[] = [
      {
        id: 'notif-starter-1',
        issueId: 'CP-2026-1001',
        title: 'Status Updated: CP-2026-1001',
        message: 'Sample report moved to In Progress (cold-mix patching scheduled).',
        createdAt: '2026-11-15T14:30:00.000Z',
        read: false,
      },
    ];
    localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(starter));
    return starter;
  } catch {
    return [];
  }
}

export function saveNotifications(notifications: AppNotification[]): void {
  try {
    localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(notifications));
  } catch {
    // Ignore storage errors
  }
}

/**
 * Helper to create a clean updated issue record when an administrator updates status.
 */
export function applyStatusUpdate(
  issue: CivicIssue,
  newStatus: IssueStatus,
  note: string,
  updatedBy = 'Demo Admin Console'
): CivicIssue {
  const now = new Date().toISOString();
  return {
    ...issue,
    status: newStatus,
    updatedAt: now,
    statusHistory: [
      ...issue.statusHistory,
      {
        status: newStatus,
        timestamp: now,
        note: note.trim() || `Status updated to ${newStatus} in demonstration console.`,
        updatedBy,
      },
    ],
  };
}

/**
 * Reset demonstration data back to original sample records.
 */
export function resetDemoStorage(): CivicIssue[] {
  saveIssues(SAMPLE_DEMO_ISSUES);
  saveVotedIssueIds([]);
  const freshNotifications: AppNotification[] = [
    {
      id: `notif-reset-${Date.now()}`,
      issueId: 'CP-2026-1001',
      title: 'Demonstration Data Reset',
      message: 'Restored sample Indian urban locality reports to default state.',
      createdAt: new Date().toISOString(),
      read: false,
    },
  ];
  saveNotifications(freshNotifications);
  return [...SAMPLE_DEMO_ISSUES];
}
