import { initializeApp } from 'firebase/app';
import {
  GoogleAuthProvider,
  User,
  getAuth,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  Timestamp,
  collection,
  doc,
  getDoc,
  getDocFromServer,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  AppNotification,
  CivicIssue,
  IssueStatus,
} from '../types/issue';

// Initialize Firebase App, Auth, and Firestore using the provisioned database ID
const app = initializeApp(firebaseConfig);
export const db = getFirestoreCompat();
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

import { getFirestore } from 'firebase/firestore';

function getFirestoreCompat() {
  return getFirestore(app, firebaseConfig.firestoreDatabaseId);
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Startup Firestore connectivity verification.
 */
export async function testFirestoreConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

/**
 * Sign in with Google via popup (required for iframe preview environment).
 */
export async function signInWithGoogle(): Promise<User> {
  const credential = await signInWithPopup(auth, googleProvider);
  const user = credential.user;
  await syncUserProfileDocuments(user);
  return user;
}

export async function signOutCitizen(): Promise<void> {
  await signOut(auth);
}

/**
 * Persist public user profile (/users/{uid}) without PII and isolate email
 * inside /users/{uid}/private/info per Firestore security rules.
 */
export async function syncUserProfileDocuments(user: User): Promise<void> {
  const publicPath = `users/${user.uid}`;
  const privatePath = `users/${user.uid}/private/info`;

  try {
    const publicRef = doc(db, 'users', user.uid);
    const existing = await getDoc(publicRef);

    if (!existing.exists()) {
      await setDoc(publicRef, {
        uid: user.uid,
        displayName: (user.displayName || 'CivicPulse Citizen').slice(0, 100),
        ...(user.photoURL ? { photoURL: user.photoURL.slice(0, 500) } : {}),
        role: 'citizen',
        createdAt: serverTimestamp(),
      });
    } else {
      await updateDoc(publicRef, {
        displayName: (user.displayName || 'CivicPulse Citizen').slice(0, 100),
        ...(user.photoURL ? { photoURL: user.photoURL.slice(0, 500) } : {}),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, publicPath);
  }

  if (user.email) {
    try {
      const privateRef = doc(db, 'users', user.uid, 'private', 'info');
      await setDoc(privateRef, {
        uid: user.uid,
        email: user.email.slice(0, 200),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, privatePath);
    }
  }
}

/**
 * Helper to convert Firestore Timestamp or string into ISO timestamp.
 */
function toIsoString(value: unknown): string {
  if (value instanceof Timestamp) {
    return value.toDate().toISOString();
  }
  if (typeof value === 'string') {
    return value;
  }
  return new Date().toISOString();
}

/**
 * Subscribe to live public civic issues stored in Firestore.
 * Query explicitly matches `visibility == 'public'` to align with Firestore rules.
 */
export function subscribeToFirestoreIssues(
  onData: (issues: CivicIssue[]) => void,
  onError: (err: Error) => void
): () => void {
  const path = 'issues';
  const issuesQuery = query(
    collection(db, path),
    where('visibility', '==', 'public'),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(
    issuesQuery,
    (snapshot) => {
      const list: CivicIssue[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: String(data.id ?? docSnap.id),
          authorId: String(data.authorId ?? ''),
          title: String(data.title ?? ''),
          category: data.category,
          description: String(data.description ?? ''),
          locality: String(data.locality ?? ''),
          city: String(data.city ?? ''),
          latitude: Number(data.latitude ?? 0),
          longitude: Number(data.longitude ?? 0),
          status: data.status,
          priority: data.priority,
          createdAt: toIsoString(data.createdAt),
          updatedAt: toIsoString(data.updatedAt),
          imageUrl: typeof data.imageUrl === 'string' ? data.imageUrl : undefined,
          upvotes: Number(data.upvotes ?? 1),
          isDemoRecord: Boolean(data.isDemoRecord),
          duplicateOfId:
            typeof data.duplicateOfId === 'string' ? data.duplicateOfId : undefined,
          statusHistory: Array.isArray(data.statusHistory) ? data.statusHistory : [],
        };
      });
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

/**
 * Subscribe to the signed-in user's voted issue IDs via collection query or per-issue check.
 * Uses user's notifications collection as well.
 */
export function subscribeToUserNotifications(
  userId: string,
  onData: (notifications: AppNotification[]) => void,
  onError: (err: Error) => void
): () => void {
  const path = `users/${userId}/notifications`;
  const notifQuery = query(
    collection(db, 'users', userId, 'notifications'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(
    notifQuery,
    (snapshot) => {
      const items: AppNotification[] = snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: String(data.id ?? docSnap.id),
          issueId: String(data.issueId ?? ''),
          title: String(data.title ?? ''),
          message: String(data.message ?? ''),
          createdAt: toIsoString(data.createdAt),
          read: Boolean(data.read),
        };
      });
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

/**
 * Create a new civic issue document in Firestore adhering strictly to firebase-blueprint.json boundaries.
 */
export async function createFirestoreIssue(
  issue: CivicIssue,
  authorUid: string
): Promise<void> {
  const path = `issues/${issue.id}`;
  const docRef = doc(db, 'issues', issue.id);

  // Respect Firestore 1MB limit and blueprint 150,000 char ceiling on imageUrl
  const boundedImage =
    issue.imageUrl && issue.imageUrl.length <= 145000 ? issue.imageUrl : undefined;

  const payload = {
    id: issue.id,
    authorId: authorUid,
    visibility: 'public',
    title: issue.title.slice(0, 180),
    category: issue.category,
    description: issue.description.slice(0, 2000),
    locality: issue.locality.slice(0, 150),
    city: issue.city.slice(0, 100),
    latitude: issue.latitude,
    longitude: issue.longitude,
    status: 'Submitted',
    priority: issue.priority,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    ...(boundedImage ? { imageUrl: boundedImage } : {}),
    upvotes: 1,
    isDemoRecord: false,
    statusHistory: issue.statusHistory.slice(0, 25),
  };

  try {
    await setDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Atomic upvote: writes /issues/{issueId}/votes/{uid} AND increments upvotes by 1 in one batch,
 * satisfying Pillar 7 Atomicity in firestore.rules.
 */
export async function upvoteFirestoreIssue(
  issueId: string,
  userId: string
): Promise<void> {
  const issueRef = doc(db, 'issues', issueId);
  const voteRef = doc(db, 'issues', issueId, 'votes', userId);
  const path = `issues/${issueId}/votes/${userId}`;

  try {
    const existingVote = await getDoc(voteRef);
    if (existingVote.exists()) return;

    const batch = writeBatch(db);
    batch.set(voteRef, {
      userId,
      issueId,
      createdAt: serverTimestamp(),
    });
    batch.update(issueRef, {
      upvotes: increment(1),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Admin update complaint status in Firestore.
 */
export async function updateFirestoreIssueStatus(
  issue: CivicIssue,
  newStatus: IssueStatus,
  note: string,
  updatedBy: string
): Promise<void> {
  const path = `issues/${issue.id}`;
  const issueRef = doc(db, 'issues', issue.id);
  const nextHistory = [
    ...issue.statusHistory,
    {
      status: newStatus,
      timestamp: new Date().toISOString(),
      note: note.trim() || `Status updated to ${newStatus}.`,
      updatedBy,
    },
  ].slice(-25);

  try {
    await updateDoc(issueRef, {
      status: newStatus,
      updatedAt: serverTimestamp(),
      statusHistory: nextHistory,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Admin mark duplicate in Firestore.
 */
export async function markFirestoreIssueDuplicate(
  issue: CivicIssue,
  duplicateOfId: string
): Promise<void> {
  const path = `issues/${issue.id}`;
  const issueRef = doc(db, 'issues', issue.id);
  const nextHistory = [
    ...issue.statusHistory,
    {
      status: issue.status,
      timestamp: new Date().toISOString(),
      note: `Linked as duplicate of ${duplicateOfId}.`,
      updatedBy: 'Admin Console',
    },
  ].slice(-25);

  try {
    await updateDoc(issueRef, {
      duplicateOfId: duplicateOfId.slice(0, 64),
      updatedAt: serverTimestamp(),
      statusHistory: nextHistory,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Persist a notification document in /users/{uid}/notifications/{notifId}.
 */
export async function createFirestoreNotification(
  userId: string,
  notif: AppNotification
): Promise<void> {
  const path = `users/${userId}/notifications/${notif.id}`;
  const notifRef = doc(db, 'users', userId, 'notifications', notif.id);

  try {
    await setDoc(notifRef, {
      id: notif.id.slice(0, 128),
      userId,
      issueId: notif.issueId.slice(0, 64),
      title: notif.title.slice(0, 180),
      message: notif.message.slice(0, 500),
      createdAt: serverTimestamp(),
      read: notif.read,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Mark unread Firestore notifications as read using a write batch.
 */
export async function markFirestoreNotificationsRead(
  userId: string,
  notificationIds: string[]
): Promise<void> {
  if (notificationIds.length === 0) return;
  const path = `users/${userId}/notifications`;

  try {
    const batch = writeBatch(db);
    for (const id of notificationIds) {
      const ref = doc(db, 'users', userId, 'notifications', id);
      batch.update(ref, { read: true });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

