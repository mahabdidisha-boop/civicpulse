import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

/**
 * Shared server-side GoogleGenAI client.
 * Reads GEMINI_API_KEY strictly from server environment variables.
 */
function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY is not configured in server environment secrets.'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractGeminiError(error: unknown): { status: number; message: string } {
  const raw = error instanceof Error ? error.message : String(error);
  if (raw.includes('PERMISSION_DENIED') || raw.includes('API_KEY_INVALID')) {
    return {
      status: 403,
      message:
        'Gemini API key permission denied or invalid. Please check your key in Settings > Secrets.',
    };
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return {
      status: 429,
      message:
        'Gemini API quota or paid-tier requirement reached. Ensure a billing-enabled API key is selected in Settings > Secrets.',
    };
  }
  return { status: 500, message: raw || 'Upstream Gemini API error.' };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  // 1. Public browser configuration (never exposes server-only secrets like GEMINI_API_KEY)
  app.get('/api/public-config', (_req, res) => {
    res.json({
      mapsApiKey:
        process.env.VITE_GOOGLE_MAPS_API_KEY ||
        process.env.GOOGLE_MAPS_API_KEY ||
        '',
    });
  });

  // 2. Photo-to-Video Animation via Gemini Interactions API (gemini-omni-1.2-flash)
  app.post('/api/animate-video', async (req, res) => {
    try {
      const { imageBase64, mimeType, prompt, aspectRatio } = req.body as {
        imageBase64?: string;
        mimeType?: string;
        prompt?: string;
        aspectRatio?: '16:9' | '9:16';
      };

      if (!imageBase64 || typeof imageBase64 !== 'string') {
        res.status(400).json({ error: 'Uploaded image data is required.' });
        return;
      }

      const validAspectRatio = aspectRatio === '9:16' ? '9:16' : '16:9';
      const cleanMime =
        typeof mimeType === 'string' && mimeType.startsWith('image/')
          ? mimeType
          : 'image/jpeg';
      const cleanPrompt =
        typeof prompt === 'string' && prompt.trim().length > 0
          ? prompt.trim()
          : 'Slow, steady civic documentation camera pan over the reported street infrastructure issue in natural daylight, realistic motion.';

      const ai = createGeminiClient();
      const interaction = await ai.interactions.create(
        {
          model: 'gemini-omni-1.2-flash',
          input: [
            {
              type: 'image',
              mime_type: cleanMime,
              data: imageBase64,
            },
            {
              type: 'text',
              text: cleanPrompt,
            },
          ],
          background: false,
          store: false,
          stream: false,
          response_format: {
            type: 'video',
            aspect_ratio: validAspectRatio,
          },
        },
        { timeout: 300000 }
      );

      const videoPart = interaction.output_video;
      if (!videoPart || (!videoPart.data && !videoPart.uri)) {
        res.status(502).json({
          error: 'Video generation completed without a playable video output.',
        });
        return;
      }

      const videoMimeType = videoPart.mime_type || 'video/mp4';
      const videoUrl = videoPart.data
        ? `data:${videoMimeType};base64,${videoPart.data}`
        : videoPart.uri;

      res.json({
        videoUrl,
        mimeType: videoMimeType,
        aspectRatio: validAspectRatio,
      });
    } catch (error) {
      const parsed = extractGeminiError(error);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // 3. Google Search Grounding for live municipal & civic advisories (gemini-4-hydrogen)
  app.post('/api/search-civic', async (req, res) => {
    try {
      const { query, locality, city } = req.body as {
        query?: string;
        locality?: string;
        city?: string;
      };

      if (!query || typeof query !== 'string' || !query.trim()) {
        res.status(400).json({ error: 'A search query is required.' });
        return;
      }

      const locationContext = [locality, city].filter(Boolean).join(', ');
      const prompt = locationContext
        ? `Provide accurate, up-to-date civic, municipal grievance portal, ward office, or local infrastructure/weather advisory information for ${locationContext}. Citizen question: ${query.trim()}`
        : query.trim();

      const ai = createGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction:
            'You are a factual CivicPulse municipal information researcher. Provide concise, practical guidance grounded in current search results, including official civic grievance portals, helpline numbers, or recent local advisories when found. Do not invent phone numbers or URLs.',
          tools: [{ googleSearch: {} }],
        },
      });

      const rawChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const sources: Array<{ title: string; uri: string }> = [];
      for (const chunk of rawChunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri) {
          sources.push({
            title: web.title || web.uri,
            uri: web.uri,
          });
        }
      }

      res.json({
        answer: response.text || 'No grounded summary returned.',
        sources,
      });
    } catch (error) {
      const parsed = extractGeminiError(error);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // 4. Multi-Turn Gemini Chatbot (CivicPulse Assistant)
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, mode, useSearch } = req.body as {
        messages?: Array<{ role: 'user' | 'model'; text: string }>;
        mode?: 'general' | 'fast' | 'complex' | 'deep';
        useSearch?: boolean;
      };

      if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'Conversation history is required.' });
        return;
      }

      const latest = messages[messages.length - 1];
      if (!latest || latest.role !== 'user' || !latest.text.trim()) {
        res.status(400).json({ error: 'Latest message must be non-empty user text.' });
        return;
      }

      const modelMap = {
        general: 'gemini-4-hydrogen',
        fast: 'gemini-3.1-flash-lite',
        complex: 'gemini-4-argon',
        deep: 'gemini-4-carbon',
      } as const;

      const selectedModel = modelMap[mode ?? 'general'] ?? 'gemini-4-hydrogen';

      const history = messages.slice(0, -1).map((msg) => ({
        role: msg.role,
        parts: [{ text: msg.text }],
      }));

      const ai = createGeminiClient();
      const chat = ai.chats.create({
        model: selectedModel,
        history,
        config: {
          systemInstruction:
            'You are the CivicPulse Neighbourhood Assistant, a calm, practical civic-tech advisor helping residents document hyperlocal infrastructure issues (roads, waste, water leaks, drainage, streetlights, traffic safety), classify urgency, draft clear non-PII descriptions, and understand local civic escalation pathways. Keep responses concise, structured, and helpful.',
          ...(useSearch ? { tools: [{ googleSearch: {} }] } : {}),
        },
      });

      const response = await chat.sendMessage({
        message: latest.text.trim(),
      });

      const rawChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const sources: Array<{ title: string; uri: string }> = [];
      for (const chunk of rawChunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri) {
          sources.push({
            title: web.title || web.uri,
            uri: web.uri,
          });
        }
      }

      res.json({
        reply: response.text || 'Unable to generate a response.',
        modelUsed: selectedModel,
        sources,
      });
    } catch (error) {
      const parsed = extractGeminiError(error);
      res.status(parsed.status).json({ error: parsed.message });
    }
  });

  // Mount Vite middleware in development or serve built dist/ in production
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CivicPulse server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start CivicPulse server:', err);
  process.exit(1);
});
