# CivicPulse Firestore Security Specification (Phase 0)

## 1. Data Invariants
1. **Default-Deny Baseline**: Every path in `/databases/{database}/documents` is denied unless explicitly matched and authorized.
2. **PII Isolation**: User email addresses live exclusively in `/users/{userId}/private/info` and are readable/writable only by `request.auth.uid == userId`.
3. **Authorship Integrity**: A civic issue document in `/issues/{issueId}` cannot be created with an `authorId` different from `request.auth.uid`, and `authorId`, `id`, and `createdAt` are immutable after creation.
4. **Server Timestamp Enforcement**: `createdAt` on create and `updatedAt` on update must equal `request.time`.
5. **Single-Vote Atomicity**: A vote in `/issues/{issueId}/votes/{userId}` can only be created when `userId == request.auth.uid`, and must be accompanied atomically in the same batch by incrementing `upvotes` by 1 on `/issues/{issueId}`.
6. **Terminal State & Privilege Separation**: Citizens cannot self-assign `role: 'admin'`, cannot alter `status` or `duplicateOfId` on issues, and cannot modify an issue once its status reaches `'Resolved'` (only `isAdmin()` can update statuses or override terminal state).
7. **Secure List Queries**: `allow list` on `/issues` explicitly evaluates `resource.data.visibility == 'public'`, and `allow list` on `/users/{userId}/notifications` checks `resource.data.userId == request.auth.uid`.

## 2. Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Unauthenticated issue create**: `auth = null`, write `/issues/CP-2026-2001` -> DENIED.
2. **Spoofed authorId on issue create**: `auth.uid = "userA"`, payload `authorId: "userB"` -> DENIED.
3. **Unverified email write**: `auth.token.email_verified = false`, write `/issues/CP-2026-2002` -> DENIED.
4. **Self-assigned admin role**: `auth.uid = "userA"`, write `/users/userA` with `role: "admin"` -> DENIED.
5. **Shadow ghost field on issue update**: `auth.uid = "userA"`, update `/issues/CP-2026-2001` adding `isVerified: true` -> DENIED.
6. **Citizen changing complaint status**: non-admin `userA` updates `status: "Resolved"` on own issue -> DENIED.
7. **Terminal state mutation**: non-admin attempts to edit `title` when existing `status == "Resolved"` -> DENIED.
8. **PII snooping**: `userA` reads `/users/userB/private/info` -> DENIED.
9. **Client-spoofed timestamp**: create `/issues/CP-2026-2003` with `createdAt` != `request.time` -> DENIED.
10. **Oversized ID poisoning**: create `/issues/<150-char-junk>` -> DENIED by `isValidId()`.
11. **Standalone upvote counter inflation**: `userA` updates `/issues/CP-2026-1001` `upvotes` by `+10` without creating `/votes/userA` -> DENIED.
12. **Reading another user's private notifications**: `userA` lists `/users/userB/notifications` -> DENIED.
